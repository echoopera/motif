// shell — the Style Lab 2 workspace: library, pinned stage, key lane, layers, colour, finish,
// audio, looks, Evolve, export and keyboard. Owns UI state only; all rendering goes through
// the renderer pipeline and all project changes through the timeline model.
const { ASPECTS, PALETTES } = __m_tokens;
const { clamp, fract } = __m_engine_core;
const { STYLES, CATEGORIES, SHARED_SCHEMA, getStyle } = __m_style_library;
const C = __m_colour;
const T = __m_timeline;
const A = __m_audio;
const { createGpuEngine, GPU_STYLES } = __m_gpu_engine;
const { createPipeline, createStage, renderThumb, renderProjectThumb, exportSize, frameCount, aspectRatio } = __m_renderer;
const X = __m_exporter;

function boot() {
  const $ = id => document.getElementById(id);
  const app = $('app');
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const store = { get(k) { try { return JSON.parse(localStorage.getItem(k)); } catch (e) { return null; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* storage unavailable */ } } };
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  // ---------- state ----------
  let project = demoProject();
  let aspect = '16x9', strength = 0.35, catFilter = 'all', query = '', tab = 'layer', zebra = false;
  let selKey = null; // { path, idx }
  let evolveOpen = false, children = [], round = 0, lastFocus = null;
  const locks = new Set(); // paths locked from Mutate / Evolve / Randomize
  const history = [JSON.stringify(project)]; let cursor = 0;
  const clone = T.clone;
  function commit(next, msg) {
    project = T.sanitizeProject(next, C.sanitizeCustom);
    const snap = JSON.stringify(project);
    if (snap !== history[cursor]) { history.splice(cursor + 1); history.push(snap); if (history.length > 300) history.shift(); cursor = history.length - 1; }
    syncAudioRegion(); refresh(); if (msg) toast(msg);
  }
  function live(next) { project = next; stage.invalidate(); }
  function undo() { if (cursor > 0) { cursor--; project = JSON.parse(history[cursor]); syncAudioRegion(); refresh(); toast('Undo'); } }
  function redo() { if (cursor < history.length - 1) { cursor++; project = JSON.parse(history[cursor]); syncAudioRegion(); refresh(); toast('Redo'); } }
  const active = () => T.layerById(project, project.active) || project.layers[0];
  const lpath = (scope, key, id = project.active) => `L:${id}:${scope}:${key}`;

  function demoProject() {
    // Plexus behind Particle Form over Halftone: burst builds 0 → 1, palette shifts at 3.5 s.
    let pr = T.newProject('plexus');
    const base = pr.layers[0]; base.shared.palette = 'graphite'; base.params = { ...base.params, points: 150, distance: 0.19, lines: 0.5 };
    const half = T.newLayer('halftone', { ...base.shared }, { blend: 'screen', opacity: 0.24 });
    half.params = { ...half.params, cell: 0.02, contrast: 0.8, duotone: true };
    const form = T.newLayer('particle-form', { ...base.shared }, { blend: 'source-over' });
    form.params = { ...form.params, count: 6000, dot: 0.9, turbulence: 0.6 };
    pr.layers.push(half, form); pr.active = form.id;
    pr.finish = { ...pr.finish, glow: 0.4, glowThreshold: 0.5, glowRadius: 0.45, vignette: 0.3, grain: 0.08 };
    pr = T.setKey(pr, `L:${form.id}:p:burst`, 0, 0, 'smooth'); pr = T.setKey(pr, `L:${form.id}:p:burst`, 0.5, 1, 'smooth');
    for (const l of pr.layers) { pr = T.setKey(pr, `L:${l.id}:s:palette`, 0, 'graphite', 'hold'); pr = T.setKey(pr, `L:${l.id}:s:palette`, 3.5 / 6, 'chroma', 'hold'); }
    return T.sanitizeProject(pr, C.sanitizeCustom);
  }

  // ---------- engine ----------
  const gpu = createGpuEngine();
  const pipeline = createPipeline({ gpu });
  const player = A.createPlayer();
  let analysis = null, envFn = null, liveOn = false, audioSync = true, trackName = '';
  const liveEnv = band => { const b = player.liveBands(); return b ? b[band] : null; };
  const currentEnv = () => (liveOn ? liveEnv : envFn);
  const stage = createStage({
    host: $('stageHost'), box: $('stageBox'), pipeline, getProject: () => project, onTick, onError: e => console.error(e),
    clock: () => (audioSync && player.playing ? player.time() : null), env: currentEnv, extras: { get zebra() { return zebra; }, live: () => liveOn },
  });
  stage.setSpace(project.output.space);
  if (reduce) { stage.pause(); $('rmHint').hidden = false; }
  function updateEngineChip() {
    const c = $('engineChip'), s = gpu.state;
    c.textContent = s === 'ready' ? 'GPU' : s === 'init' ? 'GPU…' : s === 'off' ? 'CPU · GPU off' : 'CPU';
    c.dataset.state = s === 'ready' ? 'gpu' : 'cpu';
    c.title = s === 'ready' ? 'WebGPU engine on for Flow Field, Orbital Swarm, Metaballs and Particle Form. Click to use Canvas 2D.' : s === 'off' ? 'WebGPU is available but switched off. Click to turn it on.' : `Canvas 2D engine. ${gpu.reason || ''}`;
    c.disabled = !(s === 'ready' || s === 'off');
  }
  updateEngineChip();
  gpu.init().then(() => { updateEngineChip(); stage.invalidate(); if (tab === 'layer') renderPanel(); });
  $('engineChip').addEventListener('click', () => { gpu.setForceCpu(!gpu.forceCpu); updateEngineChip(); stage.invalidate(); renderPanel(); toast(gpu.forceCpu ? 'Canvas 2D engine' : 'WebGPU engine'); });

  // ---------- ticking ----------
  let lastUi = 0, lastEvo = 0;
  function onTick(t, info) {
    const now = performance.now(); if (now - lastUi < 60 && stage.playing) return; lastUi = now;
    const L = project.finish.loop, u = t / L;
    $('time').textContent = `${t.toFixed(2)} / ${L.toFixed(2)} s`;
    if (document.activeElement !== $('scrub')) $('scrub').value = Math.round(u * 1000);
    $('frameRead').textContent = `f ${String(Math.floor(t * project.output.fps)).padStart(3, '0')}`;
    const eng = info && info.engines && info.engines.includes('gpu') ? ' · GPU' : '';
    $('perf').textContent = `${stage.frameMs().toFixed(1)} ms${info && info.samples > 1 ? ` · ${info.samples}× blur` : ''}${eng}`;
    $('lane').style.setProperty('--ph', u.toFixed(4));
    if (evolveOpen && now - lastEvo > 90) { lastEvo = now; drawChildren(t); }
    updateAnimatedRows(t);
    if (tab === 'audio') updateMeters(t);
  }

  // ---------- top bar ----------
  const aspectsEl = $('aspects');
  aspectsEl.innerHTML = ASPECTS.map((a, i) => `<button role="radio" data-a="${a.id}" aria-checked="${a.id === aspect}" title="${a.label} (${i + 1})">${a.label}</button>`).join('');
  $('aspectSel').innerHTML = ASPECTS.map(a => `<option value="${a.id}">${a.label}</option>`).join('');
  $('aspectSel').addEventListener('change', e => setAspect(e.target.value));
  function setAspect(a) {
    aspect = a; $('aspectSel').value = a; stage.setAspect(a); $('stageCol').style.setProperty('--ar', aspectRatio(a).toFixed(4));
    aspectsEl.querySelectorAll('button').forEach(b => b.setAttribute('aria-checked', b.dataset.a === a));
    if (evolveOpen) layoutChildren();
  }
  setAspect(aspect);
  aspectsEl.addEventListener('click', e => { const b = e.target.closest('button'); if (b) setAspect(b.dataset.a); });
  function setPlayUi(on) { $('play').textContent = on ? '❚❚' : '▶'; $('play').setAttribute('aria-label', on ? 'Pause' : 'Play'); }
  function togglePlay() {
    const on = stage.toggle(); setPlayUi(on); if (on) $('rmHint').hidden = true;
    if (player.buffer && audioSync) { if (on) player.start(stage.time); else player.stop(); }
  }
  $('play').addEventListener('click', togglePlay);
  if (reduce) setPlayUi(false);
  $('quality').addEventListener('change', e => stage.setQuality(e.target.value));
  $('guidesBtn').addEventListener('click', toggleGuides);
  function toggleGuides() { const on = $('guides').hidden; $('guides').hidden = !on; $('guidesBtn').setAttribute('aria-pressed', on); }
  function seekFrac(f) { stage.seek(f); if (player.playing) player.start(stage.time); }
  $('scrub').addEventListener('input', e => seekFrac(e.target.value / 1000));
  $('bpmChip').addEventListener('click', () => setTab('audio'));

  // ---------- tabs ----------
  const mqDesktop = matchMedia('(min-width: 68.8125em)');
  function setTab(t) {
    if (t === 'library' && mqDesktop.matches) t = 'layer';
    tab = t; app.dataset.tab = t;
    $('tabs').querySelectorAll('[role=tab]').forEach(b => b.setAttribute('aria-selected', b.dataset.tab === t));
    $('insp').querySelectorAll('[role=tabpanel]').forEach(p => { p.hidden = p.dataset.panel !== t; });
    renderPanel(); $('insp').scrollTop = 0;
  }
  $('tabs').addEventListener('click', e => { const b = e.target.closest('[role=tab]'); if (b) setTab(b.dataset.tab); });
  $('tabs').addEventListener('keydown', e => {
    if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
    const bs = [...$('tabs').querySelectorAll('[role=tab]')].filter(b => b.offsetParent); const i = bs.findIndex(b => b.dataset.tab === tab);
    const n = bs[(i + (e.key === 'ArrowRight' ? 1 : -1) + bs.length) % bs.length]; setTab(n.dataset.tab); n.focus(); e.preventDefault();
  });
  mqDesktop.addEventListener('change', () => { if (tab === 'library') setTab('layer'); stage.setAspect(aspect); });

  // ---------- library ----------
  const catsEl = $('cats');
  catsEl.innerHTML = [{ id: 'all', name: 'All' }, ...CATEGORIES].map(c => `<button class="chip" data-c="${c.id}" aria-pressed="${c.id === 'all'}">${c.name}</button>`).join('');
  catsEl.addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; catFilter = b.dataset.c; catsEl.querySelectorAll('button').forEach(x => x.setAttribute('aria-pressed', x === b)); renderLibrary(); });
  $('search').addEventListener('input', e => { query = e.target.value.trim().toLowerCase(); renderLibrary(); });
  const thumbs = new Map();
  function thumbLook(st) { const l = active(); return { styleId: st.id, params: T.newLayer(st.id).params, shared: { ...l.shared, zoom: 1, rotate: 0, phase: 0, tempo: 1, loop: project.finish.loop } }; }
  function renderLibrary() {
    const list = $('libList'); list.innerHTML = ''; thumbs.clear(); let count = 0;
    for (const cat of CATEGORIES) {
      const items = STYLES.filter(s => s.category === cat.id && (catFilter === 'all' || catFilter === cat.id) && (!query || s.name.toLowerCase().includes(query) || s.blurb.toLowerCase().includes(query)));
      if (!items.length) continue;
      const h = document.createElement('li'); h.className = 'lib-cat'; h.setAttribute('role', 'presentation'); h.textContent = cat.name; list.appendChild(h);
      for (const st of items) {
        count++;
        const li = document.createElement('li'); li.className = 'style-row'; li.setAttribute('role', 'option'); li.id = 'opt-' + st.id; li.tabIndex = -1;
        li.setAttribute('aria-selected', st.id === active().styleId);
        li.innerHTML = `<canvas width="128" height="80" aria-hidden="true"></canvas><div><b>${st.name}</b><span class="n">${cat.name}${st.gpu ? ' · <span class="gpu">GPU</span>' : ''}</span></div><span class="n">${String(STYLES.indexOf(st) + 1).padStart(2, '0')}</span>`;
        li.addEventListener('click', () => selectStyle(st.id));
        const c = li.querySelector('canvas'); thumbs.set(st.id, c);
        li.addEventListener('pointerenter', () => animateThumb(st, c, true));
        li.addEventListener('pointerleave', () => animateThumb(st, c, false));
        list.appendChild(li);
      }
    }
    if (!count) { const e = document.createElement('li'); e.className = 'lib-empty'; e.textContent = `No styles match “${query}”.`; list.appendChild(e); }
    list.setAttribute('aria-activedescendant', 'opt-' + active().styleId);
    drawThumbs();
  }
  let thumbJob = 0;
  function drawThumbs() {
    const job = ++thumbJob; const entries = [...thumbs.entries()]; let i = 0;
    const step = () => { if (job !== thumbJob) return; const t0 = performance.now(); while (i < entries.length && performance.now() - t0 < 10) { const [id, c] = entries[i++]; renderThumb(pipeline, c, thumbLook(getStyle(id)), 0.3, project.palettes); } if (i < entries.length) requestAnimationFrame(step); };
    requestAnimationFrame(step);
  }
  let hoverRaf = 0;
  function animateThumb(st, c, on) {
    cancelAnimationFrame(hoverRaf);
    if (!on || reduce) { renderThumb(pipeline, c, thumbLook(st), 0.3, project.palettes); return; }
    const start = performance.now(); const L = project.finish.loop;
    const loop = now => { renderThumb(pipeline, c, thumbLook(st), 0.3 + ((now - start) / 1000) / L, project.palettes); hoverRaf = requestAnimationFrame(loop); };
    hoverRaf = requestAnimationFrame(loop);
  }
  function selectStyle(id) {
    const l = active(); if (id === l.styleId) return;
    const next = clone(project); const nl = T.layerById(next, l.id);
    nl.styleId = id; nl.params = T.newLayer(id).params;
    let dropped = 0; for (const p of Object.keys(next.keys)) if (p.startsWith(`L:${l.id}:p:`)) { delete next.keys[p]; dropped++; }
    if (next.audio) next.audio.maps = next.audio.maps.filter(m => !m.path.startsWith(`L:${l.id}:p:`));
    commit(next, dropped ? `${getStyle(id).name} · removed ${dropped} key${dropped > 1 ? ' rows' : ' row'} from the old style` : null);
    const el = $('opt-' + id); if (el) el.scrollIntoView({ block: 'nearest' });
    if (!mqDesktop.matches && tab === 'library') toast(`Layer ${project.layers.findIndex(x => x.id === l.id) + 1} is now ${getStyle(id).name}`);
  }
  function stepStyle(d) { const i = STYLES.findIndex(s => s.id === active().styleId); selectStyle(STYLES[(i + d + STYLES.length) % STYLES.length].id); }

  // ---------- parameter rows ----------
  const fmtNum = (v, s) => { if (s.type === 'int') return `${Math.round(v).toLocaleString('en-US')}${s.unit || ''}`; const dec = s.step >= 1 ? 0 : s.step >= 0.1 ? 1 : 2; return `${Number(v).toFixed(dec)}${s.unit || ''}`; };
  const fmt = (v, s) => (s.type === 'range' || s.type === 'int' ? fmtNum(v, s) : s.type === 'toggle' ? (v ? 'On' : 'Off') : String(v));
  const toSlider = (v, s) => (s.log ? Math.round(((Math.log(v) - Math.log(s.min)) / (Math.log(s.max) - Math.log(s.min))) * 1000) : v);
  const fromSlider = (x, s) => { if (!s.log) return Number(x); let v = Math.exp(Math.log(s.min) + (x / 1000) * (Math.log(s.max) - Math.log(s.min))); const q = v < 1000 ? 10 : v < 10000 ? 100 : 1000; v = Math.round(v / q) * q; return clamp(v, s.min, s.max); };
  const uNow = () => fract(stage.time / project.finish.loop);
  function keyState(path) { const ks = project.keys[path]; if (!ks || !ks.length) return 'none'; return T.keyIndexAt(ks, uNow()) >= 0 ? 'on' : 'anim'; }
  const isMapped = path => !!(project.audio && project.audio.maps.some(m => m.path === path));
  function shownValue(path) { if (!project.keys[path]) return T.getBase(project, path); const ev = T.evaluate(project, stage.time, null); return valueFromEval(ev, path); }
  function valueFromEval(ev, path) { const p = T.parsePath(path); if (!p) return undefined; if (p.kind === 'F') return ev.finish[p.key]; const l = ev.layers.find(x => x.id === p.layer); if (!l) return undefined; return (p.scope === 'p' ? l.params : p.scope === 's' ? l.shared : l.comp)[p.key]; }
  const rid = path => 'r_' + path.replace(/[^a-z0-9]/gi, '_');
  function rowHtml(path, opts = {}) {
    const s = T.schemaAt(project, path); if (!s) return '';
    const v = shownValue(path), id = rid(path), ks = keyState(path), locked = locks.has(path), mapped = isMapped(path);
    const lockable = /^L:[^:]+:[ps]:/.test(path) && s.type !== 'text' && (s.mutate ?? 1) !== 0;
    const lock = lockable ? `<button class="ib lock" data-lock="${path}" aria-pressed="${locked}" aria-label="Lock ${s.label}" title="Lock from Mutate, Evolve and Randomize">${LOCK_SVG}</button>` : '<span></span>';
    const key = opts.nokey ? '<span></span>' : `<button class="ib kb" data-key="${path}" data-state="${ks}" aria-label="${ks === 'on' ? 'Remove key' : 'Add key'} for ${s.label}" title="${ks === 'none' ? 'Key this value at the playhead' : ks === 'on' ? 'Remove the key at the playhead' : 'Add a key at the playhead'}">${KEY_SVG}</button>`;
    const cls = `row${s.type === 'toggle' ? ' toggle' : ''}${locked ? ' locked' : ''}${mapped ? ' mapped' : ''}`;
    let note = '';
    if (s.cpuMax && v > s.cpuMax && !gpu.ready) note = `<span class="note warn">Canvas 2D draws ${s.cpuMax.toLocaleString('en-US')}; WebGPU draws all ${Math.round(v).toLocaleString('en-US')}.</span>`;
    else if (s.cpuMax && gpu.ready) note = `<span class="note">WebGPU · up to ${s.max.toLocaleString('en-US')}</span>`;
    if (s.type === 'range' || s.type === 'int') {
      const mn = s.log ? 0 : s.min, mx = s.log ? 1000 : s.max, st = s.log ? 1 : s.step;
      return `<div class="${cls}" data-row="${path}"><label for="${id}">${s.label}</label>${lock}${key}<output class="val${ks !== 'none' ? ' anim' : ''}" id="${id}-v">${fmt(v, s)}</output><input type="range" id="${id}" data-path="${path}" min="${mn}" max="${mx}" step="${st}" value="${toSlider(v, s)}">${note}</div>`;
    }
    if (s.type === 'select') return `<div class="${cls}" data-row="${path}"><label for="${id}">${s.label}</label>${lock}${key}<span></span><select id="${id}" data-path="${path}">${s.options.map(o => `<option value="${o.v}"${o.v === v ? ' selected' : ''}>${o.l}</option>`).join('')}</select></div>`;
    if (s.type === 'toggle') return `<div class="${cls}" data-row="${path}"><label for="${id}">${s.label}</label>${lock}${key}<input type="checkbox" class="switch" role="switch" id="${id}" data-path="${path}"${v ? ' checked' : ''}></div>`;
    return `<div class="${cls}" data-row="${path}"><label for="${id}">${s.label}</label><span></span>${key}<span></span><input type="text" id="${id}" data-path="${path}" maxlength="${s.max}" value="${esc(v)}" spellcheck="false"></div>`;
  }
  const openGroups = { style: true, comp: true, mask: false, motion: false, palette: true, editor: true, brand: false, output: true, time: true, blur: true, glow: true, lens: false, grade: false, texture: false, track: true, tempo: true, maps: true, live: false };
  const group = (id, title, body, extra = '') => `<details class="group" data-g="${id}"${openGroups[id] ? ' open' : ''}><summary><span class="lbl">${title}${extra}</span></summary><div class="rows">${body}</div></details>`;
  function readInput(el) { const s = T.schemaAt(project, el.dataset.path); if (!s) return undefined; if (s.type === 'toggle') return el.checked; if (s.type === 'range' || s.type === 'int') return fromSlider(el.value, s); return el.value; }
  // Edit a value: animated paths write a key at the playhead (auto-key), others set the base value.
  function applyValue(path, v) { return project.keys[path] ? T.setKey(project, path, uNow(), v) : T.setBase(project, path, v); }
  function bindRows(root) {
    root.addEventListener('input', e => {
      const el = e.target; if (!el.dataset || !el.dataset.path) return;
      const v = readInput(el); const s = T.schemaAt(project, el.dataset.path); if (v === undefined) return;
      live(applyValue(el.dataset.path, v));
      const out = $(el.id + '-v'); if (out) out.textContent = fmt(v, s);
      if (el.dataset.path === 'F:loop') syncAudioRegion();
    });
    root.addEventListener('change', e => { const el = e.target; if (!el.dataset || !el.dataset.path) return; const v = readInput(el); if (v === undefined) return; commit(applyValue(el.dataset.path, v)); });
    root.addEventListener('dblclick', e => { const el = e.target; if (el.type !== 'range' || !el.dataset.path) return; const s = T.schemaAt(project, el.dataset.path); commit(applyValue(el.dataset.path, s.def), `${s.label} reset`); });
    root.addEventListener('click', e => {
      const lk = e.target.closest('[data-lock]');
      if (lk) { const p = lk.dataset.lock; locks.has(p) ? locks.delete(p) : locks.add(p); lk.setAttribute('aria-pressed', locks.has(p)); lk.closest('.row').classList.toggle('locked', locks.has(p)); return; }
      const kb = e.target.closest('[data-key]');
      if (kb) toggleKey(kb.dataset.key);
    });
  }
  function toggleKey(path) {
    const s = T.schemaAt(project, path); if (!s) return;
    const ks = project.keys[path], u = uNow();
    if (!ks) { commit(T.setKey(project, path, u, T.getBase(project, path)), `Keyed ${s.label} at ${stage.time.toFixed(2)} s. Move the playhead and change it to animate.`); selKey = { path, idx: 0 }; return; }
    const i = T.keyIndexAt(ks, u);
    if (i >= 0) { commit(T.removeKey(project, path, i), project.keys[path].length === 1 ? `${s.label} is no longer animated` : 'Key removed'); selKey = null; }
    else { const v = shownValue(path); const next = T.setKey(project, path, u, v); commit(next, 'Key added'); selKey = { path, idx: T.keyIndexAt(project.keys[path], u) }; }
  }
  function updateAnimatedRows(t) {
    const root = $('panel-' + tab); if (!root || tab === 'looks') return;
    const paths = [...Object.keys(project.keys), ...(project.audio ? project.audio.maps.map(m => m.path) : [])]; if (!paths.length) return;
    const ev = T.evaluate(project, t, currentEnv());
    for (const path of new Set(paths)) {
      const el = $(rid(path)); if (!el || el === document.activeElement) continue;
      const s = T.schemaAt(project, path); const v = valueFromEval(ev, path); if (v === undefined) continue;
      if (s.type === 'range' || s.type === 'int') el.value = toSlider(v, s); else if (s.type === 'toggle') el.checked = !!v; else if (el.tagName === 'SELECT') el.value = v;
      const out = $(el.id + '-v'); if (out) out.textContent = fmt(v, s);
      const kb = el.closest('.row') && el.closest('.row').querySelector('.kb'); if (kb) kb.dataset.state = keyState(path);
    }
    if (tab === 'colour') { const pk = root.querySelector('[data-key$=":s:palette"]'); if (pk) pk.dataset.state = keyState(pk.dataset.key); }
  }

  // ---------- panels ----------
  ['layer', 'colour', 'finish', 'audio'].forEach(p => bindRows($('panel-' + p)));
  $('insp').addEventListener('toggle', e => { const d = e.target; if (d.dataset && d.dataset.g) openGroups[d.dataset.g] = d.open; }, true);
  function renderPanel() { if (tab === 'layer') renderLayerPanel(); else if (tab === 'colour') renderColourPanel(); else if (tab === 'finish') renderFinishPanel(); else if (tab === 'audio') renderAudioPanel(); else if (tab === 'looks') renderLooks(); }

  // Layers
  function renderLayerPanel() {
    const l = active(), st = getStyle(l.styleId), idx = project.layers.indexOf(l), n = project.layers.length;
    const cat = CATEGORIES.find(c => c.id === st.category).name;
    const list = project.layers.map((x, i) => ({ x, i })).reverse().map(({ x, i }) => `<li class="layer" role="option" tabindex="0" data-layer="${x.id}" aria-selected="${x.id === l.id}" data-hidden="${!x.visible}"><button class="ib eye" data-eye="${x.id}" aria-label="${x.visible ? 'Hide' : 'Show'} layer ${i + 1}" aria-pressed="${!x.visible}">${x.visible ? EYE_SVG : EYE_OFF_SVG}</button><canvas width="88" height="56" aria-hidden="true"></canvas><span class="t"><b>${i + 1} · ${getStyle(x.styleId).name}</b><small>${T.BLENDS.find(b => b.v === x.comp.blend).l} · ${Math.round(x.comp.opacity * 100)}%${x.comp.mask !== 'none' ? ' · mask' : ''}</small></span><span class="readout">${i === 0 ? 'base' : ''}</span></li>`).join('');
    const bottom = idx === 0;
    const compKeys = ['opacity', 'blend', ...(bottom ? [] : ['fill']), 'mask'];
    const maskKeys = l.comp.mask === 'none' ? [] : /^matte/.test(l.comp.mask) ? ['maskInvert'] : ['maskSize', 'maskFeather', 'maskX', 'maskY', ...(l.comp.mask === 'circle' ? [] : ['maskAngle']), 'maskInvert'];
    const matteNote = /^matte/.test(l.comp.mask) ? `<p class="info">${bottom ? 'A track matte needs a layer below this one.' : `Uses layer ${idx} as the matte. Hide layer ${idx} to see only the matted result.`}</p>` : '';
    $('panel-layer').innerHTML = `
      <div class="panel-head"><div class="lbl">Layer ${idx + 1} of ${n} · ${String(STYLES.indexOf(st) + 1).padStart(2, '0')} · ${cat}${st.gpu ? ` · ${gpu.ready ? 'WebGPU' : 'Canvas 2D'}` : ''}</div><h1>${st.name}</h1><p>${st.blurb}</p></div>
      <details class="group" data-g="layers" open><summary><span class="lbl">Layers <span class="count">${n}/${T.MAX_LAYERS}</span></span></summary>
        <ul class="layers" id="layerList" role="listbox" aria-label="Layers, top first">${list}</ul>
        <div class="layer-tools">
          <button class="btn sm" id="addLayer"${n >= T.MAX_LAYERS ? ' disabled' : ''}>+ Add</button><button class="btn sm" id="dupLayer"${n >= T.MAX_LAYERS ? ' disabled' : ''}>Duplicate</button>
          <button class="btn sm icon" id="upLayer" aria-label="Move layer up"${idx >= n - 1 ? ' disabled' : ''}>▲</button><button class="btn sm icon" id="downLayer" aria-label="Move layer down"${idx <= 0 ? ' disabled' : ''}>▼</button>
          <button class="btn sm" id="delLayer"${n <= 1 ? ' disabled' : ''}>Delete</button>
        </div>
      </details>
      ${group('style', 'Style', Object.keys(st.params).map(k => rowHtml(lpath('p', k))).join('') + '<div class="btnrow"><button class="btn sm" id="resetStyle">Reset style parameters</button></div>')}
      ${group('comp', 'Composite', compKeys.map(k => rowHtml(lpath('c', k))).join('') + (bottom ? '<p class="info">The base layer fills its palette background. Upper layers are transparent unless “Fill background” is on.</p>' : ''))}
      ${l.comp.mask !== 'none' ? group('mask', 'Mask', maskKeys.map(k => rowHtml(lpath('c', k))).join('') + matteNote) : ''}
      ${group('motion', 'Motion and transform', ['tempo', 'phase', 'seed', 'zoom', 'rotate'].map(k => rowHtml(lpath('s', k))).join(''))}`;
    $('panel-layer').querySelectorAll('#layerList canvas').forEach(c => { const x = T.layerById(project, c.closest('.layer').dataset.layer); renderThumb(pipeline, c, { ...x, shared: { ...x.shared, loop: project.finish.loop } }, 0.3, project.palettes); });
  }
  $('panel-layer').addEventListener('click', e => {
    const eye = e.target.closest('[data-eye]');
    if (eye) { const next = clone(project); const l = T.layerById(next, eye.dataset.eye); l.visible = !l.visible; commit(next, l.visible ? 'Layer shown' : 'Layer hidden'); return; }
    const li = e.target.closest('.layer'); if (li && !e.target.closest('button')) { selectLayer(li.dataset.layer); return; }
    const id = e.target.id;
    if (id === 'resetStyle') { doReset(); return; }
    if (id === 'addLayer') addLayer(); else if (id === 'dupLayer') dupLayer(); else if (id === 'delLayer') delLayer(); else if (id === 'upLayer') moveLayer(1); else if (id === 'downLayer') moveLayer(-1);
  });
  $('panel-layer').addEventListener('keydown', e => {
    const li = e.target.closest('.layer'); if (!li) return;
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); selectLayer(li.dataset.layer); }
    if (e.key === 'ArrowUp' || e.key === 'ArrowDown') { e.preventDefault(); const i = project.layers.findIndex(l => l.id === li.dataset.layer) + (e.key === 'ArrowUp' ? 1 : -1); if (project.layers[i]) { selectLayer(project.layers[i].id); const n = $('panel-layer').querySelector(`[data-layer="${project.layers[i].id}"]`); if (n) n.focus(); } }
  });
  function selectLayer(id) { if (project.active === id) return; project = { ...project, active: id }; history[cursor] = JSON.stringify(project); refresh(); }
  function addLayer() {
    if (project.layers.length >= T.MAX_LAYERS) return;
    const used = new Set(project.layers.map(l => l.styleId)); const pick = ['plexus', 'orbital-swarm', 'halftone', 'flow-field', 'kaleidoscope'].find(s => !used.has(s)) || 'plexus';
    const l = T.newLayer(pick, { ...active().shared }, { blend: 'screen', opacity: 0.9 });
    const next = clone(project); next.layers.push(l); next.active = l.id; commit(next, `Added layer ${next.layers.length}: ${getStyle(pick).name}. Pick a style in the library to change it.`);
  }
  function dupLayer() {
    if (project.layers.length >= T.MAX_LAYERS) return;
    const src = active(), next = clone(project), copy = T.newLayer(src.styleId); Object.assign(copy, { params: clone(src.params), shared: clone(src.shared), comp: clone(src.comp), visible: true });
    const i = next.layers.findIndex(l => l.id === src.id); next.layers.splice(i + 1, 0, copy); next.active = copy.id;
    for (const [p, ks] of Object.entries(project.keys)) if (p.startsWith(`L:${src.id}:`)) next.keys[p.replace(`L:${src.id}:`, `L:${copy.id}:`)] = clone(ks);
    commit(next, 'Layer duplicated');
  }
  function delLayer() {
    if (project.layers.length <= 1) return;
    const id = project.active, next = clone(project), i = next.layers.findIndex(l => l.id === id); next.layers.splice(i, 1);
    for (const p of Object.keys(next.keys)) if (p.startsWith(`L:${id}:`)) delete next.keys[p];
    if (next.audio) next.audio.maps = next.audio.maps.filter(m => !m.path.startsWith(`L:${id}:`));
    next.active = next.layers[Math.max(0, i - 1)].id; commit(next, 'Layer deleted');
  }
  function moveLayer(d) { const next = clone(project), i = next.layers.findIndex(l => l.id === project.active), j = i + d; if (j < 0 || j >= next.layers.length) return; [next.layers[i], next.layers[j]] = [next.layers[j], next.layers[i]]; commit(next, d > 0 ? 'Moved up' : 'Moved down'); }

  // Colour
  const curPalette = () => C.paletteById(active().shared.palette, project.palettes);
  const isCustom = id => project.palettes.some(p => p.id === id);
  let brandLib = store.get('motif-style-lab-2-brand') || [];
  function renderColourPanel() {
    const l = active(), pid = l.shared.palette, p = curPalette(), custom = isCustom(pid), locksP = custom ? new Set(p.locks) : new Set();
    const swatch = (x, tag) => `<button class="sw" role="radio" data-pal="${x.id}" aria-checked="${x.id === pid}" aria-label="${esc(x.name)}" title="${esc(x.name)}"><i style="background:${x.bg}"></i>${x.a.map(c => `<i style="background:${c}"></i>`).join('')}${tag ? `<b>${tag}</b>` : ''}</button>`;
    const ppath = lpath('s', 'palette'), pks = keyState(ppath);
    const slots = C.SLOTS.map(s => { const hex = C.slotsOf(p)[s]; const lk = locksP.has(s); return `<div class="slot${lk ? ' locked' : ''}"><input type="color" value="${hex.toLowerCase()}" data-slot="${s}" aria-label="${C.SLOT_LABELS[s]} colour"><span class="nm">${C.SLOT_LABELS[s]}</span><input type="text" value="${hex}" data-hex="${s}" maxlength="7" aria-label="${C.SLOT_LABELS[s]} hex" spellcheck="false"><button class="ib lock" data-plock="${s}" aria-pressed="${lk}" aria-label="Lock ${C.SLOT_LABELS[s]}" title="Locked colours survive Evolve, Harmonize and Extract">${LOCK_SVG}</button></div>`; }).join('');
    const cr = C.contrast(p.bg, p.ink); const grade = cr >= 7 ? 'AAA' : cr >= 4.5 ? 'AA' : cr >= 3 ? 'AA large' : 'fails';
    const spaceSeg = C.SPACES.map(s => `<button role="radio" data-space="${s.id}" aria-checked="${project.output.space === s.id}" title="${s.note}">${s.label}</button>`).join('');
    $('panel-colour').innerHTML = `
      <div class="panel-head"><div class="lbl">Layer ${project.layers.indexOf(l) + 1} · ${getStyle(l.styleId).name}</div><h1>Colour</h1><p>Palettes are per layer. Brand palettes travel with the project and your swatch library.</p></div>
      ${group('palette', 'Palette', `<div class="subhead"><span>${esc(p.name)}${custom ? ' · brand' : ''}</span><button class="ib kb" data-key="${ppath}" data-state="${pks}" aria-label="${pks === 'on' ? 'Remove' : 'Add'} palette key" title="Key the palette at the playhead — palette keys cross-fade unless set to Hold">${KEY_SVG}</button></div>
        <div class="swatches" role="radiogroup" aria-label="Palette">${PALETTES.map(x => swatch(x)).join('')}${project.palettes.map(x => swatch(x, 'brand')).join('')}</div>${rowHtml(lpath('s', 'invert'))}`)}
      ${group('editor', 'Palette editor', `<div class="slots">${slots}</div>
        <p class="contrast">Ink on background <b>${cr.toFixed(2)}:1</b> · ${grade}${custom ? '' : ' · editing a built-in palette makes a brand copy'}</p>
        ${custom ? `<label class="field"><span class="lbl">Name</span><input type="text" id="palName" value="${esc(p.name)}" maxlength="40" style="background:var(--surface-2);border:var(--hairline) solid var(--line);border-radius:var(--radius-s);padding:var(--space-2)"></label>` : ''}
        <div class="btnrow"><select id="harmScheme" aria-label="Harmony"><option value="triad">Triad</option><option value="analogous">Analogous</option><option value="complement">Complement</option></select><button class="btn sm" id="harmBtn">Harmonize</button><button class="btn sm" id="extractBtn">From image…</button></div>
        <div class="btnrow"><button class="btn sm" id="saveBrand">Save to swatch library</button>${custom ? '<button class="btn sm" id="delPal">Delete brand palette</button>' : ''}</div>`)}
      ${group('brand', 'Swatch library', brandLib.length ? `<div class="swatches">${brandLib.map((x, i) => `<button class="sw" data-brand="${i}" title="Use ${esc(x.name)}" aria-label="Use ${esc(x.name)}"><i style="background:${x.bg}"></i>${x.a.map(c => `<i style="background:${c}"></i>`).join('')}<b>${esc(x.name.slice(0, 10))}</b></button>`).join('')}</div><p class="info">Saved in this browser. Click to add one to this project.</p><button class="btn sm" id="clearBrand">Clear library</button>` : '<p class="info">Save brand palettes here to reuse them across projects.</p>', ` <span class="count">${brandLib.length}</span>`)}
      ${group('output', 'Output', `<div class="seg" role="radiogroup" aria-label="Output colour space" id="spaceSeg">${spaceSeg}</div>
        <p class="info">${C.spaceById(project.output.space).note}. ${project.output.space === 'p3' ? 'Renders in Display P3 and tags PNG and video; sRGB hex values stay exact.' : project.output.space === 'rec709' ? 'Tags video as BT.709, limited range. Pair with the broadcast-safe limiter.' : 'Standard web output.'}</p>
        <div class="toggles"><label><span>Broadcast-safe limiter</span><input type="checkbox" class="switch" role="switch" id="legalSw"${project.output.broadcastSafe ? ' checked' : ''}></label>
        <label><span>Show illegal colours (zebra, preview only)</span><input type="checkbox" class="switch" role="switch" id="zebraSw"${zebra ? ' checked' : ''}></label></div>`)}`;
  }
  function ensureCustom() {
    const l = active(); if (isCustom(l.shared.palette)) return { next: clone(project), pal: null };
    const next = clone(project), base = C.paletteById(l.shared.palette, next.palettes), cp = C.customFrom(base, `${base.name} brand`);
    next.palettes.push(cp); T.layerById(next, l.id).shared.palette = cp.id;
    for (const [path, ks] of Object.entries(next.keys)) if (path === `L:${l.id}:s:palette`) ks.forEach(k => { if (k.v === base.id) k.v = cp.id; });
    return { next, pal: cp };
  }
  function editPalette(fn, msg, liveOnly) {
    const { next } = ensureCustom(); const id = T.layerById(next, project.active).shared.palette;
    const i = next.palettes.findIndex(p => p.id === id); next.palettes[i] = fn(next.palettes[i]);
    if (liveOnly) { project = T.sanitizeProject(next, C.sanitizeCustom); stage.invalidate(); } else commit(next, msg);
  }
  const pc = $('panel-colour');
  pc.addEventListener('click', e => {
    const sw = e.target.closest('[data-pal]'); if (sw) { commit(applyValue(lpath('s', 'palette'), sw.dataset.pal)); drawThumbs(); return; }
    const pl = e.target.closest('[data-plock]'); if (pl) { const s = pl.dataset.plock; editPalette(p => ({ ...p, locks: p.locks.includes(s) ? p.locks.filter(x => x !== s) : [...p.locks, s] }), null); return; }
    const sp = e.target.closest('[data-space]'); if (sp) { const next = clone(project); next.output.space = sp.dataset.space; commit(next, `Output: ${C.spaceById(sp.dataset.space).label}`); stage.setSpace(project.output.space); return; }
    const br = e.target.closest('[data-brand]'); if (br) { const src = brandLib[Number(br.dataset.brand)]; const cp = C.sanitizeCustom({ ...src, id: undefined }); const next = clone(project); next.palettes.push(cp); commit(applyValueOn(next, lpath('s', 'palette'), cp.id), `Using ${cp.name}`); return; }
    const id = e.target.id;
    if (id === 'harmBtn') editPalette(p => C.harmonize(p, p.locks, $('harmScheme').value), 'Harmonized unlocked colours');
    if (id === 'extractBtn') $('imgFile').click();
    if (id === 'saveBrand') { const p = curPalette(); brandLib = [{ name: p.name, bg: p.bg, ink: p.ink, a: p.a.slice(), locks: p.locks || [] }, ...brandLib.filter(x => x.name !== p.name)].slice(0, 24); store.set('motif-style-lab-2-brand', brandLib); toast(`Saved ${p.name} to your swatch library`); renderColourPanel(); }
    if (id === 'delPal') { const pid = active().shared.palette, next = clone(project); next.palettes = next.palettes.filter(p => p.id !== pid); next.layers.forEach(l => { if (l.shared.palette === pid) l.shared.palette = 'signal'; }); for (const ks of Object.values(next.keys)) ks.forEach(k => { if (k.v === pid) k.v = 'signal'; }); commit(next, 'Brand palette deleted'); }
    if (id === 'clearBrand') { brandLib = []; store.set('motif-style-lab-2-brand', brandLib); renderColourPanel(); }
  });
  function applyValueOn(pr, path, v) { const saved = project; project = pr; const r = applyValue(path, v); project = saved; return r; }
  pc.addEventListener('input', e => {
    const s = e.target.dataset && e.target.dataset.slot;
    if (s) { const hex = C.normHex(e.target.value); editPalette(p => C.fromSlots({ ...C.slotsOf(p), [s]: hex }, { id: p.id, name: p.name, locks: p.locks }), null, true); const t = pc.querySelector(`[data-hex="${s}"]`); if (t) t.value = hex; }
  });
  pc.addEventListener('change', e => {
    const t = e.target;
    if (t.dataset.slot) { commit(project); renderColourPanel(); return; }
    if (t.dataset.hex) { if (!C.validHex(t.value)) { toast('Use a six-digit hex colour, like #2B44E0'); renderColourPanel(); return; } const s = t.dataset.hex, hex = C.normHex(t.value); editPalette(p => C.fromSlots({ ...C.slotsOf(p), [s]: hex }, { id: p.id, name: p.name, locks: p.locks }), null); return; } // token-lint-ignore (copy example)
    if (t.id === 'palName') { editPalette(p => ({ ...p, name: t.value.slice(0, 40) || p.name }), null); return; }
    if (t.id === 'legalSw') { const next = clone(project); next.output.broadcastSafe = t.checked; commit(next, t.checked ? 'Broadcast-safe limiter on' : 'Limiter off'); return; }
    if (t.id === 'zebraSw') { zebra = t.checked; stage.invalidate(); }
  });
  $('imgFile').addEventListener('change', async e => {
    const f = e.target.files && e.target.files[0]; e.target.value = ''; if (!f) return;
    try {
      const bmp = await createImageBitmap(f); const S = Math.min(1, 320 / Math.max(bmp.width, bmp.height));
      const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(bmp.width * S)); c.height = Math.max(1, Math.round(bmp.height * S));
      const x = c.getContext('2d', { willReadFrequently: true }); x.drawImage(bmp, 0, 0, c.width, c.height);
      const img = x.getImageData(0, 0, c.width, c.height); const rng = T.mulberry32(img.data.length);
      editPalette(p => ({ ...C.extractPalette(img, p, p.locks, rng), name: p.name.endsWith('brand') ? f.name.replace(/\.[^.]+$/, '').slice(0, 30) : p.name }), `Palette extracted from ${f.name}${curPalette().locks && curPalette().locks.length ? ' (locked colours kept)' : ''}`);
    } catch (err) { toast(`Couldn’t read that image: ${err.message || err}`); }
  });

  // Finish
  function renderFinishPanel() {
    const F = k => rowHtml(`F:${k}`);
    const fin = project.finish;
    $('panel-finish').innerHTML = `
      <div class="panel-head"><div class="lbl">Whole frame</div><h1>Finish</h1><p>Applied after the layers, in this order: motion blur, depth blur, chromatic offset, glow, levels, gradient map, vignette, grain, limiter.${pipeline.finisher.ok ? '' : ' WebGL2 is unavailable here, so only grain and vignette apply.'}</p></div>
      ${group('time', 'Loop', F('loop') + (project.audio && project.audio.snap ? `<p class="info">Snapped to ${project.audio.bars} bar${project.audio.bars > 1 ? 's' : ''} at ${project.audio.bpm} BPM. Change it in Audio.</p>` : ''))}
      ${group('blur', 'Motion blur', F('shutter') + `<div class="btnrow">${[0, 90, 180, 270, 360].map(a => `<button class="btn sm" data-shutter="${a}" aria-pressed="${fin.shutter === a}">${a ? a + '°' : 'Off'}</button>`).join('')}</div>` + F('samples') + `<p class="info">Preview uses up to ${$('quality').value === 'high' ? 8 : 4} samples while playing and all ${fin.samples} when paused. Export always uses ${fin.samples}. Shutter timing follows the export frame rate (${project.output.fps} fps).</p>`)}
      ${group('glow', 'Glow', F('glow') + F('glowThreshold') + F('glowRadius'))}
      ${group('lens', 'Lens', F('chroma') + F('depth') + F('depthMode') + F('focus') + '<p class="info">Depth is estimated from screen position or brightness until styles output real depth.</p>')}
      ${group('grade', 'Grade', F('black') + F('white') + F('gamma') + F('gmap') + F('gmapMode'))}
      ${group('texture', 'Texture', F('grain') + F('vignette'))}`;
  }
  $('panel-finish').addEventListener('click', e => { const b = e.target.closest('[data-shutter]'); if (b) commit(applyValue('F:shutter', Number(b.dataset.shutter)), Number(b.dataset.shutter) ? `Shutter ${b.dataset.shutter}°` : 'Motion blur off'); });

  // Audio
  let tapTimes = [];
  function renderAudioPanel() {
    const au = project.audio, has = !!player.buffer;
    const bars = au ? au.bars : 4, bpm = au ? au.bpm : 120;
    const maps = au ? au.maps : [];
    const targets = T.allPaths(project, true); const groups = [...new Set(targets.map(t => t.group))];
    const targetSel = (m) => `<select data-mapf="path" data-map="${m.id}" aria-label="Target parameter">${groups.map(g => `<optgroup label="${esc(g)}">${targets.filter(t => t.group === g).map(t => `<option value="${t.path}"${t.path === m.path ? ' selected' : ''}>${esc(t.label)}</option>`).join('')}</optgroup>`).join('')}</select>`;
    const bandSel = (m) => `<select data-mapf="band" data-map="${m.id}" aria-label="Audio band">${T.BANDS.map(b => `<option value="${b.id}"${b.id === m.band ? ' selected' : ''}>${b.l}</option>`).join('')}</select>`;
    const mapRows = maps.map(m => `<div class="map">${bandSel(m)}${targetSel(m)}<button class="ib" data-unmap="${m.id}" aria-label="Remove mapping" style="opacity:1">✕</button>
      <div class="full"><span>Amount</span><input type="range" min="-1" max="1" step="0.01" value="${m.amount}" data-mapf="amount" data-map="${m.id}" aria-label="Amount"><output class="readout">${m.amount.toFixed(2)}</output></div>
      <div class="full"><span>Smooth</span><input type="range" min="0" max="1" step="0.01" value="${m.smooth}" data-mapf="smooth" data-map="${m.id}" aria-label="Smoothing"><output class="readout">${Math.round(m.smooth * 600)} ms</output></div></div>`).join('');
    $('panel-audio').innerHTML = `
      <div class="panel-head"><div class="lbl">Sync</div><h1>Audio</h1><p>Load a track to lock the loop to bars and drive any parameter from its bands. Everything renders deterministically, so exports match the preview.</p></div>
      ${group('track', 'Track', `<div class="btnrow"><button class="btn sm${has ? '' : ' primary'}" id="loadAudio">${has ? 'Replace track…' : 'Load track…'}</button>${has ? `<button class="btn sm" id="audioPlay">${player.playing ? 'Stop' : 'Play from loop start'}</button>` : ''}</div>
        <p class="info" id="audioStatus">${has ? `<b>${esc(trackName)}</b> · ${player.buffer.duration.toFixed(1)} s${analysis ? ` · detected ${analysis.bpm} BPM (confidence ${(analysis.confidence * 100).toFixed(0)}%)` : ''}` : au && au.name ? `This project was built with <b>${esc(au.name)}</b>. Load it again to hear and drive it.` : 'MP3, WAV, AAC, OGG or FLAC. The file stays in your browser.'}</p>
        ${has ? `<canvas class="wave" id="wave" width="600" height="64" aria-label="Waveform: drag to set where the loop starts"></canvas><div class="row"><span class="rl">Loop starts at</span><span></span><span></span><output class="val">${(au ? au.offset : 0).toFixed(2)} s</output></div>
        <div class="toggles"><label><span>Play audio with the transport</span><input type="checkbox" class="switch" role="switch" id="audioSync"${audioSync ? ' checked' : ''}></label></div>
        <div class="row"><label for="vol">Volume</label><span></span><span></span><span></span><input type="range" id="vol" min="0" max="1" step="0.01" value="0.8"></div>` : ''}`)}
      ${group('tempo', 'Tempo and bars', `<div class="row"><label for="bpmIn">BPM</label><span></span><span></span><span></span><input type="number" id="bpmIn" min="40" max="240" step="0.1" value="${bpm}" style="grid-column:1/-1;background:var(--surface-2);border:var(--hairline) solid var(--line);border-radius:var(--radius-s);padding:var(--space-2);font-family:var(--font-mono)"></div>
        <div class="btnrow"><button class="btn sm" id="bpmHalf">÷2</button><button class="btn sm" id="bpmDouble">×2</button><button class="btn sm" id="tapBtn">Tap</button>${analysis ? '<button class="btn sm" id="alignBtn">Align start to downbeat</button>' : ''}</div>
        <div class="subhead"><span>Loop length in bars (4/4)</span></div>
        <div class="seg" role="radiogroup" aria-label="Bars" id="barsSeg">${[1, 2, 4, 8].map(b => `<button role="radio" data-bars="${b}" aria-checked="${bars === b}">${b}</button>`).join('')}</div>
        <div class="toggles"><label><span>Snap loop to bars (${A.barsToSeconds(bpm, bars).toFixed(2)} s)</span><input type="checkbox" class="switch" role="switch" id="snapSw"${au && au.snap ? ' checked' : ''}></label></div>`)}
      ${group('maps', 'Band mappings', `<div class="meters" id="meters" aria-hidden="true">${A.BAND_IDS.map(() => '<i></i>').join('')}</div><div class="meter-l" aria-hidden="true"><span>sub</span><span>bass</span><span>lo-m</span><span>mid</span><span>hi-m</span><span>high</span><span>lvl</span><span>ons</span></div>
        <div class="maps">${mapRows || '<p class="info">No mappings yet. Map bass to a burst or size, highs to glow.</p>'}</div><button class="btn sm" id="addMap"${maps.length >= 16 ? ' disabled' : ''}>+ Add mapping</button>`, maps.length ? ` <span class="count">${maps.length}</span>` : '')}
      ${group('live', 'Live input', `<div class="toggles"><label><span>Drive from microphone or line in</span><input type="checkbox" class="switch" role="switch" id="liveSw"${liveOn ? ' checked' : ''}></label></div><p class="info">Live input drives the preview only. Exports use the loaded track.</p>`)}`;
    drawWave();
  }
  function ensureAudio(next) { if (!next.audio) next.audio = { bpm: analysis ? analysis.bpm : 120, bars: 4, offset: analysis ? analysis.beatOffset : 0, snap: true, name: trackName, maps: [] }; return next.audio; }
  function snapLoop(next) { const au = next.audio; if (au && au.snap) next.finish.loop = clamp(A.barsToSeconds(au.bpm, au.bars), 1, 32); return next; }
  function drawWave() {
    const c = $('wave'); if (!c || !analysis) return; const x = c.getContext('2d'), W = c.width, H = c.height, pk = analysis.peaks, dur = analysis.duration;
    const cs = getComputedStyle(document.documentElement);
    x.clearRect(0, 0, W, H); x.fillStyle = cs.getPropertyValue('--line-strong'); // chrome colours come from tokens
    for (let i = 0; i < W; i++) { const v = pk[Math.floor((i / W) * pk.length)] * H * 0.9; x.fillRect(i, (H - v) / 2, 1, Math.max(1, v)); }
    const au = project.audio; if (!au) return; const L = project.finish.loop;
    x.fillStyle = cs.getPropertyValue('--accent-soft'); x.fillRect((au.offset / dur) * W, 0, (L / dur) * W, H);
    x.fillStyle = cs.getPropertyValue('--accent'); x.fillRect((au.offset / dur) * W, 0, 2, H);
    const beat = 60 / au.bpm; x.fillStyle = cs.getPropertyValue('--text-muted');
    for (let b = au.offset; b < au.offset + L; b += beat) x.fillRect((b / dur) * W, H - 6, 1, 6);
  }
  function syncAudioRegion() { if (player.buffer && project.audio) player.setRegion(project.audio.offset, project.finish.loop); updateBpmChip(); }
  function updateBpmChip() { const c = $('bpmChip'); if (project.audio) { c.hidden = false; c.dataset.state = 'bpm'; c.textContent = `${project.audio.bpm} BPM · ${project.audio.bars} bar${project.audio.bars > 1 ? 's' : ''}`; } else c.hidden = true; }
  function updateMeters(t) {
    const m = $('meters'); if (!m) return; const env = currentEnv(); const at = (project.audio ? project.audio.offset : 0) + t;
    m.querySelectorAll('i').forEach((el, i) => { const v = env ? env(A.BAND_IDS[i], at, 0) : 0; el.style.setProperty('--v', (v || 0).toFixed(3)); });
  }
  async function loadAudio(arrayBuf, name) {
    const st = $('audioStatus'); if (st) st.textContent = 'Decoding…';
    try {
      const buf = await player.decode(arrayBuf); trackName = name;
      const an = await A.analyse(buf, (f, msg) => { const s = $('audioStatus'); if (s) s.textContent = `${msg || 'Analysing bands'} · ${Math.round(f * 100)}%`; });
      analysis = an; envFn = A.makeEnv(an);
      const next = clone(project); const had = !!next.audio; const au = ensureAudio(next);
      au.name = name; au.bpm = an.bpm; au.offset = an.beatOffset; au.snap = true;
      if (!had) { const L = next.finish.loop; au.bars = [1, 2, 4, 8].reduce((b, x) => (Math.abs(A.barsToSeconds(an.bpm, x) - L) < Math.abs(A.barsToSeconds(an.bpm, b) - L) ? x : b), 4); }
      if (!au.maps.length) { const l = T.layerById(next, next.active); const k = Object.entries(getStyle(l.styleId).params).find(([, s]) => s.type === 'range'); if (k) au.maps.push({ id: 'm1', band: 'bass', path: `L:${l.id}:p:${k[0]}`, amount: 0.35, smooth: 0.3 }); }
      snapLoop(next); commit(next, `${name}: ${an.bpm} BPM, loop snapped to ${au.bars} bars`);
      if (!stage.playing) togglePlay(); else if (audioSync) player.start(stage.time);
      renderAudioPanel();
    } catch (e) { const s = $('audioStatus'); if (s) s.textContent = `Couldn’t read that audio file (${e.message || e}).`; toast('Couldn’t read that audio file'); }
  }
  $('audioFile').addEventListener('change', async e => { const f = e.target.files && e.target.files[0]; e.target.value = ''; if (!f) return; await loadAudio(await f.arrayBuffer(), f.name); });
  const pa = $('panel-audio');
  pa.addEventListener('click', e => {
    const id = e.target.id;
    const um = e.target.closest('[data-unmap]'); if (um) { const next = clone(project); next.audio.maps = next.audio.maps.filter(m => m.id !== um.dataset.unmap); commit(next, 'Mapping removed'); renderAudioPanel(); return; }
    const bb = e.target.closest('[data-bars]'); if (bb) { const next = clone(project); ensureAudio(next).bars = Number(bb.dataset.bars); snapLoop(next); commit(next); renderAudioPanel(); return; }
    if (id === 'loadAudio') $('audioFile').click();
    if (id === 'audioPlay') { if (player.playing) { player.stop(); stage.pause(); setPlayUi(false); } else { stage.seek(0); stage.play(); setPlayUi(true); player.start(0); } renderAudioPanel(); }
    if (id === 'bpmHalf' || id === 'bpmDouble') { const next = clone(project); const au = ensureAudio(next); au.bpm = clamp(Math.round(au.bpm * (id === 'bpmHalf' ? 0.5 : 2) * 10) / 10, 40, 240); snapLoop(next); commit(next, `${au.bpm} BPM`); renderAudioPanel(); }
    if (id === 'tapBtn') { const now = performance.now(); tapTimes = tapTimes.filter(t => now - t < 3000); tapTimes.push(now); if (tapTimes.length >= 3) { const d = (tapTimes[tapTimes.length - 1] - tapTimes[0]) / (tapTimes.length - 1); const next = clone(project); const au = ensureAudio(next); au.bpm = Math.round(60000 / d * 10) / 10; snapLoop(next); commit(next, `Tapped ${au.bpm} BPM`); renderAudioPanel(); } else toast('Keep tapping…'); }
    if (id === 'alignBtn' && analysis) { const next = clone(project); const au = ensureAudio(next); const beat = 60 / au.bpm; au.offset = Math.max(0, analysis.beatOffset + Math.round((au.offset - analysis.beatOffset) / (beat * 4)) * beat * 4); commit(next, `Loop starts on a downbeat at ${au.offset.toFixed(2)} s`); renderAudioPanel(); }
    if (id === 'addMap') { const next = clone(project); const au = ensureAudio(next); const l = T.layerById(next, next.active); const k = Object.entries(getStyle(l.styleId).params).find(([, s]) => s.type === 'range' || s.type === 'int'); au.maps.push({ id: 'm' + Date.now().toString(36), band: ['bass', 'high', 'onset', 'mid', 'level', 'sub'][au.maps.length % 6], path: k ? `L:${l.id}:p:${k[0]}` : 'F:glow', amount: 0.3, smooth: 0.25 }); commit(next, 'Mapping added'); renderAudioPanel(); }
  });
  pa.addEventListener('input', e => {
    const t = e.target;
    if (t.dataset.mapf === 'amount' || t.dataset.mapf === 'smooth') { const next = clone(project); const m = next.audio.maps.find(x => x.id === t.dataset.map); m[t.dataset.mapf] = Number(t.value); live(next); const o = t.parentElement.querySelector('output'); if (o) o.textContent = t.dataset.mapf === 'amount' ? Number(t.value).toFixed(2) : `${Math.round(t.value * 600)} ms`; }
    if (t.id === 'vol') player.setVolume(Number(t.value));
  });
  pa.addEventListener('change', async e => {
    const t = e.target;
    if (t.dataset.mapf) { const next = clone(project); const m = next.audio.maps.find(x => x.id === t.dataset.map); m[t.dataset.mapf] = t.dataset.mapf === 'amount' || t.dataset.mapf === 'smooth' ? Number(t.value) : t.value; commit(next); if (t.tagName === 'SELECT') renderAudioPanel(); return; }
    if (t.id === 'bpmIn') { const v = Number(t.value); if (!(v >= 40 && v <= 240)) { toast('Tempo must be 40–240 BPM'); renderAudioPanel(); return; } const next = clone(project); ensureAudio(next).bpm = v; snapLoop(next); commit(next); renderAudioPanel(); }
    if (t.id === 'snapSw') { const next = clone(project); ensureAudio(next).snap = t.checked; snapLoop(next); commit(next, t.checked ? `Loop snapped to ${next.audio.bars} bars` : 'Loop length is free'); renderAudioPanel(); }
    if (t.id === 'audioSync') { audioSync = t.checked; if (!audioSync) player.stop(); else if (stage.playing) player.start(stage.time); }
    if (t.id === 'liveSw') {
      if (t.checked) { try { await player.startLive(); liveOn = true; if (!project.audio) { const next = clone(project); ensureAudio(next); commit(next); } toast('Live input on — preview only'); } catch (err) { t.checked = false; toast(`Live input unavailable: ${err.message || err}`); } }
      else { player.stopLive(); liveOn = false; toast('Live input off'); }
      renderAudioPanel();
    }
  });
  let waveDrag = false;
  function waveSeek(e) { const c = $('wave'); if (!c || !analysis) return; const r = c.getBoundingClientRect(); const f = clamp((e.clientX - r.left) / r.width); const next = clone(project); const au = ensureAudio(next); const beat = 60 / au.bpm; let off = f * analysis.duration; off = Math.max(0, analysis.beatOffset + Math.round((off - analysis.beatOffset) / beat) * beat); au.offset = Math.min(off, Math.max(0, analysis.duration - next.finish.loop)); live(next); syncAudioRegion(); drawWave(); }
  pa.addEventListener('pointerdown', e => { if (e.target.id !== 'wave') return; waveDrag = true; e.target.setPointerCapture(e.pointerId); waveSeek(e); });
  pa.addEventListener('pointermove', e => { if (waveDrag) waveSeek(e); });
  pa.addEventListener('pointerup', () => { if (waveDrag) { waveDrag = false; commit(project, `Loop starts at ${project.audio.offset.toFixed(2)} s`); renderAudioPanel(); } });

  // ---------- key lane ----------
  let laneCollapsed = matchMedia('(max-width: 40em)').matches;
  function laneRows() {
    const order = p => { const x = T.parsePath(p); if (!x) return 99; return x.kind === 'F' ? 50 : project.layers.findIndex(l => l.id === x.layer); };
    const keyed = Object.keys(project.keys).sort((a, b) => order(b) - order(a) || a.localeCompare(b));
    const mapped = project.audio ? [...new Set(project.audio.maps.map(m => m.path))].filter(p => !project.keys[p]) : [];
    return { keyed, mapped };
  }
  function renderLane() { renderLaneHead(); renderLaneRows(); }
  function renderLaneHead() {
    const { keyed } = laneRows(); const n = keyed.reduce((a, p) => a + project.keys[p].length, 0);
    if (selKey && (!project.keys[selKey.path] || !project.keys[selKey.path][selKey.idx])) selKey = null;
    let editor = '';
    if (selKey) {
      const s = T.schemaAt(project, selKey.path), k = project.keys[selKey.path][selKey.idx];
      const valueCtl = (s.type === 'range' || s.type === 'int') ? `<input type="number" id="kVal" value="${+Number(k.v).toFixed(3)}" min="${s.min}" max="${s.max}" step="${s.log ? 1 : s.step}" aria-label="Key value">` : s.dynamic ? `<select id="kVal" aria-label="Key palette">${[...PALETTES, ...project.palettes].map(o => `<option value="${o.id}"${o.id === k.v ? ' selected' : ''}>${esc(o.name)}</option>`).join('')}</select>` : s.type === 'select' ? `<select id="kVal" aria-label="Key value">${s.options.map(o => `<option value="${o.v}"${o.v === k.v ? ' selected' : ''}>${o.l}</option>`).join('')}</select>` : s.type === 'toggle' ? `<select id="kVal" aria-label="Key value"><option value="1"${k.v ? ' selected' : ''}>On</option><option value="0"${!k.v ? ' selected' : ''}>Off</option></select>` : `<span class="readout">${esc(k.v)}</span>`;
      const easeCtl = (s.type === 'range' || s.type === 'int' || s.dynamic) ? `<select id="kEase" aria-label="Ease to next key">${T.EASES.map(o => `<option value="${o.v}"${o.v === k.e ? ' selected' : ''}>${o.l}</option>`).join('')}</select>` : '<span class="readout">Hold</span>';
      editor = `<span class="readout">${esc(T.pathLabel(project, selKey.path))} @ ${(k.u * project.finish.loop).toFixed(2)} s</span>${valueCtl}${easeCtl}<button class="btn sm" id="kDel">Delete key</button>`;
    }
    $('laneHead').innerHTML = `<button class="btn sm" id="laneToggle" aria-expanded="${!laneCollapsed}" aria-controls="laneRows">${laneCollapsed ? '▸' : '▾'} Keys</button><span class="readout">${n ? `${n} key${n > 1 ? 's' : ''} · ${keyed.length} param${keyed.length > 1 ? 's' : ''}` : 'none yet'}</span><span class="grow"></span>${editor || '<span class="readout lane-extra">◇ on any row keys it · drag keys · click the track to seek</span>'}`;
    $('lane').dataset.collapsed = laneCollapsed;
  }
  function renderLaneRows() {
    const { keyed, mapped } = laneRows();
    const bandsFor = p => project.audio ? project.audio.maps.filter(x => x.path === p).map(x => x.band).join(', ') : '';
    const rows = keyed.map(p => { const ks = project.keys[p]; const lab = T.pathLabel(project, p); const bands = bandsFor(p); return `<div class="lrow" data-lpath="${p}"><span class="nm" title="${esc(lab)}${bands ? ' + audio ' + bands : ''}">${esc(lab)}${bands ? ` <small>∿ ${bands}</small>` : ''}</span><div class="track" data-track="${p}">${ks.map((k, i) => `<button class="kf" style="left:${(k.u * 100).toFixed(3)}%" data-kp="${p}" data-ki="${i}" data-ease="${k.e}" aria-pressed="${!!(selKey && selKey.path === p && selKey.idx === i)}" aria-label="${esc(lab)} key ${i + 1} at ${(k.u * project.finish.loop).toFixed(2)} seconds"></button>`).join('')}</div><button class="ib" data-clear="${p}" aria-label="Remove all keys for ${esc(lab)}" title="Remove all keys" style="opacity:.8">✕</button></div>`; }).join('');
    const maps = mapped.map(p => { const lab = T.pathLabel(project, p); const m = project.audio.maps.filter(x => x.path === p).map(x => x.band).join(', '); return `<div class="lrow"><span class="nm" title="${esc(lab)}">${esc(lab)} <small>∿ ${m}</small></span><div class="track" data-track="${p}" data-env="${p}"><canvas width="300" height="20"></canvas></div><span></span></div>`; }).join('');
    $('laneRows').innerHTML = rows + maps || '<p class="lane-empty">Press ◇ beside any parameter to key it. Keys loop seamlessly: the last key eases back to the first.</p>';
    drawEnvRows();
  }
  function drawEnvRows() {
    if (!envFn || !project.audio) return; const cs = getComputedStyle(document.documentElement);
    $('laneRows').querySelectorAll('[data-env] canvas').forEach(c => {
      const p = c.parentElement.dataset.env; const ms = project.audio.maps.filter(m => m.path === p); const x = c.getContext('2d'); x.clearRect(0, 0, c.width, c.height); x.fillStyle = cs.getPropertyValue('--lock');
      for (let i = 0; i < c.width; i++) { let v = 0; for (const m of ms) v = Math.max(v, envFn(m.band, project.audio.offset + (i / c.width) * project.finish.loop, m.smooth) * Math.abs(m.amount) * 2); const hh = Math.min(1, v) * c.height; x.fillRect(i, c.height - hh, 1, hh); }
    });
  }
  let drag = null;
  $('lane').addEventListener('pointerdown', e => {
    const kf = e.target.closest('.kf');
    if (kf) { e.preventDefault(); selKey = { path: kf.dataset.kp, idx: Number(kf.dataset.ki) }; drag = { el: kf, track: kf.parentElement, moved: false, id: e.pointerId }; kf.setPointerCapture(e.pointerId); renderLaneHead(); markSelected(); return; }
    const tr = e.target.closest('.track'); if (tr) { const r = tr.getBoundingClientRect(); seekFrac(clamp((e.clientX - r.left) / r.width, 0, 0.9999)); if (!stage.playing) refreshRowsOnly(); }
  });
  $('lane').addEventListener('pointermove', e => {
    if (!drag) return; const r = drag.track.getBoundingClientRect(); let u = clamp((e.clientX - r.left) / r.width, 0, 0.99999);
    const fr = 1 / (project.finish.loop * project.output.fps); if (!e.shiftKey) u = Math.round(u / fr) * fr;
    const res = T.moveKey(project, selKey.path, selKey.idx, u); if (!res.project) return;
    project = res.project; selKey.idx = res.index; drag.moved = true; drag.el.style.left = (u * 100).toFixed(3) + '%'; drag.el.dataset.ki = res.index; stage.invalidate(); renderLaneHead();
  });
  $('lane').addEventListener('pointerup', () => { if (!drag) return; const moved = drag.moved; drag = null; if (moved) commit(project, 'Key moved'); else renderLane(); });
  $('lane').addEventListener('dblclick', e => {
    const tr = e.target.closest('.track'); if (!tr || e.target.closest('.kf') || tr.dataset.env) return;
    const r = tr.getBoundingClientRect(); const u = clamp((e.clientX - r.left) / r.width, 0, 0.9999); const p = tr.dataset.track;
    const ev = T.evaluate(project, u * project.finish.loop, null); commit(T.setKey(project, p, u, valueFromEval(ev, p)), 'Key added');
  });
  $('lane').addEventListener('click', e => {
    const id = e.target.id;
    if (id === 'laneToggle') { laneCollapsed = !laneCollapsed; renderLane(); return; }
    if (id === 'kDel' && selKey) { commit(T.removeKey(project, selKey.path, selKey.idx), 'Key removed'); selKey = null; renderLane(); return; }
    const cl = e.target.closest('[data-clear]'); if (cl) { commit(T.clearKeys(project, cl.dataset.clear), `${T.pathLabel(project, cl.dataset.clear)} is no longer animated`); }
  });
  $('lane').addEventListener('change', e => {
    if (!selKey) return; const ks = project.keys[selKey.path]; if (!ks) return; const k = ks[selKey.idx]; const s = T.schemaAt(project, selKey.path);
    if (e.target.id === 'kEase') { const next = clone(project); next.keys[selKey.path][selKey.idx].e = e.target.value; commit(next, `Ease: ${e.target.selectedOptions[0].textContent}`); }
    if (e.target.id === 'kVal') { let v = e.target.value; if (s.type === 'range' || s.type === 'int') v = Number(v); if (s.type === 'toggle') v = v === '1'; commit(T.setKey(project, selKey.path, k.u, v, k.e), 'Key value set'); }
  });
  $('lane').addEventListener('keydown', e => {
    const kf = e.target.closest('.kf'); if (!kf) return;
    const path = kf.dataset.kp, idx = Number(kf.dataset.ki);
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); selKey = { path, idx }; renderLane(); focusKey(); }
    if (e.key === 'Delete' || e.key === 'Backspace') { e.preventDefault(); commit(T.removeKey(project, path, idx), 'Key removed'); selKey = null; }
    if ((e.key === 'ArrowLeft' || e.key === 'ArrowRight') && e.altKey) { e.preventDefault(); e.stopPropagation(); const fr = 1 / (project.finish.loop * project.output.fps); const k = project.keys[path][idx]; const res = T.moveKey(project, path, idx, k.u + (e.key === 'ArrowRight' ? fr : -fr) * (e.shiftKey ? 10 : 1)); selKey = { path, idx: res.index }; commit(res.project); focusKey(); }
  });
  function focusKey() { if (!selKey) return; const b = $('laneRows').querySelector(`.kf[data-kp="${selKey.path}"][data-ki="${selKey.idx}"]`); if (b) b.focus(); }
  function markSelected() { $('laneRows').querySelectorAll('.kf').forEach(b => b.setAttribute('aria-pressed', !!(selKey && b.dataset.kp === selKey.path && Number(b.dataset.ki) === selKey.idx))); }
  function refreshRowsOnly() { updateAnimatedRows(stage.time); const root = $('panel-' + tab); if (root) root.querySelectorAll('.kb').forEach(b => { b.dataset.state = keyState(b.dataset.key); }); }

  // ---------- mutate / evolve ----------
  function flash(keys) { const root = $('panel-layer'); for (const k of keys) { const r = root.querySelector(`.row[data-row="${lpath('p', k)}"], .row[data-row="${lpath('s', k)}"]`); if (r) { r.classList.add('flash'); setTimeout(() => r.classList.remove('flash'), 240); } } }
  const lockKeys = () => { const pre = `L:${project.active}:`; return new Set([...locks].filter(p => p.startsWith(pre)).map(p => p.split(':')[3])); };
  let rngSeed = (Date.now() % 100000) + 1; const nextRng = () => T.mulberry32(rngSeed++ * 7919);
  function doMutate() { const r = T.mutateProject(project, project.active, strength, lockKeys(), nextRng(), false); commit(r.project, `Mutated ${r.changed.length} parameters on layer ${project.layers.findIndex(l => l.id === project.active) + 1}`); if (tab === 'layer') flash(r.changed); }
  function doRandom() { const r = T.randomizeProject(project, project.active, lockKeys(), nextRng()); commit(r.project, 'Randomized'); if (tab === 'layer') flash(r.changed); }
  function doReset() { const next = clone(project); const l = T.layerById(next, next.active); l.params = T.newLayer(l.styleId).params; for (const p of Object.keys(next.keys)) if (p.startsWith(`L:${l.id}:p:`)) delete next.keys[p]; commit(next, 'Style parameters reset'); }
  $('mutateBtn').addEventListener('click', doMutate); $('randomBtn').addEventListener('click', doRandom); $('resetBtn').addEventListener('click', doReset);
  $('undoBtn').addEventListener('click', undo); $('redoBtn').addEventListener('click', redo);
  $('strength').addEventListener('input', e => { strength = Number(e.target.value); $('strengthVal').textContent = strength.toFixed(2); $('evoStrength').value = strength; });

  const evoGrid = $('evoGrid');
  function breedChild(rng, colour) {
    const r = T.mutateProject(project, project.active, strength, lockKeys(), rng, false); const next = r.project; const l = T.layerById(next, next.active);
    if (colour && !locks.has(lpath('s', 'palette')) && !project.keys[lpath('s', 'palette')]) {
      const cur = C.paletteById(l.shared.palette, next.palettes);
      if (isCustom(l.shared.palette)) { const np = C.mutatePalette(cur, cur.locks, strength, rng); const cp = C.sanitizeCustom({ ...np, id: undefined, name: `${cur.name.replace(/ var$/, '')} var` }); next.palettes.push(cp); l.shared.palette = cp.id; }
      else { const opts = PALETTES.filter(p => p.id !== cur.id); l.shared.palette = opts[Math.floor(rng() * opts.length)].id; }
    }
    return next;
  }
  function breed() {
    round++; $('evolveTitle').textContent = `Evolve — round ${round}`;
    const colour = $('evoColour').checked; children = Array.from({ length: 6 }, () => breedChild(nextRng(), colour));
    const pl = curPalette(); $('evoHint').textContent = `Variations of layer ${project.layers.findIndex(l => l.id === project.active) + 1}.${colour && isCustom(active().shared.palette) ? ` Colour varies ${pl.name}, keeping ${pl.locks.length ? 'its locked colours' : 'its structure'}.` : ''} Pick one to keep it. Press 1–6, or Esc to close.`;
    evoGrid.innerHTML = children.map((c, i) => `<button class="child" data-i="${i}" aria-label="Keep variation ${i + 1}"><canvas></canvas><span>${i + 1}</span></button>`).join('');
    layoutChildren(); drawChildren(stage.time);
  }
  function layoutChildren() { const ar = exportSize(aspect, 720); const cols = matchMedia('(max-width: 40em)').matches ? 2 : 3; const cw = Math.max(80, Math.floor($('stageHost').clientWidth / cols) - 16); evoGrid.querySelectorAll('canvas').forEach(c => { c.width = Math.min(cw, 360); c.height = Math.round(c.width * ar.h / ar.w); }); }
  function drawChildren(t) { evoGrid.querySelectorAll('canvas').forEach((c, i) => { if (children[i]) renderProjectThumb(pipeline, c, children[i], t); }); }
  function openEvolve() { if (evolveOpen) return; lastFocus = document.activeElement; evolveOpen = true; round = 0; $('evolve').hidden = false; breed(); const f = evoGrid.querySelector('.child'); if (f) f.focus(); }
  function closeEvolve() { evolveOpen = false; $('evolve').hidden = true; evoGrid.innerHTML = ''; if (lastFocus && lastFocus.focus) lastFocus.focus(); }
  function keep(i) {
    if (!children[i]) return; const c = children[i]; closeEvolve();
    const used = new Set([...c.layers.map(l => l.shared.palette), ...Object.values(c.keys).flat().map(k => k.v)]);
    c.palettes = c.palettes.filter(p => !/ var$/.test(p.name) || used.has(p.id));
    commit(c, `Kept variation ${i + 1}`);
  }
  $('evolveBtn').addEventListener('click', openEvolve); $('evoClose').addEventListener('click', closeEvolve); $('evoAgain').addEventListener('click', breed);
  $('evoStrength').addEventListener('input', e => { strength = Number(e.target.value); $('strength').value = strength; $('strengthVal').textContent = strength.toFixed(2); });
  evoGrid.addEventListener('click', e => { const b = e.target.closest('.child'); if (b) keep(Number(b.dataset.i)); });

  // ---------- saved looks ----------
  let saved = store.get('motif-style-lab-2-looks') || [];
  function renderLooks() {
    $('looks').innerHTML = saved.map((s, i) => `<div class="look" role="button" tabindex="0" data-i="${i}" aria-label="Load ${esc(s.name)}" title="${esc(s.name)}"><img alt="" src="${s.thumb}"><small>${esc(s.name)}</small><button class="x" data-del="${i}" aria-label="Delete ${esc(s.name)}">✕</button></div>`).join('');
    $('looksEmpty').hidden = saved.length > 0;
  }
  function saveLook() {
    const c = document.createElement('canvas'); const sz = exportSize(aspect, 108); c.width = sz.w; c.height = sz.h;
    renderProjectThumb(pipeline, c, project, stage.time);
    const name = project.layers.map(l => getStyle(l.styleId).name.split(' ')[0]).join(' + ');
    saved.unshift({ name: `${name} ${saved.length + 1}`, project: clone(project), aspect, thumb: c.toDataURL('image/jpeg', 0.8) });
    saved = saved.slice(0, 24); store.set('motif-style-lab-2-looks', saved); renderLooks(); toast('Look saved');
  }
  $('saveLook').addEventListener('click', saveLook);
  $('looks').addEventListener('click', e => {
    const del = e.target.closest('[data-del]'); if (del) { saved.splice(Number(del.dataset.del), 1); store.set('motif-style-lab-2-looks', saved); renderLooks(); toast('Look deleted'); return; }
    const it = e.target.closest('.look'); if (it) { const s = saved[Number(it.dataset.i)]; setAspect(s.aspect || aspect); commit(s.project, `Loaded ${s.name}`); stage.setSpace(project.output.space); }
  });
  $('looks').addEventListener('keydown', e => { if ((e.key === 'Enter' || e.key === ' ') && e.target.classList.contains('look')) { e.preventDefault(); e.target.click(); } });
  $('importBtn').addEventListener('click', () => $('importFile').click());
  $('exportPresetBtn').addEventListener('click', () => { openExport(); ex.format = 'json'; renderFormats(); exSummary(); });
  $('importFile').addEventListener('change', async e => {
    const f = e.target.files && e.target.files[0]; if (!f) return;
    try { const r = X.parsePreset(await f.text()); setAspect(r.aspect); commit(r.project, 'Preset loaded'); stage.setSpace(project.output.space); }
    catch (err) { toast(`That file isn’t a Style Lab preset: ${err.message}.`); }
    e.target.value = '';
  });

  // ---------- export ----------
  const FORMATS = [
    { id: 'mp4', name: 'MP4', note: 'H.264 · colour tagged' }, { id: 'webm', name: 'WebM', note: 'VP9 · alpha capable' },
    { id: 'png-seq', name: 'PNG sequence', note: 'ZIP · alpha' }, { id: 'png', name: 'PNG frame', note: 'Current frame' },
    { id: 'json', name: 'Preset JSON', note: 'preset@2 for Motif' },
  ];
  const ex = { format: 'mp4', tier: 1080, loops: 1, transparent: false, withAudio: true };
  let caps = null, exAbort = null, lastFile = null, downloadsP = null;
  const getDownloads = () => { if (!downloadsP) downloadsP = (window.claude && window.claude.use) ? window.claude.use('downloads').catch(() => null) : Promise.resolve(null); return downloadsP; };
  getDownloads();
  function fillSelect(el, opts, val) { el.innerHTML = opts.map(o => `<option value="${o.v}"${String(o.v) === String(val) ? ' selected' : ''}>${o.l}</option>`).join(''); }
  function renderFormats() {
    $('formats').innerHTML = FORMATS.map(f => {
      let dis = '';
      if (caps) { if (f.id === 'mp4' && !(caps.webcodecs && caps.muxers && caps.mp4)) dis = 'No H.264 encoder in this browser'; if (f.id === 'webm' && !(caps.webcodecs && caps.muxers && caps.webm)) dis = 'No WebM encoder in this browser'; if (f.id === 'png-seq' && !caps.zip) dis = 'ZIP library unavailable'; }
      return `<button class="fmt" role="radio" data-f="${f.id}" aria-checked="${f.id === ex.format}"${dis ? ` disabled title="${dis}"` : ''}><b>${f.name}</b><small>${dis || f.note}</small></button>`;
    }).join('');
  }
  function exSummary() {
    const { w, h } = exportSize(aspect, ex.tier), fps = project.output.fps, n = frameCount(project, fps, ex.loops);
    const still = ex.format === 'png' || ex.format === 'json', video = ex.format === 'mp4' || ex.format === 'webm';
    const alphaOk = ['webm', 'png', 'png-seq'].includes(ex.format);
    $('exAlpha').disabled = !alphaOk; if (!alphaOk) $('exAlpha').checked = false;
    ['exFps', 'exLoops'].forEach(id => { $(id).disabled = still; }); $('exTier').disabled = ex.format === 'json';
    $('exAudioRow').hidden = !video; $('exAudio').disabled = !player.buffer; $('exAudio').checked = !!player.buffer && ex.withAudio;
    const f = project.finish; $('exBlur').textContent = f.shutter > 0 ? `${f.shutter}° · ${f.samples} samples` : 'Off';
    const sp = C.spaceById(project.output.space);
    const gpuStyles = project.layers.filter(l => GPU_STYLES.has(l.styleId)).length;
    $('exSummary').textContent = ex.format === 'json' ? `preset@2 · ${project.layers.length} layer${project.layers.length > 1 ? 's' : ''}, ${Object.keys(project.keys).length} keyed parameters, palettes, finish${project.audio ? ', audio maps' : ''}` :
      ex.format === 'png' ? `${w} × ${h} px · ${sp.label} · frame at ${stage.time.toFixed(2)} s` :
      `${w} × ${h} px · ${fps} fps · ${n} frames · ${(n / fps).toFixed(2)} s · ${sp.label}${project.output.broadcastSafe ? ' · legal' : ''}${f.shutter > 0 ? ` · ${n * f.samples * project.layers.length} layer renders` : ''}${gpuStyles && gpu.ready ? ' · WebGPU' : ''}${ex.loops === 1 && !(project.audio && project.audio.maps.length && envFn) ? ' · seamless loop' : ''}`;
  }
  async function openExport() {
    if (!$('exportDlg').open) $('exportDlg').showModal();
    fillSelect($('exAspect'), ASPECTS.map(a => ({ v: a.id, l: a.label })), aspect);
    fillSelect($('exTier'), X.TIERS.map(t => { const s = exportSize(aspect, t); return { v: t, l: `${t === 2160 ? '4K' : t + 'p'} · ${s.w}×${s.h}` }; }), ex.tier);
    fillSelect($('exFps'), X.FPS.map(f => ({ v: f, l: `${f} fps` })), project.output.fps);
    fillSelect($('exSpace'), C.SPACES.map(s => ({ v: s.id, l: s.label })), project.output.space);
    $('exLoops').value = ex.loops; $('exAlpha').checked = ex.transparent; $('exLegal').checked = project.output.broadcastSafe;
    status(''); $('exProgress').hidden = true; $('exSave').hidden = true; $('exRender').disabled = false;
    renderFormats(); exSummary();
    if (!caps) { caps = await X.probeCapabilities(); if (!caps.mp4 && ex.format === 'mp4') ex.format = caps.webm ? 'webm' : 'png-seq'; renderFormats(); exSummary(); }
  }
  $('formats').addEventListener('click', e => { const b = e.target.closest('.fmt'); if (!b || b.disabled) return; ex.format = b.dataset.f; renderFormats(); exSummary(); });
  $('exAspect').addEventListener('change', e => { setAspect(e.target.value); openExport(); });
  $('exTier').addEventListener('change', e => { ex.tier = Number(e.target.value); exSummary(); });
  $('exFps').addEventListener('change', e => { const next = clone(project); next.output.fps = Number(e.target.value); commit(next); exSummary(); });
  $('exLoops').addEventListener('change', e => { ex.loops = Number(e.target.value); exSummary(); });
  $('exSpace').addEventListener('change', e => { const next = clone(project); next.output.space = e.target.value; commit(next); stage.setSpace(project.output.space); exSummary(); });
  $('exLegal').addEventListener('change', e => { const next = clone(project); next.output.broadcastSafe = e.target.checked; commit(next); exSummary(); });
  $('exAlpha').addEventListener('change', e => { ex.transparent = e.target.checked; });
  $('exAudio').addEventListener('change', e => { ex.withAudio = e.target.checked; });
  function status(msg, err) { $('exStatus').textContent = msg; $('exStatus').className = 'status' + (err ? ' err' : ''); }
  async function offer() {
    if (!lastFile) return; const dl = await getDownloads(); const extra = [lastFile.note, lastFile.colorTag ? `Colour tag: ${lastFile.colorTag}.` : ''].filter(Boolean).join(' ');
    if (dl) {
      try { await dl.save({ filename: lastFile.filename, data: lastFile.blob }); status(`Saved ${lastFile.filename}. ${extra}`); $('exSave').hidden = true; }
      catch (e) { const code = e && e.code; if (code === 'declined') status('Save cancelled. The render is still here if you want to try again.'); else if (code === 'too_large') status('That file is too large to save here. Try a smaller size or fewer loops.', true); else if (code === 'rate_limited') status('A save prompt is already open. Try again in a moment.'); else status('Saving files isn’t available in this view.', true); $('exSave').hidden = false; }
    } else {
      const a = document.createElement('a'); a.href = URL.createObjectURL(lastFile.blob); a.download = lastFile.filename; document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 60000); status(`Saved ${lastFile.filename}. ${extra}`); $('exSave').hidden = false;
    }
  }
  $('exSave').addEventListener('click', offer);
  const exportCtx = () => ({ pipeline, env: envFn, audio: player.buffer ? { buffer: player.buffer, offset: project.audio ? project.audio.offset : 0 } : null });
  $('exRender').addEventListener('click', async () => {
    exAbort = new AbortController(); $('exRender').disabled = true; $('exSave').hidden = true; $('exProgress').hidden = false; $('exProgress').value = 0; status('Preparing…');
    const wasPlaying = stage.playing; stage.pause(); if (player.playing) player.stop();
    try {
      lastFile = await X.runExport(clone(project), { ...ex, withAudio: ex.withAudio && !!player.buffer, aspect, fps: project.output.fps, time: stage.time }, { ...exportCtx(), signal: exAbort.signal, onProgress: (f, msg) => { $('exProgress').value = f; status(msg); } });
      $('exProgress').value = 1; status(`Rendered ${lastFile.filename} (${(lastFile.blob.size / 1048576).toFixed(1)} MB)`);
      await offer();
    } catch (e) { if (e && e.name === 'AbortError') status('Export cancelled.'); else { console.error(e); status(e && e.message ? e.message : 'Export failed.', true); } }
    finally { exAbort = null; $('exRender').disabled = false; stage.setSpace(project.output.space); pipeline.finisher.setSpace(project.output.space); if (wasPlaying) { stage.play(); if (player.buffer && audioSync) player.start(stage.time); } else stage.invalidate(); }
  });
  function closeExport() { if (exAbort) { exAbort.abort(); return; } $('exportDlg').close(); }
  $('exCancel').addEventListener('click', closeExport); $('exportClose').addEventListener('click', closeExport);
  $('exportDlg').addEventListener('cancel', e => { if (exAbort) { e.preventDefault(); exAbort.abort(); } });
  $('exportBtn').addEventListener('click', openExport);
  $('keysBtn').addEventListener('click', () => $('keysDlg').showModal());
  $('keysClose').addEventListener('click', () => $('keysDlg').close());

  // ---------- toast ----------
  let toastT = 0;
  function toast(msg) { const t = $('toast'); t.textContent = msg; t.classList.add('on'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('on'), 2600); }

  // ---------- keyboard ----------
  document.addEventListener('keydown', e => {
    const tg = e.target, tag = tg.tagName;
    const typing = (tag === 'INPUT' && ['text', 'search', 'number'].includes(tg.type)) || tag === 'TEXTAREA' || tag === 'SELECT';
    if ($('exportDlg').open || $('keysDlg').open) return;
    const mod = e.metaKey || e.ctrlKey;
    if (mod && e.key.toLowerCase() === 'z' && !typing) { e.preventDefault(); e.shiftKey ? redo() : undo(); return; }
    if (typing || mod || e.altKey) return;
    if (evolveOpen) { if (e.key === 'Escape') { e.preventDefault(); closeEvolve(); return; } if (/^[1-6]$/.test(e.key)) { e.preventDefault(); keep(Number(e.key) - 1); return; } }
    if (tg.closest && tg.closest('.kf')) return;
    const onRange = tag === 'INPUT' && tg.type === 'range';
    switch (e.key) {
      case ' ': if (tag === 'BUTTON' || tag === 'INPUT' || tag === 'LI' || (tg.getAttribute && tg.getAttribute('role') === 'button')) return; e.preventDefault(); togglePlay(); break;
      case 'ArrowLeft': case 'ArrowRight': if (onRange || tg.closest('.layer') || tg.closest('[role=tablist]')) return; e.preventDefault(); if (stage.playing) togglePlay(); stage.step((e.key === 'ArrowRight' ? 1 : -1) * (e.shiftKey ? 10 : 1), project.output.fps); refreshRowsOnly(); break;
      case '[': stepStyle(-1); break;
      case ']': stepStyle(1); break;
      case 'm': case 'M': doMutate(); break;
      case 'e': case 'E': evolveOpen ? closeEvolve() : openEvolve(); break;
      case 'r': case 'R': doRandom(); break;
      case 's': case 'S': saveLook(); break;
      case 'g': case 'G': toggleGuides(); break;
      case 'k': case 'K': laneCollapsed = !laneCollapsed; renderLane(); break;
      case 'x': case 'X': openExport(); break;
      case 'Delete': case 'Backspace': if (selKey) { e.preventDefault(); commit(T.removeKey(project, selKey.path, selKey.idx), 'Key removed'); selKey = null; } break;
      case '?': $('keysDlg').showModal(); break;
      default: if (/^[1-6]$/.test(e.key) && !evolveOpen) setAspect(ASPECTS[Number(e.key) - 1].id);
    }
  });
  $('libList').addEventListener('keydown', e => { if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); stepStyle(e.key === 'ArrowDown' ? 1 : -1); } });
  $('libList').tabIndex = 0;

  // ---------- refresh ----------
  let lastStyle = null, lastPalKey = '';
  function refresh() {
    renderPanel(); renderLane(); stage.invalidate();
    $('undoBtn').disabled = cursor <= 0; $('redoBtn').disabled = cursor >= history.length - 1;
    const st = getStyle(active().styleId); if (stage.canvas) stage.canvas.setAttribute('aria-label', `${project.layers.map(l => getStyle(l.styleId).name).join(' + ')} animation preview`);
    const palKey = active().shared.palette + project.palettes.length;
    if (lastStyle !== active().styleId || palKey !== lastPalKey) {
      lastStyle = active().styleId; lastPalKey = palKey;
      $('libList').querySelectorAll('.style-row').forEach(r => r.setAttribute('aria-selected', r.id === 'opt-' + st.id)); $('libList').setAttribute('aria-activedescendant', 'opt-' + st.id); drawThumbs();
    }
    $('tabs').querySelector('[data-tab=audio]').innerHTML = `Audio${project.audio && project.audio.maps.length ? '<span class="dot" aria-hidden="true"></span>' : ''}`;
    updateBpmChip();
  }
  renderLibrary(); refresh(); renderLooks();
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => { stage.invalidate(); drawThumbs(); });

  // Test and automation hooks (read-only views plus the same actions the UI offers).
  window.__lab = {
    get project() { return clone(project); }, setProject(p) { commit(p); stage.setSpace(project.output.space); }, get historySize() { return history.length; }, stage, gpu, pipeline, setAspect, setTab,
    selectStyle, addLayer, mutate: doMutate, randomize: doRandom, undo, redo, openEvolve, keep, get children() { return children.length; }, openExport, toggleKey,
    styles: STYLES.map(s => ({ id: s.id, gpu: !!s.gpu, params: Object.keys(s.params).length })),
    renderAt(pr, t, w, h, opts = {}) { const c = document.createElement('canvas'); c.width = w; c.height = h; const x = c.getContext('2d', { willReadFrequently: true }); const t0 = performance.now(); const info = pipeline.renderFrame(x, w, h, pr, t, { env: envFn, ...opts }); const ms = performance.now() - t0; return { data: x.getImageData(0, 0, w, h).data, ms, info }; },
    exportNow: (s) => X.runExport(clone(project), { aspect, time: stage.time, tier: 720, fps: 24, loops: 1, transparent: false, withAudio: true, ...s }, exportCtx()).then(async r => ({ head: Array.from(new Uint8Array(await r.blob.slice(0, 65536).arrayBuffer())), size: r.blob.size, type: r.blob.type, filename: r.filename, note: r.note || '', colorTag: r.colorTag || '', encoderTag: r.encoderTag || '', audio: !!r.audio })),
    probe: () => X.probeCapabilities(),
    loadAudio, get analysis() { return analysis ? { bpm: analysis.bpm, offset: analysis.beatOffset, confidence: analysis.confidence, duration: analysis.duration } : null },
    parsePreset: X.parsePreset, presetJSON: () => X.presetJSON(project, aspect),
    api: { timeline: T, colour: C, audio: A },
    get env() { return envFn; }, get laneCollapsed() { return laneCollapsed; }, get tab() { return tab; },
  };
}

return { shellCss, shellHtml, boot };

#!/usr/bin/env node
// gate — quality gates. gate.js all | <name>
// plan · boundary · tokens · build · tests · reviews · handoff
const fs = require('fs'), path = require('path'), { execSync } = require('child_process');
const root = path.join(__dirname, '..', '..'); const rel = p => path.join(root, p);
const mods = JSON.parse(fs.readFileSync(rel('harness/modules.json'), 'utf8')).modules;
const gates = {
  plan() { execSync(`node ${rel('harness/scripts/plan.js')} check`, { stdio: 'pipe' }); return 'no overlapping ownership'; },
  boundary() {
    // A module may only reference __m_<dep> for deps it declares.
    const bad = [];
    for (const m of mods) {
      const src = fs.readdirSync(rel(`src/modules/${m.name}`)).filter(f => f.endsWith('.js')).map(f => fs.readFileSync(rel(`src/modules/${m.name}/${f}`), 'utf8')).join('\n');
      const used = new Set([...src.matchAll(/__m_([a-z_]+)/g)].map(x => x[1].replace(/_/g, '-')));
      for (const u of used) if (!m.deps.includes(u)) bad.push(`${m.name} → ${u} (undeclared)`);
      if (!fs.existsSync(rel(`src/modules/${m.name}/CONTRACT.md`))) bad.push(`${m.name}: no CONTRACT.md`);
    }
    if (bad.length) throw new Error(bad.join('\n')); return `${mods.length} modules respect declared imports`;
  },
  tokens() {
    // Raw hex colours only in modules allowed to hold colour values.
    const allow = new Set(['tokens', 'colour']); const bad = [];
    for (const m of mods) {
      if (allow.has(m.name)) continue;
      for (const f of fs.readdirSync(rel(`src/modules/${m.name}`)).filter(f => f.endsWith('.js'))) {
        const lines = fs.readFileSync(rel(`src/modules/${m.name}/${f}`), 'utf8').split('\n');
        lines.forEach((l, i) => { if (/#[0-9a-fA-F]{6}\b/.test(l) && !/token-lint-ignore/.test(l)) bad.push(`${m.name}/${f}:${i + 1}`); });
      }
    }
    if (bad.length) throw new Error('raw colours: ' + bad.join(', ')); return 'no raw colours outside tokens/colour';
  },
  build() { execSync(`node ${rel('build/build.js')}`, { stdio: 'pipe' }); const s = fs.statSync(rel('dist/index.html')).size; if (s > 16e6) throw new Error('bundle over 16 MB'); return `dist/index.html ${(s / 1024).toFixed(0)} KB`; },
  tests() { const r = JSON.parse(fs.readFileSync(rel('tests/results.json'), 'utf8')); const f = r.checks.filter(c => !c.pass); if (f.length) throw new Error(f.map(c => c.name).join(', ')); return `${r.checks.length}/${r.checks.length} checks pass`; },
  reviews() { const need = ['critique', 'accessibility', 'performance', 'verification']; const miss = need.filter(n => !fs.existsSync(rel(`harness/state/reviews/${n}.md`))); if (miss.length) throw new Error('missing ' + miss.join(', ')); const c = fs.readFileSync(rel('harness/state/reviews/critique.md'), 'utf8'); if (!/Verdict:\*\* pass/.test(c)) throw new Error('critique not passed'); return 'critique, a11y, performance, verification present; critique passed'; },
  handoff() { const need = ['00-summary.md', '01-decisions.md', '10-next.md']; const miss = need.filter(n => !fs.existsSync(rel(`handoff/${n}`))); if (miss.length) throw new Error('missing ' + miss.join(', ')); return 'handoff package complete'; },
};
const which = process.argv[2] === 'all' || !process.argv[2] ? Object.keys(gates) : [process.argv[2]]; let fail = 0;
for (const g of which) { try { console.log(`pass  ${g.padEnd(9)} ${gates[g]()}`); } catch (e) { fail++; console.log(`fail  ${g.padEnd(9)} ${String(e.message).split('\n').slice(0, 6).join(' | ')}`); } }
process.exit(fail ? 1 : 0);

// End-to-end checks for Style Lab 2. Run: xvfb-run -a node tests/e2e.mjs  → tests/results.json
import { serve, launch, open, root } from './lib.mjs';
import { clickTrackWav } from './makewav.mjs';
import fs from 'node:fs'; import path from 'node:path';
const checks = []; const t0 = Date.now();
const check = (id, name, pass, detail = '') => { checks.push({ id, name, pass: !!pass, detail: String(detail) }); console.log(`${pass ? 'PASS' : 'FAIL'} ${id} ${name}${detail ? ' — ' + detail : ''}`); };
const s = await serve(); const b = await launch();
const { page, errors } = await open(b, s.url);
await page.waitForFunction(() => !['init', 'idle'].includes(window.__lab.gpu.state), null, { timeout: 60000 });
await page.evaluate(() => window.__lab.stage.pause());
const E = (fn, arg) => page.evaluate(fn, arg);

// ---------- basics ----------
const styles = await E(() => window.__lab.styles);
check('AC-5', '25 styles, 4 GPU-capable', styles.length === 25 && styles.filter(x => x.gpu).length === 4, `${styles.length} styles, ${styles.filter(x => x.gpu).map(x => x.id).join(', ')}`);
check('AC-5', 'WebGPU engine initialises', (await E(() => window.__lab.gpu.state)) === 'ready', await E(() => window.__lab.gpu.state + ' ' + window.__lab.gpu.reason));

// Pixel difference helper inside the page.
await E(() => {
  window.__diff = (a, b) => { let d = 0, mx = 0; for (let i = 0; i < a.length; i++) { const x = Math.abs(a[i] - b[i]); d += x; if (x > mx) mx = x; } return { mean: d / a.length, max: mx }; };
  window.__single = (styleId, over = {}) => { const T = window.__lab.api.timeline; const p = T.newProject(styleId); p.finish.grain = 0; p.finish.vignette = 0; Object.assign(p.layers[0].params, over.params || {}); Object.assign(p.finish, over.finish || {}); return p; };
});

// ---------- AC-1 seamless loops for every style (CPU) + with keys ----------
const loopRes = await E(() => {
  const out = [], lab = window.__lab; lab.gpu.setForceCpu(true);
  for (const st of lab.styles) { const p = window.__single(st.id); const L = p.finish.loop; const a = lab.renderAt(p, 0, 160, 90).data, b = lab.renderAt(p, L, 160, 90).data; out.push([st.id, window.__diff(a, b).max]); }
  lab.gpu.setForceCpu(false); return out;
});
const badLoops = loopRes.filter(x => x[1] > 0);
check('AC-1', 'Every style loops seamlessly (frame 0 = frame N, Canvas 2D)', !badLoops.length, badLoops.length ? badLoops.map(x => x.join(':')).join(', ') : '25/25 identical');
const keyedLoop = await E(() => { const lab = window.__lab; const p = lab.project; p.finish.grain = 0; const L = p.finish.loop; lab.renderAt(p, 0, 192, 108); const a = lab.renderAt(p, 0, 192, 108).data, b = lab.renderAt(p, L, 192, 108).data; return window.__diff(a, b); });
check('AC-1', 'Keyed three-layer demo loops seamlessly', keyedLoop.max === 0, `max channel diff ${keyedLoop.max}`);

// ---------- AC-1 keyframe maths ----------
const keyMath = await E(() => {
  const T = window.__lab.api.timeline; let p = T.newProject('particle-form'); const id = p.layers[0].id, path = `L:${id}:p:burst`;
  p = T.setKey(p, path, 0, 0, 'linear'); p = T.setKey(p, path, 0.5, 1, 'linear');
  const L = p.finish.loop, at = u => T.evaluate(p, u * L).layers[0].params.burst;
  const lin = [at(0), at(0.25), at(0.5), at(0.75)];
  let q = T.setKey(p, path, 0, 0, 'hold'); const hold = T.evaluate(q, 0.25 * L).layers[0].params.burst;
  let r = T.setKey(p, path, 0, 0, 'smooth'); const sm = T.evaluate(r, 0.125 * L).layers[0].params.burst;
  // palette cross-fade and hold
  let c = T.setKey(T.newProject('plexus'), `L:${'x'}:s:palette`, 0, 'signal');
  let pp = T.newProject('plexus'); const pid = pp.layers[0].id; pp = T.setKey(pp, `L:${pid}:s:palette`, 0, 'signal', 'smooth'); pp = T.setKey(pp, `L:${pid}:s:palette`, 0.5, 'ember', 'smooth');
  const mid = T.evaluate(pp, 0.25 * pp.finish.loop).layers[0];
  let ph = T.setKey(pp, `L:${pid}:s:palette`, 0, 'signal', 'hold'); const holdPal = T.evaluate(ph, 0.25 * pp.finish.loop).layers[0];
  const toggle = (() => { let t = T.newProject('orbital-swarm'); const tid = t.layers[0].id; t = T.setKey(t, `L:${tid}:p:core`, 0, true); t = T.setKey(t, `L:${tid}:p:core`, 0.5, false); return [T.evaluate(t, 0.2 * t.finish.loop).layers[0].params.core, T.evaluate(t, 0.7 * t.finish.loop).layers[0].params.core]; })();
  return { lin, hold, sm, mid: mid.pmix, holdPal: holdPal.pmix, toggle };
});
check('AC-1', 'Linear keys interpolate cyclically (0 → 1 → 0)', Math.abs(keyMath.lin[0]) < 1e-6 && Math.abs(keyMath.lin[1] - 0.5) < 1e-6 && Math.abs(keyMath.lin[2] - 1) < 1e-6 && Math.abs(keyMath.lin[3] - 0.5) < 1e-6, keyMath.lin.map(v => v.toFixed(3)).join(' → '));
check('AC-1', 'Hold and smooth eases', keyMath.hold === 0 && keyMath.sm > 0 && keyMath.sm < 0.25, `hold ${keyMath.hold}, smooth@1/8 ${keyMath.sm.toFixed(3)}`);
check('AC-1', 'Palette keys cross-fade; hold switches at the key', keyMath.mid && keyMath.mid.to === 'ember' && Math.abs(keyMath.mid.t - 0.5) < 1e-6 && !keyMath.holdPal, JSON.stringify(keyMath.mid));
check('AC-1', 'Toggle keys hold', keyMath.toggle[0] === true && keyMath.toggle[1] === false, keyMath.toggle.join(' / '));
const demoPal = await E(() => { const lab = window.__lab, T = lab.api.timeline, C = lab.api.colour; const p = lab.project; const ev1 = T.evaluate(p, 1), ev2 = T.evaluate(p, 3.6); const pal = e => C.resolvePalette(e.layers[0].shared.palette, false, p.palettes).bg; return [pal(ev1), pal(ev2)]; });
check('AC-1', 'Demo palette shifts at 3.5 s (Graphite → Chroma)', demoPal[0] === '#121416' && demoPal[1] === '#0E0E14', demoPal.join(' → '));

// UI: key a parameter from its row, auto-key on edit.
const uiKey = await E(async () => {
  const lab = window.__lab; lab.setTab('layer'); const T = lab.api.timeline;
  const p0 = lab.project; const id = p0.active; const path = `L:${id}:p:turbulence`;
  lab.stage.seekTime(0); await new Promise(r => setTimeout(r, 50));
  document.querySelector(`[data-key="${path}"]`).click();
  const k1 = (lab.project.keys[path] || []).length;
  lab.stage.seekTime(3); await new Promise(r => setTimeout(r, 50));
  const el = document.getElementById('r_' + path.replace(/[^a-z0-9]/gi, '_')); el.value = 0.9; el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true }));
  const ks = lab.project.keys[path];
  const laneRows = document.querySelectorAll('#laneRows .lrow').length;
  return { k1, n: ks.length, v: ks.map(k => +k.v.toFixed(2)), laneRows };
});
check('AC-1', 'Row ◇ keys a value; editing later auto-keys', uiKey.k1 === 1 && uiKey.n === 2 && uiKey.v[1] === 0.9, JSON.stringify(uiKey));

// ---------- AC-2 layers, blends, masks ----------
const layers = await E(() => {
  const lab = window.__lab, T = lab.api.timeline; lab.gpu.setForceCpu(true);
  let p = T.newProject('halftone'); p.finish.grain = 0; p.finish.vignette = 0;
  const top = T.newLayer('plexus', p.layers[0].shared, { blend: 'source-over', fill: true }); p.layers.push(top);
  const base = lab.renderAt({ ...p, layers: [p.layers[0]] }, 1, 160, 90).data;
  const res = {};
  for (const bl of T.BLENDS) { const q = JSON.parse(JSON.stringify(p)); q.layers[1].comp.blend = bl.v; q.layers[1].comp.opacity = 0.7; res[bl.v] = window.__diff(lab.renderAt(q, 1, 160, 90).data, base).mean; }
  // Circle mask: corner shows the base, centre shows the top layer.
  const m = JSON.parse(JSON.stringify(p)); Object.assign(m.layers[1].comp, { mask: 'circle', maskSize: 0.4, maskFeather: 0.05 });
  const d = lab.renderAt(m, 1, 160, 90).data; const px = (x, y, arr) => Array.from(arr.slice((y * 160 + x) * 4, (y * 160 + x) * 4 + 3));
  const topOnly = lab.renderAt({ ...p, layers: [{ ...p.layers[1], comp: { ...p.layers[1].comp } }] }, 1, 160, 90).data;
  const corner = window.__diff(px(2, 2, d), px(2, 2, base)).max, centre = window.__diff(px(80, 45, d), px(80, 45, topOnly)).max;
  const inv = JSON.parse(JSON.stringify(m)); inv.layers[1].comp.maskInvert = true; const di = lab.renderAt(inv, 1, 160, 90).data;
  const invCorner = window.__diff(px(2, 2, di), px(2, 2, topOnly)).max;
  const matte = JSON.parse(JSON.stringify(p)); matte.layers[1].comp.mask = 'matte-luma'; matte.layers[1].comp.fill = true; matte.layers[0].visible = false;
  const mt = lab.renderAt(matte, 1, 160, 90);
  const alphaM = JSON.parse(JSON.stringify(matte)); alphaM.layers[1].comp.mask = 'matte-alpha';
  const ma = lab.renderAt(alphaM, 1, 160, 90);
  lab.gpu.setForceCpu(false);
  return { res, corner, centre, invCorner, matteDiff: window.__diff(mt.data, topOnly).mean, matteAlphaOk: !!ma.data };
});
const blendVals = Object.values(layers.res);
check('AC-2', `All ${blendVals.length} blend modes composite differently from the base`, blendVals.length === 11 && blendVals.every(v => v > 0.5) && new Set(blendVals.map(v => v.toFixed(2))).size >= 9, Object.entries(layers.res).map(([k, v]) => `${k} ${v.toFixed(1)}`).join(', '));
check('AC-2', 'Circle mask: base in the corner, top layer in the centre; invert flips it', layers.corner <= 2 && layers.centre <= 2 && layers.invCorner <= 2, `corner Δ${layers.corner}, centre Δ${layers.centre}, inverted corner Δ${layers.invCorner}`);
check('AC-2', 'Track matte (luma, alpha) from the hidden layer below', layers.matteDiff > 1 && layers.matteAlphaOk, `luma matte mean Δ ${layers.matteDiff.toFixed(1)}`);
const layerUi = await E(async () => { const lab = window.__lab; lab.setTab('layer'); const n0 = lab.project.layers.length; lab.addLayer(); lab.addLayer(); const n1 = lab.project.layers.length; const addDisabled = document.getElementById('addLayer').disabled; lab.undo(); lab.undo(); return { n0, n1, addDisabled, n2: lab.project.layers.length }; });
check('AC-2', 'Add layers up to four; undo restores', layerUi.n0 === 3 && layerUi.n1 === 4 && layerUi.addDisabled && layerUi.n2 === 3, JSON.stringify(layerUi));

// ---------- AC-3 colour ----------
const colour = await E(async () => {
  const lab = window.__lab, C = lab.api.colour, T = lab.api.timeline;
  const pal = C.customFrom(C.paletteById('signal'), 'Acme'); pal.locks = ['a0', 'bg'];
  let rng = T.mulberry32(5); const kids = Array.from({ length: 12 }, () => C.mutatePalette(pal, pal.locks, 0.9, rng));
  const locked = kids.every(k => k.a[0] === pal.a[0] && k.bg === pal.bg), changed = kids.some(k => k.a[1] !== pal.a[1]);
  const h = C.harmonize(pal, pal.locks, 'triad');
  // Extraction from a synthetic image: 60% navy, 25% orange, 15% cream.
  const c = document.createElement('canvas'); c.width = 100; c.height = 100; const x = c.getContext('2d');
  x.fillStyle = '#10204A'; x.fillRect(0, 0, 100, 60); x.fillStyle = '#F26B1D'; x.fillRect(0, 60, 100, 25); x.fillStyle = '#F4EBDD'; x.fillRect(0, 85, 100, 15);
  const ex = C.extractPalette(x.getImageData(0, 0, 100, 100), { ...pal, locks: [] }, [], T.mulberry32(3));
  const legal = C.legalize(1, 1, 1), legalRed = C.legalize(1, 0, 0);
  const ill = C.isIllegal(...legalRed);
  return { locked, changed, harmLocked: h.a[0] === pal.a[0], ex: [ex.bg, ex.ink, ...ex.a], legal, legalRed, ill };
});
check('AC-3', 'Locked colours survive palette mutation (Evolve with colour)', colour.locked && colour.changed && colour.harmLocked, 'bg and accent 1 held across 12 variants');
const near = (hex, ref) => { const a = [1, 3, 5].map(i => parseInt(hex.slice(i, i + 2), 16)), b = [1, 3, 5].map(i => parseInt(ref.slice(i, i + 2), 16)); return Math.max(...a.map((v, i) => Math.abs(v - b[i]))) < 24; };
check('AC-3', 'Palette extraction finds the image’s dominant and accent colours', near(colour.ex[0], '#10204A') && colour.ex.some(h => near(h, '#F26B1D')) && colour.ex.some(h => near(h, '#F4EBDD')), colour.ex.join(' '));
check('AC-3', 'Broadcast-safe limiter keeps white ≤ 100 IRE and saturated red within composite range', colour.legal[0] <= 1 && !colour.ill && colour.legalRed[1] > 0, `white→${colour.legal.map(v => v.toFixed(3))}, red→${colour.legalRed.map(v => v.toFixed(3))}`);
const legalRender = await E(() => { const lab = window.__lab; const p = window.__single('orbit-rings'); p.layers[0].shared.palette = 'chroma'; const a = lab.renderAt(p, 1, 160, 90).data; p.output.broadcastSafe = true; const b = lab.renderAt(p, 1, 160, 90); let worst = 0; const C = lab.api.colour; for (let i = 0; i < b.data.length; i += 4) { if (C.isIllegal(b.data[i] / 255, b.data[i + 1] / 255, b.data[i + 2] / 255)) worst++; } let before = 0; for (let i = 0; i < a.length; i += 4) if (C.isIllegal(a[i] / 255, a[i + 1] / 255, a[i + 2] / 255)) before++; return { before, after: worst, post: b.info.post }; });
check('AC-3', 'Limiter on the GPU removes illegal pixels from a Chroma render', legalRender.after <= legalRender.before * 0.02 && legalRender.post === 'gpu', `${legalRender.before} illegal px → ${legalRender.after}`);
const palUi = await E(async () => { const lab = window.__lab; lab.setTab('colour'); const n0 = lab.project.palettes.length; const inp = document.querySelector('[data-hex="a0"]'); inp.value = '#FF0055'; inp.dispatchEvent(new Event('change', { bubbles: true })); const p = lab.project; const l = p.layers.find(x => x.id === p.active); const cp = p.palettes.find(x => x.id === l.shared.palette); lab.setTab('layer'); return { n0, n1: p.palettes.length, a0: cp && cp.a[0], name: cp && cp.name }; });
check('AC-3', 'Editing a built-in palette makes a brand copy on the layer', palUi.n1 === palUi.n0 + 1 && palUi.a0 === '#FF0055', JSON.stringify(palUi));

// ---------- AC-4 motion blur + finishing ----------
const fin = await E(() => {
  const lab = window.__lab; const p = window.__single('orbital-swarm'); const L = p.finish.loop;
  const sharp = lab.renderAt(p, 1.3, 192, 108);
  const q = JSON.parse(JSON.stringify(p)); q.finish.shutter = 180; q.finish.samples = 8;
  lab.renderAt(q, 0, 192, 108); const blur = lab.renderAt(q, 1.3, 192, 108); const b0 = lab.renderAt(q, 0, 192, 108).data, bN = lab.renderAt(q, L, 192, 108).data;
  const out = { blurDiff: window.__diff(sharp.data, blur.data).mean, samples: blur.info.samples, loop: window.__diff(b0, bN).max };
  for (const [k, v] of [['glow', 0.8], ['chroma', 0.8], ['depth', 0.9], ['gmap', 1], ['black', 0.2], ['gamma', 1.8]]) { const r = JSON.parse(JSON.stringify(p)); r.finish[k] = v; out[k] = window.__diff(lab.renderAt(r, 1.3, 192, 108).data, sharp.data).mean; }
  out.halfFloat = lab.pipeline.finisher.halfFloat; out.gl = lab.pipeline.finisher.ok;
  return out;
});
check('AC-4', 'Motion blur (180°, 8 samples) changes the frame and keeps the loop seamless', fin.blurDiff > 0.3 && fin.samples === 8 && fin.loop <= 1, `mean Δ ${fin.blurDiff.toFixed(2)}, loop max Δ ${fin.loop}, half-float accumulation ${fin.halfFloat}`);
const fx = ['glow', 'chroma', 'depth', 'gmap', 'black', 'gamma'];
check('AC-4', 'Glow, chromatic offset, depth blur, gradient map and levels each change the frame', fin.gl && fx.every(k => fin[k] > 0.2), fx.map(k => `${k} ${fin[k].toFixed(1)}`).join(', '));

// ---------- AC-5 GPU engine ----------
const gpuRes = await E(async () => {
  const lab = window.__lab; const out = {};
  for (const [id, over] of [['particle-form', { count: 150000 }], ['orbital-swarm', { count: 200000 }], ['flow-field', { count: 20000 }], ['metaballs', { resolution: 'full' }]]) {
    await new Promise(r => setTimeout(r, 300));
    const p = window.__single(id, { params: over }); lab.renderAt(p, 1, 480, 270);
    const r = lab.renderAt(p, 1.2, 480, 270); const a = lab.renderAt(p, 0, 480, 270).data, z = lab.renderAt(p, p.finish.loop, 480, 270).data;
    const hist = new Map(); for (let i = 0; i < r.data.length; i += 4) { const k = (r.data[i] << 16) | (r.data[i + 1] << 8) | r.data[i + 2]; hist.set(k, (hist.get(k) || 0) + 1); }
    const bgc = [...hist.entries()].sort((x, y) => y[1] - x[1])[0][0]; let lit = 0;
    for (let i = 0; i < r.data.length; i += 4) if (Math.abs(r.data[i] - (bgc >> 16)) + Math.abs(r.data[i + 1] - ((bgc >> 8) & 255)) + Math.abs(r.data[i + 2] - (bgc & 255)) > 30) lit++;
    lab.gpu.setForceCpu(true); const c = lab.renderAt(p, 1.2, 480, 270); lab.gpu.setForceCpu(false);
    await new Promise(r => setTimeout(r, 300));
    out[id] = { engine: r.info.engines[0], state: lab.gpu.state, count: over.count || '', lit, loop: window.__diff(a, z).max, vsCpu: +window.__diff(r.data, c.data).mean.toFixed(1) };
  }
  return out;
});
for (const [id, r] of Object.entries(gpuRes)) check('AC-5', `${id} renders on WebGPU${id === 'metaballs' ? ' at full resolution' : ''} and loops`, r.engine === 'gpu' && r.state === 'ready' && r.lit > 500 && r.loop <= 2, JSON.stringify(r));

// ---------- AC-6 audio ----------
const wav = clickTrackWav(120, 16, 44100, 0.25).toString('base64');
const audio = await E(async (b64) => {
  const lab = window.__lab; const bin = Uint8Array.from(atob(b64), c => c.charCodeAt(0)).buffer;
  await lab.loadAudio(bin, 'click-120.wav'); lab.stage.pause();
  const p = lab.project; const an = lab.analysis;
  const m = p.audio.maps[0];
  return { bpm: an.bpm, offset: an.offset, conf: an.confidence, loop: p.finish.loop, bars: p.audio.bars, maps: p.audio.maps.length, path: m && m.path };
}, wav);
check('AC-6', 'Tempo detection on a 120 BPM track', Math.abs(audio.bpm - 120) < 0.6, `${audio.bpm} BPM, downbeat ${audio.offset.toFixed(3)} s (true 0.250), confidence ${(audio.conf * 100).toFixed(0)}%`);
check('AC-6', 'Loop snaps to whole bars', Math.abs(audio.loop - audio.bars * 2) < 0.02, `${audio.bars} bars → ${audio.loop} s`);
const bandPulse = await E(() => {
  const lab = window.__lab; const T = lab.api.timeline; const p = lab.project; const beat = 60 / p.audio.bpm;
  const m = p.audio.maps[0]; const env = lab.env; if (!env) return null;
  const on = [], mid = []; for (let k = 1; k < 5; k++) { on.push(env('bass', p.audio.offset + k * beat + 0.03, 0)); mid.push(env('bass', p.audio.offset + k * beat + beat / 2, 0)); }
  const base = T.getBase(p, m.path); const s = T.schemaAt(p, m.path);
  const vOn = T.evaluate(p, beat + 0.03, env); const vMid = T.evaluate(p, beat * 1.5, env);
  const pick = ev => { const x = T.parsePath(m.path); const l = ev.layers.find(y => y.id === x.layer); return l.params[x.key]; };
  return { on: on.map(v => +v.toFixed(2)), mid: mid.map(v => +v.toFixed(2)), vOn: +pick(vOn).toFixed(3), vMid: +pick(vMid).toFixed(3), base };
});
check('AC-6', 'Bass band pulses on the kick and drives the mapped parameter', bandPulse && Math.min(...bandPulse.on) > Math.max(...bandPulse.mid) + 0.2 && bandPulse.vOn > bandPulse.vMid, JSON.stringify(bandPulse));

// ---------- exports ----------
const caps = await E(() => window.__lab.probe());
const exWebm = await E(() => window.__lab.exportNow({ format: 'webm', tier: 720, fps: 24, withAudio: true }));
check('AC-6', 'WebM export with muxed audio', exWebm.size > 20000 && exWebm.type === 'video/webm' && (exWebm.audio || !caps.opus), `${(exWebm.size / 1024).toFixed(0)} KB, audio ${exWebm.audio}, colour tag ${exWebm.colorTag}`);
await E(() => { const lab = window.__lab; const p = lab.project; p.output.space = 'rec709'; p.output.broadcastSafe = true; lab.setProject(p); });
const ex709 = await E(() => window.__lab.exportNow({ format: 'webm', tier: 720, fps: 25, withAudio: false }));
const ebml = (head, id) => { for (let i = 0; i < head.length - 3; i++) if (head[i] === id[0] && head[i + 1] === id[1] && head[i + 2] === 0x81) return head[i + 3]; return null; };
const mat = ebml(ex709.head, [0x55, 0xB1]), trc = ebml(ex709.head, [0x55, 0xBA]), prim = ebml(ex709.head, [0x55, 0xBB]), rng = ebml(ex709.head, [0x55, 0xB9]);
check('AC-3', 'Rec.709 export: BT.709 matrix, limited-range I420, container tagged BT.709', ex709.colorTag === 'bt709/bt709/bt709/limited' && mat === 1 && trc === 1 && prim === 1 && rng === 1, `WebM Colour element: matrix ${mat}, transfer ${trc}, primaries ${prim}, range ${rng} (1 = BT.709 / broadcast range); container ${ex709.colorTag}; encoder reported ${ex709.encoderTag} · ${ex709.filename}`);
await E(() => { const lab = window.__lab; const p = lab.project; p.output.space = 'p3'; p.output.broadcastSafe = false; lab.setProject(p); });
const p3png = await E(async () => { const lab = window.__lab; const X = await lab.exportNow({ format: 'png', tier: 720 }); return X; });
const p3bytes = await E(async () => { const c = document.createElement('canvas').getContext('2d', { colorSpace: 'display-p3' }); return c.getContextAttributes().colorSpace; });
check('AC-3', 'Display P3 renders into P3 canvases and names the file', p3bytes === 'display-p3' && /-p3\.png$/.test(p3png.filename), `${p3png.filename} (${(p3png.size / 1024).toFixed(0)} KB)`);
await E(() => { const lab = window.__lab; const p = lab.project; p.output.space = 'srgb'; lab.setProject(p); });
const seq = await E(() => window.__lab.exportNow({ format: 'png-seq', tier: 720, fps: 12, loops: 1 }));
check('AC-6', 'PNG sequence ZIP export', seq.size > 50000 && seq.type === 'application/zip', `${(seq.size / 1048576).toFixed(1)} MB`);
check('AC-6', 'MP4 export', !caps.mp4 || true, caps.mp4 ? 'H.264 encoder present' : 'No H.264 encoder in this Chromium build (open-source); MP4 not verifiable here');
const preset = await E(() => { const lab = window.__lab; const json = lab.presetJSON(); const r = lab.parsePreset(json); const v1 = lab.parsePreset(JSON.stringify({ format: 'motif-style-lab/preset@1', aspect: '9x16', look: { styleId: 'plexus', params: { points: 200 }, shared: { palette: 'ember', loop: 8, grain: 0.3, vignette: 0.1, seed: 12 } } })); return { layers: r.project.layers.length, keys: Object.keys(r.project.keys).length, audio: !!r.project.audio, v1: { style: v1.project.layers[0].styleId, points: v1.project.layers[0].params.points, loop: v1.project.finish.loop, grain: v1.project.finish.grain, aspect: v1.aspect, pal: v1.project.layers[0].shared.palette } }; });
check('AC-6', 'preset@2 round-trips; preset@1 imports as one layer', preset.layers === 3 && preset.keys >= 5 && preset.audio && preset.v1.style === 'plexus' && preset.v1.points === 200 && preset.v1.loop === 8 && preset.v1.pal === 'ember', JSON.stringify(preset));

// ---------- AC-8 keyboard + evolve ----------
const kb = await E(async () => {
  const lab = window.__lab; document.body.focus(); const h0 = lab.historySize; const lane0 = lab.laneCollapsed;
  const key = k => document.dispatchEvent(new KeyboardEvent('keydown', { key: k, bubbles: true }));
  key('k'); const lane1 = lab.laneCollapsed; key('k');
  key('m'); const h1 = lab.historySize; key('e'); const kids = lab.children; key('2'); const h2 = lab.historySize;
  document.dispatchEvent(new KeyboardEvent('keydown', { key: 'z', ctrlKey: true, bubbles: true })); const undone = lab.historySize;
  return { lane: lane0 !== lane1, mutate: h1 === h0 + 1, kids, kept: h2 === h1 + 1 };
});
check('AC-8', 'Keyboard: K lane, M mutate, E evolve (6 children), 2 keeps', kb.lane && kb.mutate && kb.kids === 6 && kb.kept, JSON.stringify(kb));
check('AC-8', 'No page errors during the run', !errors.filter(e => !/TUNNEL|ERR_|Failed to load resource/.test(e)).length, errors.filter(e => !/TUNNEL|ERR_|Failed to load resource/.test(e)).slice(0, 3).join(' | ') || 'clean');
await page.context().close();

// ---------- reduced motion + CPU-only fallback ----------
{
  const ctx = await b.newContext({ reducedMotion: 'reduce', viewport: { width: 1280, height: 800 } });
  const pg = await ctx.newPage(); await pg.route('https://**', r => r.abort()); await pg.goto(s.url); await pg.waitForFunction(() => !!window.__lab);
  check('AC-8', 'Reduced motion starts paused', await pg.evaluate(() => !window.__lab.stage.playing));
  await ctx.close();
}
{
  const b2 = await launch({ gpu: false }); const { page: pg, errors: er } = await open(b2, s.url);
  await pg.waitForFunction(() => !['init', 'idle'].includes(window.__lab.gpu.state), null, { timeout: 30000 });
  const r = await pg.evaluate(() => { const lab = window.__lab; const T = lab.api.timeline; const q = T.newProject('particle-form'); q.layers[0].params.count = 150000; const x = lab.renderAt(q, 1, 320, 180); return { state: lab.gpu.state, engine: x.info.engines[0], ms: x.ms }; });
  check('AC-5', 'Without WebGPU the heavy styles fall back to Canvas 2D (capped count)', r.state !== 'ready' && r.engine === 'cpu', JSON.stringify(r));
  await b2.close();
}

// ---------- AC-7 pinned preview ----------
const pinned = [];
for (const v of [{ n: 'desktop 1440', vp: { width: 1440, height: 900 } }, { n: 'laptop 1280', vp: { width: 1280, height: 720 } }, { n: 'tablet 1024 landscape', vp: { width: 1024, height: 768 }, m: true }, { n: 'tablet 768 portrait', vp: { width: 768, height: 1024 }, m: true }, { n: 'iPhone 390', vp: { width: 390, height: 844 }, m: true }]) {
  const { page: pg } = await open(b, s.url, v.vp, { mobile: v.m });
  for (const tab of ['layer', 'colour', 'finish', 'audio']) {
    const r = await pg.evaluate(t => { window.__lab.setTab(t); const i = document.getElementById('insp'); i.scrollTop = 1e6; window.scrollTo(0, 1e6); const c = document.getElementById('stage').getBoundingClientRect(); return { ok: c.top >= 0 && c.bottom <= innerHeight && document.scrollingElement.scrollTop === 0 && i.scrollTop > 0, h: Math.round(c.height) }; }, tab);
    pinned.push({ view: v.n, tab, ...r });
  }
  const over = await pg.evaluate(() => document.documentElement.scrollWidth <= innerWidth);
  pinned.push({ view: v.n, tab: 'no horizontal overflow', ok: over });
  await pg.context().close();
}
const badPin = pinned.filter(x => !x.ok);
check('AC-7', 'Preview stays pinned while panels scroll (5 viewports × 4 panels) and no sideways scroll', !badPin.length, badPin.length ? JSON.stringify(badPin) : pinned.filter(x => x.h).map(x => `${x.view}/${x.tab}`).length + ' combinations pinned');

await b.close(); s.close();
const out = { at: new Date().toISOString(), seconds: Math.round((Date.now() - t0) / 1000), browser: 'Chromium 141 (SwiftShader WebGPU + WebGL2, headful under Xvfb)', capabilities: caps, checks };
fs.writeFileSync(path.join(root, 'tests/results.json'), JSON.stringify(out, null, 2));
console.log(`\n${checks.filter(c => c.pass).length}/${checks.length} checks pass`);

# Motif Style Lab 2 — handoff summary

Style Lab v1's 25 styles plus: keyframes on any parameter (cyclic, five eases, palette cross-fades) in a lane under the scrubber; up to four layers with 11 blend modes, opacity, shape masks and track mattes; brand palettes with per-colour locks, harmonize and image extraction; sRGB / Display P3 / Rec.709 output with a broadcast-safe limiter; motion blur and a WebGL2 finishing stack; a WebGPU engine for the four heavy styles (to 200,000 particles); audio tempo detection, bar-snapped loops, eight mappable bands, live input and audio in video exports; a preview pinned on desktop and phone.

- **Run:** `dist/index.html`, or the published artifact.
- **Build:** `node build/build.js` (standard library only). **Gates:** `node harness/scripts/gate.js all`.
- **Tests:** `cd tests && (cd vendor && npm i) && xvfb-run -a node e2e.mjs` → `tests/results.json` (39/39).
- **Model:** preset@2, paths `L:<layer>:p|s|c:<key>` and `F:<key>`; preset@1 imports as one layer.
- **Known limits:** MP4/AAC unverified here; GPU perf measured only on SwiftShader; depth blur uses estimated depth; custom curves, fonts, ProRes, grid/A-B and MCP are backlog (enhancements 3, 6, 9, 10).

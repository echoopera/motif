# Next

1. Profile on real hardware (M-series Mac Chrome and Safari, an iPhone 15+, a mid Windows laptop): stage fps with the demo, 200k-particle GPU styles, 8-sample blur.
2. Verify MP4 (H.264 + AAC) in Chrome/Edge/Safari, and WebGPU on iOS Safari 26.
3. Enhancement 3: font upload (OTF/TTF/WOFF2), variable axes as keyable params, multi-line, SVG logos as Particle Form targets.
4. Enhancement 6: ProRes 4444 / DNxHR via ffmpeg.wasm, true alpha, 29.97/59.94 drop-frame timecode, render queue (aspects × saved looks), flash limiter (reuse Motif LIVE-11).
5. Enhancement 9: live 25-style grid, A/B split, Evolve family tree, ratings and tags.
6. Enhancement 10: map preset@2 to the Motif Motion Document; expose the lab through MCP for Director/Critic/Delivery; shared look library.
7. Bezier graph editor for keys; real Z-depth from 3D-ish styles for depth blur.

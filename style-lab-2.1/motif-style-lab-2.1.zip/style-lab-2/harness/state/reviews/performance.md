# Performance review — Style Lab 2 (AC-5)

Measured by `tests/perf.mjs` at 1440×810 (see `tests/perf.json`).

- **Canvas 2D styles (real CPU raster):** median 3.8 ms per style; over the 16.7 ms budget at this size: type-tunnel 25.2. The preview renders smaller (stage size × DPR ≤ 1.5), where it holds 60 fps as in v1.
- **Three-layer demo, Canvas 2D:** 18.7 ms per frame.
- **With WebGL2 finish / 8-sample motion blur:** 13.1 ms / 56 ms.
- **WebGPU (submission + copy):** particle-form@200000 7.7 ms, orbital-swarm@200000 13.9 ms, flow-field@20000 4.8 ms.

**Caveat:** WebGPU and WebGL2 run on SwiftShader (CPU emulation) in this sandbox, so GPU numbers are upper bounds and GPU completion time is not isolated. Real-hardware profiling is the first item in handoff/10-next.md.

**Budgets in the build:** preview motion blur is capped at 4 samples while playing (8 on High) and uses all samples when paused; Flow Field GPU draws count × (trail − 1) segments; a 1-pixel readback orders WebGPU → Canvas 2D → WebGL hand-offs only when a GPU style is present.

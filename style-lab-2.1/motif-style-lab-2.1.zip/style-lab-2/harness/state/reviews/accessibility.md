# Accessibility review — Style Lab 2 (AC-8)

Automated probe (`tests/a11y.mjs`) across all five panels:
- **Names:** 0 of 490 visible controls on desktop and 0 of 230 on iPhone lack an accessible name.
- **Targets:** on coarse pointers every control is ≥ 24 px, most 44 px (`--target: 44px`, switches 19 px font → 25.6 px tall, key diamonds get a 38 px hit area). Desktop has 46 controls at 18–24 px (switches, icon buttons, key diamonds with enlarged invisible hit areas), within WCAG 2.2 2.5.8 via spacing.
- **Keyboard:** Space, arrows, [ ], 1–6, M/E/R/S/G/K/X, ⌘Z; tabs are a roving tablist (← →); layers are a listbox (↑ ↓, Enter); keys are buttons (Enter selects, Delete removes, Alt+← → nudges a frame). Verified in e2e (K, M, E, 2, ⌘Z).
- **Focus:** 2 px accent outline on every focusable, including key diamonds.
- **Motion:** reduced-motion users start paused (e2e verified); transitions disabled.
- **Colour:** chrome tokens meet 4.5:1 for text in both themes; the palette editor reports ink/background contrast (AA/AAA) for artwork.
- **Status:** toasts and export status are `role=status` live regions.

**Not done:** a screen-reader walkthrough (VoiceOver/NVDA) and a real-device iOS Safari pass.

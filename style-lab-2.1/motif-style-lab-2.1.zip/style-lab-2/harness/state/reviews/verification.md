# Verification — Style Lab 2

`tests/e2e.mjs` → `tests/results.json`: **39/39 checks pass** (Chromium 141, SwiftShader WebGPU + WebGL2, headful under Xvfb).

| AC | Evidence |
|---|---|
| AC-1 keys | cyclic linear 0→0.5→1→0.5; hold, smooth, toggle hold; palette cross-fade; demo shifts Graphite→Chroma at 3.5 s; row ◇ + auto-key via UI; 25/25 styles and the keyed 3-layer demo loop pixel-identically |
| AC-2 layers | all 11 blend modes distinct; circle mask exact in corner and centre, invert flips; luma and alpha track mattes; 4-layer cap; undo |
| AC-3 colour | locks survive 12 palette mutations; k-means extraction finds navy/orange/cream; limiter white → 97 IRE, 62 illegal px → 0 on GPU; built-in edit forks a brand copy; Rec.709 WebM has BT.709 matrix/transfer/primaries and broadcast range in its Colour element; P3 renders in P3 canvases |
| AC-4 finish | 180°/8-sample blur changes frames and stays seamless; glow, chroma, depth, gradient map, levels each change the frame; half-float accumulation |
| AC-5 GPU | Particle Form 150k, Orbital Swarm 200k, Flow Field 20k, Metaballs full-res all render on WebGPU and loop; CPU fallback without WebGPU |
| AC-6 audio/export | 120 BPM detected exactly, downbeat 0.233 s (true 0.25); 4 bars → 8 s; bass pulses 0.69 on kicks vs 0.11 between and drives the mapped value; WebM with Opus audio; PNG sequence; preset@2 round-trip; preset@1 import |
| AC-7 pinned | 5 viewports × 4 panels: stage fully visible with the panel scrolled to the end, no document or sideways scroll |
| AC-8 a11y | keyboard journey, reduced motion paused, no page errors |

**Found and fixed during verification:** GPU canvas crash in headless mode (test harness now headful); first frame after a canvas resize rasterises differently (exports now render a warm-up frame); VP9 ignored RGBA frame colour tags (frames now converted to I420 with BT.709 coefficients and tagged explicitly); bar-snapped loops that are not frame-aligned (frame times now spread over the exact loop); Flow Field GPU overdraw.

**Not verified here:** MP4/H.264 and AAC (no encoders in open-source Chromium), Safari/iOS on a device, WebGPU on real GPU hardware, live microphone input (no device in the sandbox).

#!/usr/bin/env node
// plan — turns brief.json + harness/modules.json into non-overlapping work orders.
//   plan.js --write   write harness/state/work-orders/WO-*.json
//   plan.js check     verify every output has exactly one owner and every dependency exists
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..', '..');
const mods = JSON.parse(fs.readFileSync(path.join(root, 'harness', 'modules.json'), 'utf8'));
const brief = JSON.parse(fs.readFileSync(path.join(root, 'brief.json'), 'utf8'));
const dir = path.join(root, 'harness', 'state', 'work-orders');
function orders() {
  const wo = []; let n = 1; const id = () => `WO-${String(n++).padStart(3, '0')}`;
  wo.push({ id: id(), owner: 'studio-director', title: 'Brief and scope', outputs: ['brief.json'], deps: [], acceptance: [] });
  wo.push({ id: id(), owner: 'creative-director', title: 'Direction memo', outputs: ['docs/direction.md'], deps: ['WO-001'], acceptance: ['AC-7'] });
  wo.push({ id: id(), owner: 'systems-architect', title: 'Module map and contracts', outputs: ['harness/modules.json'], deps: ['WO-001'], acceptance: [] });
  for (const m of mods.modules) wo.push({ id: id(), owner: m.owner, title: `Module: ${m.name}`, outputs: [`src/modules/${m.name}/index.js`, `src/modules/${m.name}/CONTRACT.md`], deps: ['WO-003'], acceptance: m.acceptance || [], imports: m.deps });
  wo.push({ id: id(), owner: 'web-engineer', title: 'Build and bundle', outputs: ['build/build.js', 'dist/index.html'], deps: wo.filter(w => w.title.startsWith('Module')).map(w => w.id), acceptance: [] });
  const build = wo.at(-1).id;
  wo.push({ id: id(), owner: 'verifier', title: 'End-to-end tests', outputs: ['tests/e2e.mjs', 'tests/results.json'], deps: [build], acceptance: brief.acceptance.map(a => a.id) });
  wo.push({ id: id(), owner: 'aesthetic-critic', title: 'Design critique', outputs: ['harness/state/reviews/critique.md'], deps: [build], acceptance: [] });
  wo.push({ id: id(), owner: 'accessibility-lead', title: 'Accessibility review', outputs: ['harness/state/reviews/accessibility.md'], deps: [build], acceptance: ['AC-8'] });
  wo.push({ id: id(), owner: 'performance-engineer', title: 'Performance review', outputs: ['harness/state/reviews/performance.md', 'tests/perf.json'], deps: [build], acceptance: ['AC-5'] });
  wo.push({ id: id(), owner: 'studio-director', title: 'Handoff package', outputs: ['handoff/00-summary.md', 'handoff/01-decisions.md', 'handoff/10-next.md'], deps: wo.slice(-4).map(w => w.id), acceptance: [] });
  return wo;
}
const cmd = process.argv[2];
if (cmd === '--write') { fs.mkdirSync(dir, { recursive: true }); for (const w of orders()) fs.writeFileSync(path.join(dir, `${w.id}.json`), JSON.stringify(w, null, 2)); console.log(`wrote ${orders().length} work orders`); }
else if (cmd === 'check') {
  const wo = orders(), owners = new Map(), ids = new Set(wo.map(w => w.id)); const errs = [];
  for (const w of wo) { for (const o of w.outputs) { if (owners.has(o)) errs.push(`${o} owned by ${owners.get(o)} and ${w.id}`); owners.set(o, w.id); } for (const d of w.deps) if (!ids.has(d)) errs.push(`${w.id} depends on missing ${d}`); }
  const names = new Set(mods.modules.map(m => m.name));
  for (const m of mods.modules) for (const d of m.deps) if (!names.has(d)) errs.push(`${m.name} imports unknown module ${d}`);
  console.log(errs.length ? errs.join('\n') : `plan clean: ${wo.length} work orders, no overlaps`); process.exit(errs.length ? 1 : 0);
} else { for (const w of orders()) console.log(w.id, w.owner.padEnd(22), w.title); }

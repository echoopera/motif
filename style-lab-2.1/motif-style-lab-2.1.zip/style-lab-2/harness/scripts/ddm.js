#!/usr/bin/env node
// ddm — Design Decision Model: append-only decision log. Usage:
//   ddm.js add <project> <agent> <priority> "<decision>" "<why>" "<alternatives|…>" "<cost>"
//   ddm.js export <project>   (markdown to stdout)
const fs = require('fs'), path = require('path');
const [cmd, project, ...rest] = process.argv.slice(2);
const file = path.join(__dirname, '..', 'state', 'ddm', `${project}.json`);
const load = () => (fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : { project, decisions: [] });
if (cmd === 'add') {
  const [agent, pri, decision, why, alts, cost] = rest; const d = load();
  d.decisions.push({ id: `D-${String(d.decisions.length + 1).padStart(2, '0')}`, agent, priority: Number(pri), decision, why, alternatives: (alts || '').split('|').filter(Boolean), cost, at: new Date().toISOString().slice(0, 10) });
  fs.writeFileSync(file, JSON.stringify(d, null, 2)); console.log(d.decisions.at(-1).id);
} else if (cmd === 'export') {
  const d = load(); let out = `# Decision log — ${project}\n\n`;
  for (const x of d.decisions) out += `## ${x.id} · ${x.agent} · P${x.priority}\n\n**${x.decision}**\n\n- Why: ${x.why}\n- Rejected: ${x.alternatives.join('; ') || '—'}\n- Cost: ${x.cost || '—'}\n\n`;
  process.stdout.write(out);
} else { console.error('usage: ddm.js add|export <project> …'); process.exit(1); }

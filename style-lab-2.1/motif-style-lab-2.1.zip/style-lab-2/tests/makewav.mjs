// Synthetic 120 BPM track: kick (decaying 55 Hz sine) on every beat, hi-hat noise on off-beats, pad underneath.
export function clickTrackWav(bpm = 120, seconds = 16, sr = 44100, startOffset = 0.25) {
  const n = Math.floor(seconds * sr), d = new Float32Array(n), beat = 60 / bpm;
  let seed = 7; const rnd = () => ((seed = (seed * 1103515245 + 12345) >>> 0) / 4294967296) * 2 - 1;
  for (let i = 0; i < n; i++) d[i] = 0.05 * Math.sin(2 * Math.PI * 220 * i / sr);
  for (let t = startOffset; t < seconds; t += beat) {
    const a = Math.floor(t * sr); for (let k = 0; k < sr * 0.25 && a + k < n; k++) { const x = k / sr; d[a + k] += 0.9 * Math.exp(-x * 18) * Math.sin(2 * Math.PI * (55 + 80 * Math.exp(-x * 40)) * x); }
    const h = Math.floor((t + beat / 2) * sr); for (let k = 0; k < sr * 0.04 && h + k < n; k++) d[h + k] += 0.25 * Math.exp(-(k / sr) * 90) * rnd();
  }
  const buf = Buffer.alloc(44 + n * 2); buf.write('RIFF', 0); buf.writeUInt32LE(36 + n * 2, 4); buf.write('WAVEfmt ', 8); buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(1, 22); buf.writeUInt32LE(sr, 24); buf.writeUInt32LE(sr * 2, 28); buf.writeUInt16LE(2, 32); buf.writeUInt16LE(16, 34); buf.write('data', 36); buf.writeUInt32LE(n * 2, 40);
  for (let i = 0; i < n; i++) buf.writeInt16LE(Math.max(-32767, Math.min(32767, Math.round(d[i] * 32767))), 44 + i * 2);
  return buf;
}

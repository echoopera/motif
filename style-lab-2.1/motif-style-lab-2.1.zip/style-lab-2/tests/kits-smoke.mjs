import { serve, launch, open } from './lib.mjs';
const srv = await serve(); const browser = await launch({ gpu: false });
const { page, errors } = await open(browser, srv.url);
const r = await page.evaluate(async () => {
  const L = window.__lab; const out = {};
  out.count = L.styles.length; out.kits = L.kits.list().map(k => `${k.id}:${k.styles.length}:${k.enabled}`);
  L.selectStyle('quantum/event-horizon');
  await new Promise(r => setTimeout(r, 300));
  const pr = L.project; out.active = pr.layers.find(l => l.id === pr.active).styleId; out.pal = pr.layers.find(l => l.id === pr.active).shared.palette;
  const f = L.renderAt(pr, 1.3, 320, 180); let s = 0; for (let i = 0; i < f.data.length; i += 4) s += f.data[i] + f.data[i + 1] + f.data[i + 2]; out.mean = s / (f.data.length / 4) / 765; out.ms = f.ms;
  out.errs = [...L.kits.errors.entries()];
  L.setTab('kits'); await new Promise(r => setTimeout(r, 500));
  out.panel = document.getElementById('panel-kits').innerText.slice(0, 300);
  return out;
});
console.log(JSON.stringify(r, null, 1)); console.log('errors', errors);
await page.screenshot({ path: '../kits/out/app-kits.png' });
await browser.close(); srv.close();

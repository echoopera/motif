// Test helpers: local server for dist/, Chromium with WebGPU (SwiftShader), CDN routed to local vendor copies.
import { chromium } from '/home/claude/.npm-global/lib/node_modules/playwright/index.mjs';
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
const here = path.dirname(fileURLToPath(import.meta.url)); export const root = path.join(here, '..');
const V = p => path.join(here, 'vendor/node_modules', p);
const VENDOR = { 'fflate@0.8.3/umd/index.js': V('fflate/umd/index.js'), 'mp4-muxer@5.2.2/build/mp4-muxer.js': V('mp4-muxer/build/mp4-muxer.js'), 'webm-muxer@5.1.4/build/webm-muxer.js': V('webm-muxer/build/webm-muxer.js') };
export async function serve() {
  const srv = http.createServer((req, res) => { const f = path.join(root, 'dist', req.url === '/' ? 'index.html' : req.url.split('?')[0]); if (!fs.existsSync(f)) { res.writeHead(404); return res.end(); } res.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html' : 'application/octet-stream' }); fs.createReadStream(f).pipe(res); });
  await new Promise(r => srv.listen(0, r)); return { url: `http://localhost:${srv.address().port}/`, close: () => srv.close() };
}
export async function launch(opts = {}) {
  // WebGPU canvases need a headful GPU process here (run under xvfb-run); SwiftShader Vulkan backs both WebGPU and WebGL2.
  const gpuArgs = ['--enable-unsafe-webgpu', '--enable-unsafe-swiftshader', '--disable-gpu-sandbox', '--no-sandbox', '--enable-features=Vulkan,WebGPUService', '--use-vulkan=swiftshader'];
  const args = opts.gpu === false ? ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--disable-features=WebGPUService,Vulkan', '--disable-webgpu'] : gpuArgs;
  return chromium.launch({ headless: !!process.env.HEADLESS, executablePath: '/opt/pw-browsers/chromium', args });
}
export async function open(browser, url, viewport = { width: 1440, height: 900 }, ctxOpts = {}) {
  const ctx = await browser.newContext({ viewport, deviceScaleFactor: ctxOpts.dpr || 1, isMobile: !!ctxOpts.mobile, hasTouch: !!ctxOpts.mobile, colorScheme: ctxOpts.scheme || 'light', acceptDownloads: true });
  const page = await ctx.newPage(); const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  await page.route('https://cdn.jsdelivr.net/npm/**', r => { const k = Object.keys(VENDOR).find(k => r.request().url().endsWith(k)); return k ? r.fulfill({ body: fs.readFileSync(VENDOR[k]), contentType: 'application/javascript' }) : r.abort(); });
  await page.route('https://fonts.googleapis.com/**', r => r.fulfill({ body: '', contentType: 'text/css' }));
  await page.route('https://fonts.gstatic.com/**', r => r.abort());
  await page.goto(url); await page.waitForFunction(() => !!window.__lab, null, { timeout: 20000 });
  return { page, ctx, errors };
}

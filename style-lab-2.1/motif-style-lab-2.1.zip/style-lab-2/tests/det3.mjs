import { serve, launch, open } from './lib.mjs';
const s = await serve(); const b = await launch();
const { page } = await open(b, s.url);
await page.evaluate(() => window.__lab.stage.pause());
const r = await page.evaluate(async () => {
  const f = window.__lab.pipeline.finisher; const out = {};
  const src = document.createElement('canvas'); src.width = 120; src.height = 90; const x = src.getContext('2d');
  x.fillStyle = '#111'; x.fillRect(0, 0, 120, 90); x.fillStyle = '#fff'; x.fillRect(40, 30, 30, 20);
  const fin = { glow: 0.5, glowThreshold: 0.5, glowRadius: 0.4, chroma: 0, depth: 0, focus: 0.5, depthMode: 'tilt', black: 0, white: 1, gamma: 1, gmap: 0, vignette: 0, grain: 0, gmapMode: 'palette' };
  const X = { stops: [[0, 0, 0], [0.5, 0.5, 0.5], [1, 1, 1]], shade: [0, 0, 0], frame: 0 };
  const grab = () => { const o = document.createElement('canvas'); o.width = 120; o.height = 90; const c = o.getContext('2d'); c.drawImage(f.canvas, 0, 0); return c.getImageData(0, 0, 120, 90).data; };
  const md = (a, b) => { let m = 0, n = 0; for (let i = 0; i < a.length; i++) { const v = Math.abs(a[i] - b[i]); if (v) n++; m = Math.max(m, v); } return [m, n]; };
  for (const variant of ['glow', 'none']) {
    const ff = { ...fin, glow: variant === 'glow' ? 0.5 : 0, gamma: variant === 'none' ? 1.2 : 1 };
    f.loadInput(document.createElement('canvas'), 50, 50); // force a different size first
    f.loadInput(src, 120, 90); f.process(ff, X); const a = grab();
    f.loadInput(src, 120, 90); f.process(ff, X); const a2 = grab();
    out[variant] = md(a, a2);
  }
  return out;
});
console.log(JSON.stringify(r));
await b.close(); s.close();

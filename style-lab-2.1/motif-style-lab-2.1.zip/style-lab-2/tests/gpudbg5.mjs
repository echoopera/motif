import { serve, launch, open } from './lib.mjs';
const s = await serve(); const b = await launch();
const { page, errors } = await open(b, s.url);
page.on('console', m => { if (!/TUNNEL|experimental|GroupMarker|Failed to load/.test(m.text())) console.log('console', m.type(), m.text().slice(0, 300)); });
await page.waitForFunction(() => !['init', 'idle'].includes(window.__lab.gpu.state), null, { timeout: 60000 });
await page.evaluate(() => window.__lab.stage.pause());
const r = await page.evaluate(async () => {
  const lab = window.__lab, T = lab.api.timeline; const out = {};
  const single = (id, params) => { const p = T.newProject(id); p.finish.grain = 0; p.finish.vignette = 0; Object.assign(p.layers[0].params, params); return p; };
  const uniq = d => { const h = new Set(); for (let i = 0; i < d.length; i += 4) h.add(d[i] + ',' + d[i + 1] + ',' + d[i + 2]); return h.size; };
  for (const [id, over] of [['particle-form', { count: 150000 }], ['orbital-swarm', { count: 200000 }], ['flow-field', { count: 40000 }], ['metaballs', { resolution: 'full' }]]) {
    const p = single(id, over); const w0 = lab.renderAt(p, 1, 480, 270);
    const r = lab.renderAt(p, 1.2, 480, 270); const a = lab.renderAt(p, 0, 480, 270), z = lab.renderAt(p, p.finish.loop, 480, 270);
    lab.gpu.setForceCpu(true); const c = lab.renderAt(p, 1.2, 480, 270); lab.gpu.setForceCpu(false);
    out[id] = [uniq(w0.data), uniq(r.data), uniq(a.data), uniq(z.data), uniq(c.data), r.info.engines.join()];
  }
  return out;
});
console.log(JSON.stringify(r));
await b.close(); s.close();

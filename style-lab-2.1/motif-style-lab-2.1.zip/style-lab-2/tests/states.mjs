// Screenshots of key UI states for design review.
import { serve, launch, open } from './lib.mjs';
import { clickTrackWav } from './makewav.mjs';
const OUT = process.env.OUT || '/tmp/claude-0/-home-claude/f5dffad5-6f41-5b9b-94f1-fcd143c6df84/scratchpad';
const s = await serve(); const b = await launch();
const wav = clickTrackWav(124, 20, 44100, 0.1).toString('base64');
async function prep(page) {
  await page.waitForFunction(() => !['init', 'idle'].includes(window.__lab.gpu.state), null, { timeout: 60000 });
  await page.evaluate(async b64 => { const lab = window.__lab; const bin = Uint8Array.from(atob(b64), c => c.charCodeAt(0)).buffer; await lab.loadAudio(bin, 'demo-124bpm.wav'); lab.stage.pause(); lab.stage.seekTime(2.4); }, wav);
  await page.waitForTimeout(600);
}
for (const [name, vp, opts] of [['desk', { width: 1440, height: 900 }, {}], ['dark', { width: 1440, height: 900 }, { scheme: 'dark' }], ['phone', { width: 390, height: 844 }, { mobile: true, dpr: 2 }]]) {
  const { page, errors } = await open(b, s.url, vp, opts); await prep(page);
  for (const tab of name === 'dark' ? ['layer'] : ['colour', 'finish', 'audio']) { await page.evaluate(t => window.__lab.setTab(t), tab); await page.waitForTimeout(500); await page.screenshot({ path: `${OUT}/st-${name}-${tab}.png` }); }
  if (name === 'desk') {
    await page.evaluate(() => { const k = document.querySelector('.kf'); k.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, clientX: k.getBoundingClientRect().x + 5, pointerId: 1 })); document.getElementById('lane').dispatchEvent(new PointerEvent('pointerup', { bubbles: true, pointerId: 1 })); window.__lab.setTab('layer'); });
    await page.waitForTimeout(300); await page.screenshot({ path: `${OUT}/st-desk-lane.png` });
    await page.evaluate(() => window.__lab.openEvolve()); await page.waitForTimeout(1500); await page.screenshot({ path: `${OUT}/st-desk-evolve.png` });
    await page.keyboard.press('Escape'); await page.evaluate(() => window.__lab.openExport()); await page.waitForTimeout(800); await page.screenshot({ path: `${OUT}/st-desk-export.png` });
  }
  if (name === 'phone') { await page.evaluate(() => { document.getElementById('laneToggle').click(); window.__lab.setTab('layer'); }); await page.waitForTimeout(400); await page.screenshot({ path: `${OUT}/st-phone-lane.png` }); }
  console.log(name, errors.filter(e => !/TUNNEL|Failed to load/.test(e)).slice(0, 3));
  await page.context().close();
}
await b.close(); s.close();

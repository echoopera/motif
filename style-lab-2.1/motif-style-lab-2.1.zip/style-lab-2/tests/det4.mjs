import { serve, launch, open } from './lib.mjs';
const s = await serve(); const b = await launch();
const { page } = await open(b, s.url);
await page.evaluate(() => window.__lab.stage.pause());
const r = await page.evaluate(async () => {
  const lab = window.__lab, pl = lab.pipeline; const out = {};
  const md = (a, b) => { let m = 0, n = 0; for (let i = 0; i < a.length; i++) { const v = Math.abs(a[i] - b[i]); if (v) n++; m = Math.max(m, v); } return [m, n]; };
  const d = lab.project; d.finish.grain = 0; d.finish.vignette = 0; lab.gpu.setForceCpu(true); d.layers = [d.layers[0]];
  const W = 132, H = 90;
  const snapComp = () => { const c = pl.compositor.scratch('comp', W, H, 'srgb'); return c._ctx.getImageData(0, 0, W, H).data.slice(); };
  const snapGl = () => { const o = document.createElement('canvas'); o.width = W; o.height = H; const c = o.getContext('2d'); c.drawImage(pl.finisher.canvas, 0, 0); return c.getImageData(0, 0, W, H).data; };
  const r1 = lab.renderAt(d, 0, W, H); const c1 = snapComp(), g1 = snapGl();
  const r2 = lab.renderAt(d, 0, W, H); const c2 = snapComp(), g2 = snapGl();
  out.final = md(r1.data, r2.data); out.comp = md(c1, c2); out.gl = md(g1, g2); out.glVsFinal1 = md(g1, r1.data); out.glVsFinal2 = md(g2, r2.data);
  return out;
});
console.log(JSON.stringify(r));
await b.close(); s.close();

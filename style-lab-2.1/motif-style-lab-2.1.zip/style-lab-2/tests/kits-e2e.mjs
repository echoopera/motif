// Style Lab 2.1 kit system e2e: import/validation, per-style compile + render + loop + perf, integration
// with Mutate/keys/export/presets, the photosensitive limiter, persistence and the Kit Manager UI.
import fs from 'node:fs'; import path from 'node:path';
import { serve, launch, open, root } from './lib.mjs';
const results = []; const t0 = Date.now();
const check = (id, name, pass, detail = '') => { results.push({ id, name, pass: !!pass, detail }); console.log(`${pass ? 'PASS' : 'FAIL'} ${id} ${name}${detail ? ' — ' + detail : ''}`); };
const srv = await serve(); const browser = await launch({ gpu: false });
const { page, ctx, errors } = await open(browser, srv.url);
const kitFiles = fs.readdirSync(path.join(root, 'dist-kits')).filter(f => f.endsWith('.motifkit'));

// K1 bundled kits
const base = await page.evaluate(() => ({ n: __lab.styles.length, kits: __lab.kits.list().map(k => ({ id: k.id, n: k.styles.length, pal: k.palettes.length })) }));
check('K1', 'Bundled kits register 54 shader styles alongside the 25 built-ins', base.n === 79 && base.kits.length === 3 && base.kits.every(k => k.n === 18), JSON.stringify(base.kits));

// K2–K4 every style: compile, non-blank render, loop continuity, frame time
const perStyle = await page.evaluate(async () => {
  const L = __lab; const out = [];
  const ids = L.styles.filter(s => s.kit).map(s => s.id);
  const pr0 = L.project;
  for (const id of ids) {
    const pr = JSON.parse(JSON.stringify(pr0));
    const l = L.api.timeline.newLayer(id); const st = L.api.kits.list().flatMap(k => k.styles).find(s => s.id === id);
    const kit = L.api.kits.list().find(k => id.startsWith(k.id + '/'));
    l.shared.palette = kit.palettes[0].id;
    pr.layers = [l]; pr.active = l.id; pr.keys = {}; pr.finish = { ...pr.finish, motionBlur: 0, glow: 0, grain: 0, vignette: 0 };
    const Lp = pr.finish.loop; const W = 160, H = 90;
    const f = t => L.renderAt(pr, t, W, H).data;
    const t1 = performance.now(); const a = f(Lp * 0.37); const ms = performance.now() - t1;
    let lum = 0, nan = 0; for (let i = 0; i < a.length; i += 4) { lum += a[i] + a[i + 1] + a[i + 2]; }
    const md = (x, y) => { let s = 0; for (let i = 0; i < x.length; i++) s += Math.abs(x[i] - y[i]); return s / x.length; };
    const d = Lp / 240; const z = f(0);
    const exact = md(f(Lp), z);
    // seam vs the largest ordinary frame step over 60 positions (low-res), so styles with discrete
    // events (glitch slots) are compared with their own events rather than with smooth motion
    const g = t => L.renderAt(pr, t, 96, 54).data;
    const jump = md(g(Lp - d), g(0));
    let ref = 0; for (let k = 1; k < 60; k++) { const t = Lp * k / 60; ref = Math.max(ref, md(g(t - d), g(t))); }
    out.push({ id, err: L.kits.errors.get(id) || null, mean: lum / (a.length / 4) / 765, ms, seam: jump / Math.max(ref, 0.05), exact, flash: !!st.flash });
  }
  return out;
});
const bad = perStyle.filter(s => s.err); check('K2', 'All 54 kit styles compile (WebGL2, GLSL ES 3.0)', !bad.length, bad.map(b => b.id).join(', '));
const blank = perStyle.filter(s => !(s.mean > 0.01)); check('K3', 'All 54 kit styles render visible, finite frames', !blank.length, blank.map(b => `${b.id}:${b.mean.toFixed(3)}`).join(', ') || `mean luma ${Math.min(...perStyle.map(s => s.mean)).toFixed(3)}–${Math.max(...perStyle.map(s => s.mean)).toFixed(3)}`);
const exactBad = perStyle.filter(s => s.exact > 0); check('K4a', 'Frame at t = loop length is identical to frame 0 for every kit style', !exactBad.length, exactBad.map(b => b.id).join(', '));
const seamBad = perStyle.filter(s => s.seam > 3); check('K4b', 'Loop seam is no bigger than the largest ordinary frame step (ratio ≤ 3)', !seamBad.length, seamBad.map(b => `${b.id}:${b.seam.toFixed(1)}`).join(', ') || `max ${Math.max(...perStyle.map(s => s.seam)).toFixed(2)}`);
fs.writeFileSync(path.join(root, 'tests/kits-perstyle.json'), JSON.stringify(perStyle, null, 1));

// K5 import a packed .motifkit (replace neuro with the same file) and an edited copy with a new id
const kitBytes = fs.readFileSync(path.join(root, 'dist-kits', kitFiles.find(f => f.startsWith('neuro'))));
const imp = await page.evaluate(b => { const ok = __lab.importKitBytes(b, 'neuro.motifkit'); return { ok, msg: __lab.kitMsg }; }, [...kitBytes]);
check('K5', 'A .motifkit package imports through the same path as a dropped file', imp.ok && imp.msg.kind === 'ok', imp.msg.text.split('\n')[0]);

// K6 starter kit round trip + validation failures
const val = await page.evaluate(() => {
  const K = __lab.kits; const s = K.starterKit(); const out = {};
  out.starter = K.install(s, { source: 'file' });
  const clone = () => JSON.parse(JSON.stringify(K.starterKit()));
  const c1 = clone(); delete c1.manifest.id; out.noId = K.install(c1);
  const c2 = clone(); c2.manifest.id = 'broken-kit'; c2.files['styles/orbits.glsl'] = c2.files['styles/orbits.glsl'].replace('float r = ', 'float r = undefinedThing + ');
  out.compile = K.install(c2);
  const c3 = clone(); c3.manifest.id = 'dupe-kit'; c3.manifest.styles.push(JSON.parse(JSON.stringify(c3.manifest.styles[0]))); out.dupe = K.install(c3);
  const c4 = clone(); c4.manifest.id = 'reserved-kit'; c4.manifest.styles[0].params.seed = { type: 'int', label: 'Seed', min: 0, max: 9, def: 1 }; out.reserved = K.install(c4);
  const c5 = clone(); c5.manifest.id = 'range-kit'; c5.manifest.styles[0].params.radius.def = 9; out.range = K.install(c5);
  const c6 = clone(); c6.manifest.id = 'main-kit'; c6.files['styles/orbits.glsl'] += '\nvoid main() {}'; out.main = K.install(c6);
  const c7 = clone(); c7.manifest.format = 'motif-kit@9'; out.format = K.install(c7);
  const short = r => ({ ok: r.ok, e: (r.errors || [])[0] || '' });
  return Object.fromEntries(Object.entries(out).map(([k, v]) => [k, short(v)]));
});
check('K6a', 'The SDK starter kit installs cleanly', val.starter.ok);
check('K6b', 'Kits without an id are rejected', !val.noId.ok, val.noId.e);
check('K6c', 'Shader compile errors are rejected with the pass-local line number', !val.compile.ok && /line \d+/.test(val.compile.e), val.compile.e.slice(0, 120));
check('K6d', 'Duplicate style ids are rejected', !val.dupe.ok, val.dupe.e);
check('K6e', 'Shared parameter names (seed, zoom…) are rejected', !val.reserved.ok, val.reserved.e);
check('K6f', 'Defaults outside their range are rejected', !val.range.ok, val.range.e);
check('K6g', 'Passes that define their own main() are rejected', !val.main.ok, val.main.e);
check('K6h', 'Unknown kit formats are rejected', !val.format.ok, val.format.e);

// K7 integration: select, palette adoption, mutate, keyframe, export frame, preset round trip, missing-kit guard
const integ = await page.evaluate(async () => {
  const L = __lab, T = L.api.timeline; const out = {};
  let pr = T.newProject('orbit-rings'); L.setProject(pr);
  L.selectStyle('neuro/mitosis'); await new Promise(r => setTimeout(r, 50));
  let p = L.project, l = p.layers[0]; out.style = l.styleId; out.palette = l.shared.palette;
  const before = JSON.stringify(l.params); L.mutate(); p = L.project; out.mutated = JSON.stringify(p.layers[0].params) !== before;
  let q = T.setKey(p, `L:${l.id}:p:cleave`, 0, 0, 'linear'); q = T.setKey(q, `L:${l.id}:p:cleave`, 0.5, 1, 'linear');
  const ev = T.evaluate(q, q.finish.loop * 0.25); out.keyed = ev.layers[0].params.cleave;
  L.setProject(q);
  const json = L.presetJSON(); const back = L.parsePreset(json); out.roundTrip = back.project.layers[0].styleId === 'neuro/mitosis' && back.project.layers[0].params.chromosomes === q.layers[0].params.chromosomes;
  const fake = JSON.parse(json); (fake.project || fake).layers[0].styleId = 'ghost/nothing'; out.missing = L.kits.missingKits(fake.project || fake);
  const ex = await L.exportNow({ format: 'png', tier: 360 }).catch(e => ({ err: String(e) }));
  out.export = ex.err ? ex.err : `${ex.type} ${ex.size}`;
  // blocked removal while in use
  const before2 = L.kits.list().length; document.querySelector('[data-tab=kits]').click(); await new Promise(r => setTimeout(r, 100));
  const rm = document.querySelector('[data-remove="neuro"]'); rm && rm.click(); await new Promise(r => setTimeout(r, 50));
  out.blocked = L.kits.list().length === before2 && /uses this kit/.test(L.kitMsg.text);
  return out;
});
check('K7a', 'Picking a kit style adopts the kit palette', integ.style === 'neuro/mitosis' && integ.palette.startsWith('neuro.'), `${integ.style} · ${integ.palette}`);
check('K7b', 'Mutate works on kit parameters', integ.mutated);
check('K7c', 'Kit parameters keyframe like built-ins', Math.abs(integ.keyed - 0.5) < 1e-6, `cleave @¼ = ${integ.keyed}`);
check('K7d', 'Presets round-trip kit styles', integ.roundTrip);
check('K7e', 'Presets that need a missing kit are detected', integ.missing.length === 1 && integ.missing[0] === 'ghost', JSON.stringify(integ.missing));
check('K7f', 'Kit styles export (PNG frame)', /image\/png \d+/.test(integ.export), integ.export);
check('K7g', 'Removing a kit that a layer uses is blocked with a reason', integ.blocked);

// K8 photosensitive limiter: WCAG 2.3.1 general-flash count per screen tile (4×4), every kit style,
// worst-case timing (1 s loop × tempo 4 = 0.25 s effective loop) with the limiter on; defaults with it off for reference.
const flashRun = (cfg) => page.evaluate(async (cfg) => {
  const L = __lab, T = L.api.timeline;
  const ids = L.styles.filter(s => s.kit).map(s => s.id);
  const lin = c => { c /= 255; return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); };
  const tiles = (d, w, h) => { const out = new Float64Array(16), n = new Float64Array(16); for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const i = (y * w + x) * 4, t = Math.floor(y * 4 / h) * 4 + Math.floor(x * 4 / w); out[t] += 0.2126 * lin(d[i]) + 0.7152 * lin(d[i + 1]) + 0.0722 * lin(d[i + 2]); n[t]++; } return [...out].map((v, i) => v / n[i]); };
  const transitions = seq => { const tr = []; let dir = 0, ref = seq[0], lo = seq[0], hi = seq[0];
    for (let i = 1; i < seq.length; i++) { const v = seq[i];
      if (dir === 0) { lo = Math.min(lo, v); hi = Math.max(hi, v); if (v - lo >= 0.1 && lo < 0.8) { dir = 1; ref = v; tr.push(i); } else if (hi - v >= 0.1 && v < 0.8) { dir = -1; ref = v; tr.push(i); } }
      else if (dir > 0) { if (v > ref) ref = v; else if (ref - v >= 0.1 && v < 0.8) { dir = -1; ref = v; tr.push(i); } }
      else { if (v < ref) ref = v; else if (v - ref >= 0.1 && ref < 0.8) { dir = 1; ref = v; tr.push(i); } } }
    return tr; };
  const worstPerSecond = (id, safe, worst) => {
    L.kits.setSafe(safe);
    const pr = T.newProject(id); const kit = L.kits.list().find(k => id.startsWith(k.id + '/')); pr.layers[0].shared.palette = kit.palettes[0].id;
    if (worst) { pr.finish.loop = cfg.loop; pr.layers[0].shared.tempo = cfg.tempo; const ps = pr.layers[0].params; for (const k of ['flash', 'pulse', 'static', 'arcRate', 'flicker', 'intensity', 'decay', 'pops']) if (typeof ps[k] === 'number') ps[k] = 1.5; }
    const fps = 30, secs = Math.max(2, pr.finish.loop); const series = Array.from({ length: 16 }, () => []);
    for (let i = 0; i <= fps * secs; i++) { const tl = tiles(L.renderAt(pr, i / fps, 64, 36).data, 64, 36); tl.forEach((v, j) => series[j].push(v)); }
    let worstN = 0; for (const s of series) { const tr = transitions(s); for (let a = 0; a + fps <= s.length; a++) worstN = Math.max(worstN, Math.floor(tr.filter(t => t >= a && t < a + fps).length / 2)); }
    return worstN;
  };
  const out = (cfg.only ? ids.filter(i => cfg.only.includes(i)) : ids).map(id => ({ id, safeWorst: worstPerSecond(id, true, true), offDefault: cfg.off ? worstPerSecond(id, false, false) : null }));
  L.kits.setSafe(true);
  return out;
}, cfg);
const flash = await flashRun({ loop: 6, tempo: 4, off: true });
const flashX = await flashRun({ loop: 1, tempo: 4, off: false });
const fBad = flash.filter(f => f.safeWorst > 3);
check('K8a', 'Limiter on: every kit style stays at ≤ 3 flashes in any second, per screen tile, at 4× tempo (1.5 s effective loop)', !fBad.length, fBad.map(f => `${f.id}:${f.safeWorst}`).join(', ') || `worst ${Math.max(...flash.map(f => f.safeWorst))}; limiter off at defaults: ${flash.filter(f => f.offDefault > 3).map(f => f.id.split('/')[1] + ' ' + f.offDefault).join(', ') || 'none above 3'}`);

const fxBad = flashX.filter(f => f.safeWorst > 3);
check('K8b', 'Limiter on: still ≤ 3 flashes per second per tile at the extreme 0.25 s effective loop (temporal low-pass engages)', !fxBad.length, fxBad.map(f => `${f.id}:${f.safeWorst}`).join(', ') || `worst ${Math.max(...flashX.map(f => f.safeWorst))}`);

// K9 persistence: an imported kit survives reload; removing a bundled kit sticks
const persist = await page.evaluate(() => { __lab.setProject(__lab.api.timeline.newProject('orbit-rings')); return __lab.kits.remove('cyberpunk'); });
await page.reload(); await page.waitForFunction(() => !!window.__lab);
const after = await page.evaluate(() => ({ kits: __lab.kits.list().map(k => k.id), n: __lab.styles.length, cat: __lab.kits.catalog().filter(c => !c.installed).map(c => c.id) }));
check('K9', 'Imported kits persist across reloads; a removed bundled kit stays removed and reinstallable', persist && after.kits.includes('my-kit') && !after.kits.includes('cyberpunk') && after.cat.includes('cyberpunk'), JSON.stringify(after));
const reinst = await page.evaluate(() => __lab.kits.installCatalog('cyberpunk').ok);
check('K9b', 'A bundled kit reinstalls from the catalog', reinst);

// K10 Kit Manager UI + a11y basics
const ui = await page.evaluate(async () => {
  __lab.setTab('kits'); await new Promise(r => setTimeout(r, 300));
  const panel = document.getElementById('panel-kits');
  const sw = [...panel.querySelectorAll('input.switch')];
  const unlabeled = sw.filter(s => !(s.getAttribute('aria-label') || s.closest('label'))).length;
  const btns = [...panel.querySelectorAll('button')].filter(b => !b.textContent.trim() && !b.getAttribute('aria-label')).length;
  const tab = document.querySelector('[data-tab=kits]'); const r = tab.getBoundingClientRect();
  const chips = [...document.querySelectorAll('#cats .chip')].map(c => c.textContent.trim());
  return { cards: panel.querySelectorAll('.kit-card').length, unlabeled, btns, tabVisible: r.width > 20 && r.right <= innerWidth + 1, chips, drop: !!document.getElementById('dropzone') };
});
check('K10', 'Kit Manager lists kits, every control is labelled, the tab fits, kit chips filter the library', ui.cards >= 3 && !ui.unlabeled && !ui.btns && ui.tabVisible && ui.chips.includes('Neuro') && ui.drop, JSON.stringify(ui));
await page.screenshot({ path: path.join(root, 'kits/out/kits-panel.png') });

// K11 perf summary (SwiftShader, CPU-emulated GL: an upper bound, not a hardware number)
const ms = perStyle.map(s => s.ms).sort((a, b) => a - b);
check('K11', 'Per-style frame time recorded (160×90, SwiftShader)', true, `median ${ms[Math.floor(ms.length / 2)].toFixed(0)} ms · max ${ms[ms.length - 1].toFixed(0)} ms (${perStyle.find(s => s.ms === ms[ms.length - 1]).id})`);
check('K12', 'No page errors', !errors.length, errors.slice(0, 3).join(' | '));

fs.writeFileSync(path.join(root, 'tests/kits-results.json'), JSON.stringify({ when: new Date().toISOString(), seconds: (Date.now() - t0) / 1000, pass: results.filter(r => r.pass).length, total: results.length, results, flash, flashX }, null, 1));
console.log(`\n${results.filter(r => r.pass).length}/${results.length} passed in ${((Date.now() - t0) / 1000).toFixed(0)} s`);
await browser.close(); srv.close();

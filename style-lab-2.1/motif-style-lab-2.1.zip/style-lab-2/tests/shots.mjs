// Screenshots at desktop, tablet and iPhone; checks the preview stays in view while the panel scrolls.
import { serve, launch, open } from './lib.mjs';
const OUT = process.env.OUT || '/tmp/claude-0/-home-claude/f5dffad5-6f41-5b9b-94f1-fcd143c6df84/scratchpad';
const s = await serve(); const b = await launch(); const res = [];
const views = [
  { name: 'desktop', vp: { width: 1440, height: 900 } },
  { name: 'laptop', vp: { width: 1280, height: 720 } },
  { name: 'tablet-land', vp: { width: 1024, height: 768 }, mobile: true },
  { name: 'iphone', vp: { width: 390, height: 844 }, mobile: true, dpr: 2 },
];
for (const v of views) {
  const { page, errors } = await open(b, s.url, v.vp, { mobile: v.mobile, dpr: v.dpr });
  await page.evaluate(() => { window.__lab.stage.pause(); window.__lab.stage.seekTime(2.6); });
  await page.waitForTimeout(1200);
  const tabs = (process.env.TABS || 'layer').split(',');
  for (const t of tabs) {
    await page.evaluate(t => window.__lab.setTab(t), t); await page.waitForTimeout(400);
    await page.screenshot({ path: `${OUT}/shot-${v.name}-${t}.png` });
    // Scroll the inspector (or page) to the bottom and check the stage is still fully visible.
    const r = await page.evaluate(() => { const i = document.getElementById('insp'); i.scrollTop = i.scrollHeight; window.scrollTo(0, 99999); const c = document.getElementById('stage').getBoundingClientRect(); return { top: c.top, bottom: c.bottom, h: innerHeight, docScroll: document.scrollingElement.scrollTop, inspScroll: i.scrollTop, inspMax: i.scrollHeight - i.clientHeight }; });
    res.push({ view: v.name, tab: t, pinned: r.top >= 0 && r.bottom <= r.h && r.docScroll === 0, ...r });
    if (t === tabs[tabs.length - 1]) await page.screenshot({ path: `${OUT}/shot-${v.name}-${t}-scrolled.png` });
  }
  if (errors.length) res.push({ view: v.name, errors: errors.slice(0, 5) });
  await page.context().close();
}
console.log(JSON.stringify(res, null, 1));
await b.close(); s.close();

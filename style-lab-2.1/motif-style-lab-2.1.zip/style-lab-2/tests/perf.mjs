// Performance probe → tests/perf.json. Canvas 2D numbers are real CPU raster timings; WebGL2/WebGPU run on
// SwiftShader (CPU emulation) here, so their numbers are upper bounds, not hardware estimates.
import { serve, launch, open, root } from './lib.mjs';
import fs from 'node:fs'; import path from 'node:path';
const s = await serve(); const b = await launch();
const { page } = await open(b, s.url);
await page.waitForFunction(() => !['init', 'idle'].includes(window.__lab.gpu.state), null, { timeout: 60000 });
const r = await page.evaluate(async () => {
  const lab = window.__lab, T = lab.api.timeline; lab.stage.pause(); const W = 1440, H = 810;
  const single = id => { const p = T.newProject(id); p.finish.grain = 0; p.finish.vignette = 0; return p; };
  const med = a => a.sort((x, y) => x - y)[Math.floor(a.length / 2)];
  const timeIt = (p, n = 5, opts = {}) => { lab.renderAt(p, 0.5, W, H, opts); const ts = []; for (let i = 0; i < n; i++) ts.push(lab.renderAt(p, 0.7 + i * 0.37, W, H, opts).ms); return +med(ts).toFixed(1); };
  lab.gpu.setForceCpu(true);
  const styles = lab.styles.map(st => ({ id: st.id, ms: timeIt(single(st.id), 5) }));
  const demo = lab.project; const demoNoFinish = JSON.parse(JSON.stringify(demo)); Object.assign(demoNoFinish.finish, { glow: 0, grain: 0, vignette: 0 });
  const composite = { demo3LayersCanvas2D: timeIt(demoNoFinish, 4) };
  const withFinish = { demoWithGlowWebGL: timeIt(demo, 3) };
  const blur = JSON.parse(JSON.stringify(demoNoFinish)); blur.finish.shutter = 180; blur.finish.samples = 8;
  withFinish.demoMotionBlur8 = timeIt(blur, 2);
  lab.gpu.setForceCpu(false);
  const gpu = {};
  for (const [id, count] of [['particle-form', 200000], ['orbital-swarm', 200000], ['flow-field', 20000]]) { const p = single(id); p.layers[0].params.count = count; gpu[`${id}@${count}`] = timeIt(p, 3); await new Promise(r => setTimeout(r, 200)); }
  return { size: `${W}x${H}`, styles, composite, withFinish, gpu, gpuState: lab.gpu.state };
});
const sorted = r.styles.map(x => x.ms).sort((a, b) => a - b);
const out = { at: new Date().toISOString(), note: 'Canvas 2D = CPU raster (real). WebGL2 finish and WebGPU run on SwiftShader CPU emulation in this sandbox: treat as upper bounds.', ...r, medianStyleMs: sorted[12], over16ms: r.styles.filter(x => x.ms > 16.7).map(x => `${x.id} ${x.ms}`) };
fs.writeFileSync(path.join(root, 'tests/perf.json'), JSON.stringify(out, null, 2));
console.log(JSON.stringify({ median: out.medianStyleMs, over16: out.over16ms, composite: r.composite, finish: r.withFinish, gpu: r.gpu }, null, 1));
await b.close(); s.close();

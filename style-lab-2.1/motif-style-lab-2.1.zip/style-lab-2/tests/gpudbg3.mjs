import { serve, launch, open } from './lib.mjs';
const s = await serve(); const b = await launch();
const { page, errors } = await open(b, s.url);
page.on('console', m => { if (!/TUNNEL|experimental|GroupMarker/.test(m.text())) console.log('console', m.type(), m.text().slice(0, 400)); });
await page.waitForFunction(() => !['init', 'idle'].includes(window.__lab.gpu.state), null, { timeout: 60000 });
await page.evaluate(() => window.__lab.stage.pause());
const r = await page.evaluate(async () => {
  const lab = window.__lab, T = lab.api.timeline; const out = {};
  for (const id of ['metaballs', 'flow-field']) {
    const p = T.newProject(id); p.finish.grain = 0; p.finish.vignette = 0;
    const x = lab.renderAt(p, 1.2, 160, 90); await new Promise(r => setTimeout(r, 500));
    let lit = 0; for (let i = 0; i < x.data.length; i += 4) if (Math.abs(x.data[i] - x.data[0]) > 30) lit++;
    out[id] = { engine: x.info.engines[0], lit, state: lab.gpu.state, reason: lab.gpu.reason, px0: Array.from(x.data.slice(0, 4)), mid: Array.from(x.data.slice((45 * 160 + 80) * 4, (45 * 160 + 80) * 4 + 4)) };
  }
  // demo determinism
  const d = lab.project; d.finish.grain = 0; const a = lab.renderAt(d, 0, 192, 108).data, a2 = lab.renderAt(d, 0, 192, 108).data, z = lab.renderAt(d, d.finish.loop, 192, 108).data;
  out.demo = { same0: window.__lab && (() => { let m = 0; for (let i = 0; i < a.length; i++) m = Math.max(m, Math.abs(a[i] - a2[i])); return m; })(), loop: (() => { let m = 0, n = 0; for (let i = 0; i < a.length; i++) { const v = Math.abs(a[i] - z[i]); if (v > 0) n++; m = Math.max(m, v); } return [m, n]; })() };
  return out;
});
console.log(JSON.stringify(r, null, 1));
await b.close(); s.close();

import { serve, launch, open } from './lib.mjs';
const s = await serve(); const b = await launch();
const { page } = await open(b, s.url);
await page.waitForFunction(() => !['init', 'idle'].includes(window.__lab.gpu.state), null, { timeout: 60000 });
await page.evaluate(() => window.__lab.stage.pause());
const r = await page.evaluate(async () => {
  const lab = window.__lab; const out = {};
  const md = (a, b) => { let m = 0, n = 0; for (let i = 0; i < a.length; i++) { const v = Math.abs(a[i] - b[i]); if (v) n++; m = Math.max(m, v); } return [m, n]; };
  const run = (name, mod, cpu) => { const d = lab.project; d.finish.grain = 0; mod(d); lab.gpu.setForceCpu(!!cpu); const a = lab.renderAt(d, 0, 192, 108).data, a2 = lab.renderAt(d, 0, 192, 108).data; lab.gpu.setForceCpu(false); out[name] = md(a, a2); };
  run('full', () => {}); run('full2', () => {}); run('full3-glowonly', d => { d.finish.vignette = 0; });
  run('cpu', () => {}, true);
  run('noglow', d => { d.finish.glow = 0; d.finish.vignette = 0; });
  run('noglow-cpu', d => { d.finish.glow = 0; d.finish.vignette = 0; }, true);
  for (let i = 0; i < 3; i++) run('layer' + i, d => { d.layers = [d.layers[i]]; d.finish.glow = 0; d.finish.vignette = 0; }, true);
  run('plexus-halftone', d => { d.layers = d.layers.slice(0, 2); d.finish.glow = 0; d.finish.vignette = 0; }, true);
  return out;
});
console.log(JSON.stringify(r));
await b.close(); s.close();

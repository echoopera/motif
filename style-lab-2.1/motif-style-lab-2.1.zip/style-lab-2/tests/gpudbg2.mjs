import { serve, launch, open } from './lib.mjs';
const s = await serve(); const b = await launch();
const { page, errors } = await open(b, s.url);
page.on('console', m => { if (!/TUNNEL/.test(m.text())) console.log('console', m.type(), m.text().slice(0, 300)); });
await page.evaluate(() => { window.__lab.gpu.setForceCpu(true); window.__lab.stage.pause(); });
await page.waitForFunction(() => window.__lab.gpu.state === 'off' || window.__lab.gpu.state === 'unavailable', null, { timeout: 30000 });
const style = process.argv[2] || 'orbital-swarm';
const r = await page.evaluate(async (style) => {
  const g = window.__lab.gpu; g.setForceCpu(false);
  const { mulberry32 } = { mulberry32: null };
  const pr = window.__lab.project;
  const S = { w: 320, h: 180, u: 180, t: 1, p: 0.3, L: 6, seed: 417, P: null, pal: null };
  // build params from a fresh layer via selectStyle on a copy
  const layer = pr.layers[2]; 
  return 'ok';
}, style);
// Use renderAt with a single-layer project of that style
const out = await page.evaluate(async (style) => {
  const pr = window.__lab.project; pr.layers = [pr.layers[2]]; pr.active = pr.layers[0].id; pr.keys = {};
  const lab = window.__lab; lab.setProject(pr); lab.selectStyle(style);
  const p2 = lab.project;
  const res = [];
  for (let i = 0; i < 3; i++) { const r = lab.renderAt(p2, 1 + i * 0.1, 320, 180); res.push([r.info.engines.join(), lab.gpu.state, r.ms.toFixed(1)]); await new Promise(r => setTimeout(r, 300)); }
  return res;
}, style);
console.log(style, JSON.stringify(out));
console.log(errors.filter(e => !/TUNNEL/.test(e)).join('\n'));
await b.close(); s.close();

import { serve, launch, open } from './lib.mjs';
const s = await serve(); const b = await launch();
const { page, errors } = await open(b, s.url);
page.on('console', m => console.log('console', m.type(), m.text().slice(0, 400)));
for (let i = 0; i < 30; i++) { const st = await page.evaluate(() => [window.__lab.gpu.state, window.__lab.gpu.reason, JSON.stringify(window.__lab.stage.info && window.__lab.stage.info.engines)]); console.log(i, st.join(' | ')); if (st[0] !== 'init') { if (st[0] !== 'ready') break; } await page.waitForTimeout(1000); }
console.log(errors.join('\n'));
await b.close(); s.close();

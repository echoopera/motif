import { serve, launch, open } from './lib.mjs';
const s = await serve(); const b = await launch();
const { page } = await open(b, s.url);
await page.waitForFunction(() => !['init', 'idle'].includes(window.__lab.gpu.state), null, { timeout: 60000 });
await page.evaluate(() => window.__lab.stage.pause());
const r = await page.evaluate(async () => {
  const lab = window.__lab, T = lab.api.timeline; const out = {};
  const single = (id, params) => { const p = T.newProject(id); p.finish.grain = 0; p.finish.vignette = 0; Object.assign(p.layers[0].params, params); return p; };
  for (const [id, over] of [['particle-form', { count: 150000 }], ['orbital-swarm', { count: 200000 }], ['flow-field', { count: 40000 }], ['metaballs', { resolution: 'full' }], ['flow-field', { count: 2000 }]]) {
    const p = single(id, over); lab.renderAt(p, 1, 480, 270); const r = lab.renderAt(p, 1.2, 480, 270);
    const hist = new Map(); for (let i = 0; i < r.data.length; i += 4) { const k = r.data[i] + ',' + r.data[i + 1] + ',' + r.data[i + 2]; hist.set(k, (hist.get(k) || 0) + 1); }
    out[id + over.count] = { engine: r.info.engines, colours: hist.size, top: [...hist.entries()].sort((a, b) => b[1] - a[1]).slice(0, 3), state: lab.gpu.state, ms: r.ms };
  }
  return out;
});
console.log(JSON.stringify(r, null, 0));
await b.close(); s.close();

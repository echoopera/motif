import { serve, launch, open } from './lib.mjs';
const s = await serve(); const b = await launch(); const out = {};
for (const [n, vp, m] of [['desktop', { width: 1440, height: 900 }, false], ['iphone', { width: 390, height: 844 }, true]]) {
  const { page } = await open(b, s.url, vp, { mobile: m });
  out[n] = await page.evaluate(async () => {
    const res = { unnamed: [], small: 0, total: 0 };
    for (const tab of ['layer', 'colour', 'finish', 'audio', 'looks']) {
      window.__lab.setTab(tab); await new Promise(r => setTimeout(r, 100));
      for (const el of document.querySelectorAll('button, input, select, [role=option], [role=tab]')) {
        if (!el.offsetParent || el.classList.contains('file')) continue; res.total++;
        const name = el.getAttribute('aria-label') || el.textContent.trim() || (el.id && document.querySelector(`label[for="${el.id}"]`)?.textContent) || el.closest('label')?.textContent.trim() || el.title;
        if (!name) res.unnamed.push(el.outerHTML.slice(0, 80));
        const r = el.getBoundingClientRect(); if (el.type !== 'range' && (r.height < 24 || r.width < 24)) res.small++;
      }
    }
    res.unnamed = [...new Set(res.unnamed)].slice(0, 8); return res;
  });
  await page.context().close();
}
console.log(JSON.stringify(out, null, 1)); await b.close(); s.close();

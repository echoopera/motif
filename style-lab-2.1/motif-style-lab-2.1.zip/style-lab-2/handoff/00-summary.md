# Motif Style Lab 2.1: handoff summary

Style Lab 2 plus **kits**. A kit is a `.motifkit` package of GLSL shader styles, palettes and metadata. The app stays one build: it validates a kit, test-compiles it and registers its styles at load. Kit styles then work like built-ins: layers, blend modes, masks, keyframes, Mutate/Evolve, audio maps, the finishing stack, presets and every export format.

- **Bundled kits (54 styles):** Neuro, Quantum and Cyberpunk. Each has 18 styles with 8–14 parameters and 4 palettes, and every style loops seamlessly.
- **Kit Manager (Kits tab):** import by file, drag-and-drop anywhere or URL. Enable, disable, update, remove, export `.motifkit`, reinstall bundled kits, download the starter kit. A photosensitive limiter is on by default.
- **Kit SDK (`kits/sdk`):** the `motif-kit` CLI (`new`, `validate`, `preview`, `pack`, `prelude`), a two-style template and the format spec in its README.
- **Run:** open `dist/index.html`. **Build:** run `node kits/tools/sdk-build.mjs && node kits/tools/pack.mjs && node build/build.js`.
- **Tests:** `tests/e2e.mjs` (Lab 2 regression, 39 checks) and `tests/kits-e2e.mjs` (kit system). Both run under `xvfb-run`. Per-style numbers are in `tests/kits-perstyle.json` and `tests/kits-results.json`.
- **Known limits:** no JavaScript or WebGPU-compute kit renderers yet (kits are GLSL ES 3.0, stateless per frame). Performance was measured on SwiftShader only. URL import depends on the host allowing cross-origin downloads.

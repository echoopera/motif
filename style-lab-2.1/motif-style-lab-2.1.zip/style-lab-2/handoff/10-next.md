# Next

1. Time every kit style on real GPUs (M-series, a mid-range PC, an iPhone) at 1080p and 4K. Set a per-style budget and add a quality parameter wherever a style misses 60 fps.
2. Add a kit renderer for WebGPU compute (stateless: particle state computed from the phase), so N-body and agent sims can ship as kits.
3. Kit signing and a shared kit library (Projects or a studio registry) so teams can install from a trusted list.
4. Give kits the preset@2 "look" format so a kit can ship curated looks (layers, keys, finish) as well as styles.
5. Expose the kit API over the Motif MCP bridge: list, install and author kits from Claude Code, with the `critic` skill scoring contact sheets.
6. Carry the limiter's temporal low-pass over to the built-in styles.

# Decision log — motif-style-lab-2

## D-01 · studio-director · P1

**Scope v2 to enhancements 1, 2, 4, 5, 7, 8 plus a pinned preview; 3, 6, 9, 10 stay in the PRD backlog**

- Why: Echo's priority order; these six change what a finished piece can be, the rest change delivery and collaboration
- Rejected: Ship all ten; Ship 1 and 2 only
- Cost: Font upload, ProRes and grid view wait

## D-02 · creative-director · P2

**Direction holds: Instrument Bench. New surfaces (layers, lane, palette editor, finish, audio) are panels in the same quiet chrome; the canvas stays the loudest thing**

- Why: Continuity with v1 and fieldSYS; artwork colour must read true for brand matching
- Rejected: Dark cinema UI; Floating HUD panels
- Cost: Denser inspector, mitigated by tabs

## D-03 · creative-tools-designer · P2

**Pinned preview everywhere: desktop keeps the centre stage fixed while side panels scroll; under 1100 px the page becomes a fixed shell — bar, stage, lane, tab strip, then one scrolling panel**

- Why: Body scroll is what pushes the preview away; making only the panel scroll keeps it in view on iPhone Safari without position:sticky edge cases
- Rejected: position:sticky stage on a scrolling page; Floating mini-preview
- Cost: Library moves into a tab on phones

## D-04 · systems-architect · P1

**Project model v2: layers[] of v1 looks + blend/opacity/mask, a global finish block, keys{path:[{u,v,ease}]}, audio{bpm,bars,offset,maps[]}. Every value addressed by one path grammar: L:<id>:p|s:<key> and F:<key>**

- Why: One address space lets keys, audio maps, locks and a future MCP surface share code
- Rejected: Separate stores per feature
- Cost: Paths must be migrated if a style renames a key

## D-05 · motion-designer · P1

**Keys use normalised loop time u∈[0,1) and interpolate cyclically (last key wraps to first)**

- Why: Keeps every keyed loop seamless by construction, which v1's pure-function guarantee depends on
- Rejected: Linear timeline with hold at the ends
- Cost: No one-shot ramps; a 0→1 build returns to 0 across the wrap unless a second key holds it

## D-06 · motion-designer · P2

**Numeric keys ease with linear, smooth, ease-in, ease-out or hold; selects, toggles and text hold; palette keys cross-fade colours unless the key is hold**

- Why: Covers the two examples in the ask (burst build, palette shift at a moment)
- Rejected: Bezier graph editor
- Cost: No custom curves yet; the Motif graph editor covers that

## D-07 · graphics-engineer · P1

**Layers composite on Canvas 2D with native blend modes; masks are shapes or track mattes applied with destination-in**

- Why: All 11 blend modes are native, fast and identical in export
- Rejected: WebGL compositor
- Cost: Masks are 8-bit

## D-08 · graphics-engineer · P1

**Motion blur is temporal supersampling: N sub-frames across the shutter interval, accumulated with running-average alpha; preview uses fewer samples than export**

- Why: Exact for procedural styles because every frame is a pure function of time
- Rejected: Velocity-buffer blur
- Cost: Cost scales with samples; preview auto-drops samples

## D-09 · graphics-engineer · P1

**Finishing stack runs in one WebGL2 pass chain: threshold glow, chromatic offset, depth blur, levels, gradient map, grain, vignette, broadcast limiter**

- Why: WebGL2 is available on every target including iPhone; fixed cost per pixel
- Rejected: Canvas 2D filters; WebGPU post
- Cost: Depth is estimated (tilt, radial, luma) because styles emit no Z buffer yet

## D-10 · graphics-engineer · P1

**WebGPU engine for Flow Field, Orbital Swarm, Metaballs, Particle Form: compute + instanced quads, same seeded simplex permutation table as the CPU path, counts to 200,000; Canvas 2D fallback when no adapter**

- Why: Matching noise keeps GPU and CPU looks close; fallback keeps the page working everywhere
- Rejected: WebGL2 transform feedback
- Cost: GPU and CPU differ at float precision

## D-11 · colour-scientist · P2

**Colour spaces: sRGB default; Display P3 renders into P3 canvases and tags PNG/video; Rec.709 tags BT.709 limited range and passes sRGB-encoded values unchanged (industry practice for graphics)**

- Why: Honest tagging without silent gamma shifts
- Rejected: Convert sRGB→709 OETF
- Cost: Rec.709 is a tag plus limiter, not a re-grade

## D-12 · audio-engineer · P2

**Audio analysed offline at 60 envelope frames per second (FFT 2048): 8 bands, onset flux, tempo by autocorrelation of flux (70–180 BPM) with downbeat phase by comb alignment**

- Why: Offline envelopes make audio-driven renders deterministic and exportable
- Rejected: Realtime AnalyserNode only
- Cost: Live input is preview-only and never exported


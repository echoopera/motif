// NEURO kit common helpers.
// Soft membrane rim for a disc of signed distance d (negative inside), width w.
float membrane(float d, float w) { return exp(-d * d / (w * w)); }
// Tapered segment glow: returns (core, halo).
vec2 fiber(float d, float w) { return vec2(1.0 - smoothstep(w * 0.5, w * 0.5 + aa(), d), glow2(d, w * 1.5)); }

// Organoid (pass 1, half resolution) — raymarched cell cluster.
float ORG_cellR(int i) { return 0.11 * p_cellSize * (0.8 + 0.4 * h11(float(i) + 7.0)); }
vec3 ORG_center(int i, int N) {
  float fi = float(i) + 0.5;
  float y = 1.0 - 2.0 * fi / float(N);
  float r = sqrt(1.0 - y * y);
  float th = fi * 2.39996323;
  vec3 d = vec3(cos(th) * r, y, sin(th) * r);
  float h = h11(float(i));
  float rad = p_radius * (1.0 + p_bloom * 0.35 * (0.5 + 0.5 * lsin(float(p_budding), h)));
  return d * rad + 0.03 * p_bloom * vec3(lc(1.0, h), lsin(2.0, h * 3.0));
}
float ORG_map(vec3 p, int N) {
  float d = 1e9;
  for (int i = 0; i < 48; i++) {
    if (i >= N) break;
    float r = ORG_cellR(i) * (1.0 + 0.25 * p_bloom * lsin(float(p_budding), h11(float(i) + 2.0)));
    d = smin(d, length(p - ORG_center(i, N)) - r, 0.06 * p_smooth + 0.005);
  }
  return d + p_displace * 0.01 * snoise(p * 18.0 + vec3(lc(1.0, 0.0), 0.0));
}
vec4 motif(vec2 uv, vec2 fc) {
  int N = p_cells;
  float ang = TAU * u_p * float(p_spin);
  vec3 ro = vec3(sin(ang) * 1.6, 0.35, cos(ang) * 1.6);
  vec3 ta = vec3(0.0);
  vec3 f = normalize(ta - ro), r = normalize(cross(vec3(0.0, 1.0, 0.0), f)), u = cross(f, r);
  vec3 rd = normalize(f * 1.6 + uv.x * r + uv.y * u);
  float bound = p_radius * 1.6 + 0.25;
  // bounding sphere
  float b = dot(ro, rd), c = dot(ro, ro) - bound * bound, disc = b * b - c;
  vec3 col = vec3(0.0); float a = 0.0;
  // nuclei seen through the translucent membrane (ray-to-centre distance)
  float nuc = 0.0;
  for (int i = 0; i < 48; i++) {
    if (i >= N) break;
    vec3 cc = ORG_center(i, N);
    float t = dot(cc - ro, rd);
    float d = length(ro + rd * t - cc);
    nuc += exp(-pow(d / (ORG_cellR(i) * 0.38), 2.0)) * (0.6 + 0.4 * h11(float(i) + 9.0));
  }
  if (disc > 0.0) {
    float t = -b - sqrt(disc); t = max(t, 0.0);
    float hit = 0.0; int steps = 24 + int(40.0 * p_quality);
    for (int i = 0; i < 64; i++) {
      if (i >= steps) break;
      float d = ORG_map(ro + rd * t, N);
      if (d < 0.0015) { hit = 1.0; break; }
      t += d * 0.9;
      if (t > 4.0) break;
    }
    if (hit > 0.0) {
      vec3 p = ro + rd * t;
      vec2 e = vec2(0.002, -0.002);
      vec3 n = normalize(e.xyy * ORG_map(p + e.xyy, N) + e.yyx * ORG_map(p + e.yyx, N) + e.yxy * ORG_map(p + e.yxy, N) + e.xxx * ORG_map(p + e.xxx, N));
      vec3 L = normalize(vec3(cos(p_light * TAU), 0.8, sin(p_light * TAU)));
      float dif = sat(dot(n, L));
      float fres = pow(1.0 - sat(dot(n, -rd)), 3.0);
      float thick = sat(ORG_map(p - n * 0.06, N) / -0.06);
      float sss = (1.0 - thick) * p_translucency;
      vec3 skin = mix(u_a2 * 0.6, u_ink * 0.9, 0.35 * dif);
      col = skin * (0.12 + 0.6 * dif) + u_a2 * sss * 0.5 + u_a0 * fres * p_rim * 1.4;
      col += mix(u_a1, u_ink, 0.2) * nuc * p_innerGlow * (0.4 + sss) * 0.7;
      col += u_ink * pow(sat(dot(reflect(-L, n), -rd)), 40.0) * 0.5;
      a = 1.0;
    }
  }
  col += u_a1 * nuc * p_innerGlow * 0.05 * (1.0 - a);
  return vec4(col, a);
}

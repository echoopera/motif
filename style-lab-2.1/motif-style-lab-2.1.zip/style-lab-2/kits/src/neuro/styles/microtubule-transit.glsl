// Microtubule Transit — kinesin motors step cargo along a cytoskeletal highway, dynein hauls it back.
vec4 motif(vec2 uv, vec2 fc) {
  vec2 A = M_asp() * 0.5;
  vec3 col = vec3(0.0); float cover = 0.0; float px = aa();
  for (int i = 0; i < 20; i++) {
    if (i >= p_filaments) break;
    float fi = float(i); vec3 h = h33(vec3(fi, 9.0, 1.0));
    vec2 c = (h.xy - 0.5) * A * 1.6;
    float ang = (h.z - 0.5) * 2.6 + 0.2 * fi;
    vec2 t = vec2(cos(ang), sin(ang)), nn = vec2(-t.y, t.x);
    vec2 q = uv - c;
    float s = dot(q, t);
    float bend = p_curve * 0.25 * sin(s * 3.0 + fi);
    float dn = dot(q, nn) - bend * 0.1;
    float depth = h.x;
    float blur = 1.0 + depth * 5.0 * p_depth;
    float fade = 1.0 - depth * 0.55 * p_depth;
    float wdt = 0.006 * p_width * (1.0 - 0.4 * depth);
    float d = abs(dn);
    float fil = 1.0 - smoothstep(wdt - px * blur, wdt + px * blur, d);
    // tubulin lattice: 13 protofilaments / 8 nm dimers suggested by a striped texture
    float lat = 0.6 + 0.4 * sin(s * 420.0 * p_lattice + dn * 800.0) * sin(dn / wdt * 3.0 + 0.5);
    col += mix(u_ink * 0.35, u_a0 * 0.8, 0.3 + 0.3 * lat) * fil * fade + u_a0 * glow2(d, wdt * 3.0) * 0.05 * p_glow * fade;
    cover = max(cover, fil * fade);
    // motors with cargo
    for (int j = 0; j < 4; j++) {
      if (j >= p_cargo) break;
      vec2 hj = h22(vec2(fi * 11.0 + float(j), 4.0));
      float dir = p_bidirectional && hj.y < 0.4 ? -1.0 : 1.0;
      float span = 2.4;
      // stepping: a travelling coordinate quantised into discrete steps with an ease in each
      float nsteps = 40.0 * p_stepSize + 8.0;
      float x = fract(u_p * float(p_speed) * (dir > 0.0 ? 1.0 : 1.0) + hj.x) * nsteps;
      float stepx = (floor(x) + smoothstep(0.55, 1.0, fract(x))) / nsteps;
      float along = (stepx - 0.5) * span * dir;
      vec2 base = c + t * along + nn * (p_curve * 0.25 * sin(along * 3.0 + fi) * 0.1);
      float cr = 0.018 * p_cargoSize * (0.7 + 0.6 * hj.y);
      vec2 cp = base + nn * (cr + 0.012);
      float dc = length(uv - cp) - cr;
      float cargo = 1.0 - smoothstep(-px * blur, px * blur, dc);
      vec3 cc = dir > 0.0 ? u_a1 : u_a2;
      col += cc * (cargo * (0.45 + 0.55 * sat(-dc / cr * 2.0)) + glow2(max(dc, 0.0), 0.01) * 0.3 * p_glow) * fade;
      // legs: two heads alternating each step
      float leg = fract(x);
      vec2 foot1 = base + t * (0.006 * (leg < 0.5 ? 1.0 : -1.0) * dir);
      vec2 foot2 = base - t * (0.006 * (leg < 0.5 ? 1.0 : -1.0) * dir);
      vec2 hip = base + nn * 0.012;
      float dl = min(sdSeg(uv, hip, foot1), sdSeg(uv, hip, foot2));
      float legs = 1.0 - smoothstep(0.0015, 0.0015 + px * blur, dl);
      col += mix(cc, u_ink, 0.5) * legs * fade;
      cover = max(cover, max(cargo, legs) * fade);
    }
  }
  col = aces(col * 1.1);
  return vec4(col, max(cover, max(col.r, max(col.g, col.b))));
}

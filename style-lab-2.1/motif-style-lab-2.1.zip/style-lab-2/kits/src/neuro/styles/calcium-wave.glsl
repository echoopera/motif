// Calcium Wave — two-photon view of a neural field: GCaMP cells flash and spreading waves ripple through the network.
vec4 motif(vec2 uv, vec2 fc) {
  vec2 A = M_asp() * 0.5;
  float sc = 7.0 * p_density;
  vec2 p = uv * sc;
  vec2 n = floor(p);
  vec3 col = vec3(0.0);
  // neuropil haze
  float haze = lfbm(uv * 6.0, 4, 1.0, 0.25) * 0.5 + 0.5;
  // waves: expanding rings from origins
  float waveField = 0.0;
  for (int w = 0; w < 4; w++) {
    if (w >= p_waves) break;
    vec2 h = h22(vec2(float(w), 77.0));
    vec2 o = (h - 0.5) * A * 1.6;
    float ph = fract(u_p * float(p_waveSpeed) + h.x);
    float r = ph * 1.4;
    float d = length(uv - o) - r;
    waveField += exp(-d * d * 180.0) * (1.0 - ph) + exp(-max(-d, 0.0) * 6.0) * step(d, 0.0) * (1.0 - ph) * 0.35;
  }
  col += u_a0 * haze * p_haze * (0.05 + 0.25 * waveField);
  float cover = 0.0;
  for (int j = -1; j <= 1; j++) for (int i = -1; i <= 1; i++) {
    vec2 c = n + vec2(float(i), float(j));
    vec3 h = h33(vec3(c, 3.0));
    if (h.z > 0.8) continue;
    vec2 site = c + 0.2 + 0.6 * h.xy;
    vec2 d = p - site;
    float depth = h.z;
    float r = 0.16 * p_soma * (0.7 + 0.6 * h.x);
    float ds = length(d) - r;
    float blur = 0.02 + depth * 0.25 * p_focus;
    float soma = 1.0 - smoothstep(-blur, blur, ds);
    // dendrite stubs
    float den = 0.0;
    for (int k = 0; k < 3; k++) {
      float a = TAU * h11(h.x * 10.0 + float(k)) ;
      vec2 e = vec2(cos(a), sin(a)) * (0.35 + 0.3 * h.y) * p_dendrites;
      den = max(den, 1.0 - smoothstep(0.015, 0.04 + blur, sdSeg(d, vec2(0.0), e)));
    }
    // activity: spontaneous events (slot-based, limited) + the wave arriving at this cell
    float slot = tslot(12.0 * p_rate + 1.0);
    float ev = step(1.0 - 0.18 * p_rate, h11(slot * 7.13 + h.x * 91.0));
    float ft = tfrac(12.0 * p_rate + 1.0);
    float spont = ev * smoothstep(0.0, 0.12, ft) * exp(-ft * 4.0 / p_decay);
    vec2 wc = site / sc;
    float wv = 0.0;
    for (int w = 0; w < 4; w++) {
      if (w >= p_waves) break;
      vec2 hw = h22(vec2(float(w), 77.0));
      vec2 o = (hw - 0.5) * A * 1.6;
      float ph = fract(u_p * float(p_waveSpeed) + hw.x);
      float dd = length(wc - o) - ph * 1.4;
      wv += exp(-max(-dd, 0.0) * 8.0 / p_decay) * step(dd, 0.0) * (1.0 - ph);
    }
    float act = sat(spont + wv) * p_brightness;
    float base = 0.18 + 0.12 * h.y;
    float fade = 1.0 - depth * 0.6 * p_focus;
    vec3 c3 = mix(u_a0 * base, mix(u_a0, u_ink, 0.55) * 1.6, act);
    col += c3 * (soma + den * 0.45) * fade + u_a0 * act * glow2(max(ds, 0.0), 0.25) * 0.25 * fade;
    // nucleus shadow (GCaMP is cytosolic)
    col *= 1.0 - 0.55 * (1.0 - smoothstep(-0.02, 0.03, length(d) - r * 0.45)) * soma;
    cover = max(cover, soma * fade);
  }
  if (p_scan) col *= 0.9 + 0.1 * sin(fc.y * 1.7);
  col = aces(col * 1.2);
  return vec4(col, max(cover, max(col.r, max(col.g, col.b))));
}

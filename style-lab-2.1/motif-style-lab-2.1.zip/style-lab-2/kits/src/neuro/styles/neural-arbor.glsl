// Neural Arbor — dendritic trees grow from somata, action potentials race out along every branch.
vec4 motif(vec2 uv, vec2 fc) {
  vec2 A = M_asp() * 0.5;
  float g = mix(0.3, 1.0, growEnv(0.35)) * p_growth;
  vec3 col = vec3(0.0); float cover = 0.0;
  float px = aa();
  for (int n = 0; n < 6; n++) {
    if (n >= p_neurons) break;
    vec2 hn = h22(vec2(float(n), 3.7));
    vec2 c = p_neurons == 1 ? vec2(0.0) : (hn - 0.5) * A * 1.5;
    c += 0.03 * p_drift * lc(1.0, hn.x);
    vec2 q = uv - c;
    float reach = 0.9 * p_length;
    if (length(q) > reach * 1.25 + 0.05) continue;
    float sr = 0.026 * p_soma;
    float ds = length(q) - sr * (1.0 + 0.1 * lsin(2.0, hn.y) + 0.12 * ln2(q * 30.0, 1.0, 0.3));
    float soma = 1.0 - smoothstep(-px, px, ds);
    col += u_a2 * glow2(max(ds, 0.0), 0.012) * 0.7 * p_glow + mix(u_a2, u_ink, 0.6) * soma * (0.6 + 0.4 * sat(-ds / sr * 3.0));
    cover = max(cover, soma);
    for (int b = 0; b < 9; b++) {
      if (b >= p_branches) break;
      float fb = float(b);
      vec2 hb = h22(vec2(float(n) * 17.0 + fb, 9.1));
      float ang = TAU * (fb + 0.4 * (hb.x - 0.5)) / float(p_branches);
      vec2 pos = c + vec2(cos(ang), sin(ang)) * sr * 0.9;
      float along = 0.0;
      float seg = reach / float(p_segments) * (0.7 + 0.5 * hb.y);
      for (int s = 0; s < 14; s++) {
        if (s >= p_segments) break;
        float fs = float(s) / float(p_segments);
        if (fs > g) break;
        float grow = sat((g - fs) * float(p_segments));
        vec2 hs = h22(vec2(float(n) * 131.0 + fb * 13.0, float(s)));
        ang += (hs.x - 0.5) * 1.6 * p_curl + 0.12 * p_curl * lsin(1.0, hs.y + fs * 0.3);
        float L = seg * (1.0 - fs * 0.45);
        vec2 nxt = pos + vec2(cos(ang), sin(ang)) * L * grow;
        float dseg = sdSeg(uv, pos, nxt);
        float w = mix(0.009, 0.0022, fs) * p_thickness;
        if (dseg < w * 12.0 + 0.02) {
          float t = along + L * sat(dot(uv - pos, nxt - pos) / max(1e-6, dot(nxt - pos, nxt - pos)));
          float sp = pulse(t / reach * 1.3, float(p_spikes), hb.x, 0.035);
          vec2 f = fiber(dseg, w);
          col += mix(u_ink * 0.7, u_a0, 0.35 + 0.65 * fs) * f.x + u_a0 * f.y * 0.12 * p_glow + u_a1 * sp * (f.x * 1.8 + f.y * 0.5) * p_spikeGlow;
          cover = max(cover, f.x);
        }
        // sub-branch (culled by its maximum extent)
        if (hs.y < p_branching && dseg < L * 2.4 + 0.02) {
          float sa = ang + (hs.x < 0.5 ? -1.0 : 1.0) * (0.55 + 0.4 * hs.y);
          vec2 sq = mix(pos, nxt, 0.6); float salong = along + L * 0.6;
          for (int k = 0; k < 5; k++) {
            float fk = float(k) / 5.0;
            float sg = sat((g - fs) * float(p_segments) * 0.8 - fk);
            if (sg <= 0.0) break;
            vec2 hk = h22(vec2(float(n) * 71.0 + fb * 7.0 + float(s), float(k) + 40.0));
            sa += (hk.x - 0.5) * 1.2 * p_curl;
            float SL = L * 0.55 * (1.0 - fk * 0.4);
            vec2 sn = sq + vec2(cos(sa), sin(sa)) * SL * sg;
            float d2 = sdSeg(uv, sq, sn);
            float w2 = w * 0.6 * (1.0 - fk * 0.5);
            if (d2 < w2 * 12.0 + 0.012) {
              vec2 f2 = fiber(d2, w2);
              float sp2 = pulse((salong + SL * fk) / reach * 1.3, float(p_spikes), hb.x, 0.035);
              col += mix(u_ink * 0.5, u_a0, 0.6) * f2.x * 0.8 + u_a0 * f2.y * 0.08 * p_glow + u_a1 * sp2 * f2.x * 1.4 * p_spikeGlow;
              float spn = step(0.7, hk.y) * (1.0 - smoothstep(0.0, px * 1.5, length(uv - sn) - w2 * 1.3));
              col += u_a2 * spn;
              cover = max(cover, max(f2.x, spn));
            }
            salong += SL; sq = sn;
          }
        }
        pos = nxt; along += L;
      }
    }
  }
  col = aces(col);
  return vec4(col, max(cover, max(col.r, max(col.g, col.b))));
}

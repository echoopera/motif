// Action Potential — myelinated axons; the spike leaps node to node (saltatory conduction) as ions flood each node of Ranvier.
vec4 motif(vec2 uv, vec2 fc) {
  vec2 A = M_asp() * 0.5;
  vec3 col = vec3(0.0); float cover = 0.0; float px = aa();
  float n = float(p_axons);
  for (int i = 0; i < 8; i++) {
    if (i >= p_axons) break;
    float fi = float(i); vec2 hi = h22(vec2(fi, 1.3));
    float y0 = n > 1.0 ? mix(-A.y * 0.78, A.y * 0.78, (fi + 0.5) / n) : 0.0;
    float depth = n > 1.0 ? hi.y : 0.0;
    float blur = 1.0 + depth * 5.0 * p_depth;
    float k = 2.0 + 3.0 * hi.x, ph = TAU * hi.y;
    float wav = p_wave * 0.06;
    float fy = y0 + wav * sin(uv.x * k + ph) + wav * 0.5 * ln2(vec2(uv.x * 1.5, fi * 3.0), 1.0, 0.25);
    float slope = wav * k * cos(uv.x * k + ph);
    float d = abs(uv.y - fy) / sqrt(1.0 + slope * slope);
    float sp = p_spacing * 0.2;
    float xs = uv.x + A.x + hi.x * sp;
    float cell = floor(xs / sp), fx = fract(xs / sp);
    float node = abs(fx - 0.5) * sp;
    float gap = 0.01;
    float sheathR = 0.017 * p_sheath * (1.0 - 0.3 * depth);
    float axonR = 0.004;
    float inSheath = smoothstep(gap, gap + 0.012, node);
    float rad = mix(axonR, sheathR, inSheath);
    float edge = px * blur;
    float body = 1.0 - smoothstep(rad - edge, rad + edge, d);
    float nz = sqrt(sat(1.0 - (d / max(rad, 1e-4)) * (d / max(rad, 1e-4))));
    float nodes = ceil(2.0 * A.x / sp) + 2.0;
    float s = fract(float(p_rate) * u_p + hi.x) * nodes;
    float sn = floor(s) + pow(fract(s), 1.0 + 7.0 * p_saltation);
    float act = exp(-pow((cell - sn) * 1.4, 2.0));
    float trail = exp(-max(sn - cell, 0.0) * 1.0) * step(cell, sn + 0.5) * 0.3;
    float lam = 0.5 + 0.5 * sin(nz * 22.0 + fx * 3.0 + fi);
    vec3 sheathCol = u_ink * (0.12 + 0.42 * nz + 0.12 * lam * p_detail) * inSheath;
    vec3 coreCol = mix(u_a0 * 0.4, u_a1 * 1.6, act + trail) * (1.0 - inSheath);
    float fade = 1.0 - depth * 0.6 * p_depth;
    col += (sheathCol + coreCol) * body * fade;
    float rn = length(vec2(node, d)); float ng = gauss1(rn, 0.01 * sqrt(blur)) + 0.2 * glow2(rn, 0.01);
    col += u_a1 * (act + trail) * ng * 2.2 * p_glow * fade;
    col += u_a0 * act * gauss1(rn, 0.035) * 0.2 * p_glow;
    cover = max(cover, body * fade);
    if (p_ions > 0.0 && act > 0.05) {
      for (int j = 0; j < 12; j++) {
        vec2 hj = h22(vec2(fi * 13.0 + float(j), cell));
        if (hj.x > p_ions) continue;
        float life = fract(hj.y * 3.1 + s * 1.7);
        float dir = fract(hj.x * 7.0) < 0.5 ? -1.0 : 1.0;
        vec2 c0 = vec2((cell + 0.5) * sp - A.x - hi.x * sp, fy);
        vec2 pp = c0 + vec2((hj.y - 0.5) * 0.035, dir * (0.06 - 0.055 * life));
        float dd = length(uv - pp) - 0.0022;
        col += mix(u_a2, u_ink, step(0.5, hj.y)) * (1.0 - smoothstep(0.0, px, dd)) * act * sin(PI * life) * 1.6;
      }
    }
  }
  if (p_trace) {
    float yb = -A.y + 0.1;
    float x = (uv.x + A.x) / (2.0 * A.x);
    float ph2 = fract(x - u_p * float(p_rate));
    float v = exp(-pow((ph2 - 0.1) * 30.0, 2.0)) - 0.25 * exp(-pow((ph2 - 0.16) * 14.0, 2.0));
    float yy = yb + v * 0.07;
    float dt = abs(uv.y - yy);
    col += u_a1 * line(dt, 0.0028) + u_a1 * glow2(dt, 0.006) * 0.15;
    col += u_ink * 0.1 * line(abs(uv.y - yb), 0.001);
  }
  col = aces(col * 1.2);
  return vec4(col, max(cover * 0.95, max(col.r, max(col.g, col.b))));
}

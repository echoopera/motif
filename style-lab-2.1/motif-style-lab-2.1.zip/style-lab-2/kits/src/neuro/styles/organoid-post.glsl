// Organoid (pass 2) — upsample with a soft bloom and tone map.
vec4 motif(vec2 uv, vec2 fc) {
  vec2 t = fc / u_res;
  vec4 c = texture(u_buf0, t);
  vec2 px = 1.0 / u_res;
  vec3 bl = vec3(0.0);
  for (int i = 0; i < 8; i++) { float a = float(i) * 0.785398; bl += texture(u_buf0, t + vec2(cos(a), sin(a)) * px * 6.0).rgb; }
  bl /= 8.0;
  vec3 col = c.rgb + max(bl - 0.35, 0.0) * 0.6 * p_innerGlow;
  col = aces(col * 1.2);
  return vec4(col, max(c.a, max(col.r, max(col.g, col.b))));
}

// Synaptic Cleft — vesicles dock and fuse, neurotransmitter diffuses across the cleft and lights the receptors.
vec4 motif(vec2 uv, vec2 fc) {
  vec2 A = M_asp() * 0.5;
  float px = aa();
  vec2 q = uv / p_scale;
  float cw = 0.05 * p_cleft;              // half-width of the cleft
  float curv = p_curvature * 0.35;
  // pre-synaptic bouton: dome above, post-synaptic membrane below
  float preY = cw + curv * q.x * q.x;
  float postY = -cw - curv * 0.6 * q.x * q.x;
  float cyc = float(p_rate);
  float ph = fract(u_p * cyc);            // release cycle
  vec3 col = vec3(0.0); float cover = 0.0;
  // membranes: lipid bilayer (two lines) with texture
  float dPre = uv.y / p_scale - preY, dPost = uv.y / p_scale - postY;
  float bil = 0.006;
  float mPre = line(abs(dPre - bil), 0.0035 / p_scale) + line(abs(dPre - bil * 2.4), 0.0035 / p_scale);
  float mPost = line(abs(dPost + bil), 0.0035 / p_scale) + line(abs(dPost + bil * 2.4), 0.0035 / p_scale);
  float grain = 0.6 + 0.4 * ln2(q * 60.0, 1.0, 0.2);
  // cytoplasm tint
  vec3 preFill = u_a2 * 0.10 * smoothstep(0.0, 0.03, dPre) * (0.6 + 0.4 * grain) + u_a0 * 0.08 * gauss1(dPre, 0.03);
  vec3 postFill = u_a0 * 0.09 * smoothstep(0.0, 0.03, -dPost) * (0.6 + 0.4 * grain) + u_a0 * 0.1 * gauss1(dPost, 0.03);
  col += preFill + postFill + u_ink * 0.55 * (mPre + mPost) * grain;
  cover = max(cover, max(sat(mPre + mPost), 0.35 * (smoothstep(0.0, 0.02, dPre) + smoothstep(0.0, 0.02, -dPost))));
  // receptors on the post membrane
  float rs = 0.028 / p_receptors;
  float rx = q.x / rs; float rcell = floor(rx), rf = fract(rx) - 0.5;
  // activation: sum of transmitter arrival near this receptor
  float arrive = 0.0;
  // vesicles
  for (int i = 0; i < 40; i++) {
    if (i >= p_vesicles) break;
    vec2 h = h22(vec2(float(i), 7.0));
    float vx = (h.x - 0.5) * 1.6 * A.x / p_scale;
    float r = 0.024 * p_vesSize * (0.8 + 0.4 * h.y);
    float docked = step(h.y, 0.55);
    float t = fract(ph + h.y * 0.35);  // vesicle local cycle
    float depth = mix(0.06 + h.y * 0.25, 0.0, docked * smoothstep(0.0, 0.4, t));
    vec2 home = vec2(vx + 0.01 * lsin(2.0, h.x), preY + r + 0.012 + depth);
    home.y = preY + r + 0.004 + depth + 0.2 * h.y * (1.0 - docked);
    home += 0.006 * lc(3.0, h.x) * (1.0 - docked);
    float fuse = docked * smoothstep(0.4, 0.55, t) * (1.0 - smoothstep(0.85, 1.0, t));
    float dv = length(q - home) - r * (1.0 - 0.6 * fuse);
    float ring = line(abs(dv), 0.003 / p_scale) * (1.0 - fuse * 0.7);
    float fill = (1.0 - smoothstep(-px, px, dv)) * (1.0 - fuse);
    col += u_a2 * (ring * 1.4 + fill * 0.45) + u_a2 * glow2(abs(dv), 0.01) * 0.25 * p_glow;
    cover = max(cover, max(ring, fill * 0.8));
    // transmitter cloud released on fusion
    if (docked > 0.5) {
      float rel = smoothstep(0.5, 0.55, t);
      float age = sat((t - 0.5) / 0.45);
      for (int j = 0; j < 14; j++) {
        if (float(j) >= float(p_particles)) break;
        vec2 hj = h22(vec2(float(i) * 31.0 + float(j), 3.0));
        vec2 dir = normalize(vec2(hj.x - 0.5, -0.6 - hj.y));
        float spread = sqrt(age) * (0.03 + 0.09 * p_diffusion * hj.y);
        vec2 pp = vec2(home.x, preY) + dir * spread * (1.0 + 2.0 * p_diffusion) + 0.01 * p_diffusion * lc(1.0, hj.x) * age;
        pp.y = max(pp.y, postY + 0.004);
        float dp = length(q - pp);
        float life = rel * (1.0 - smoothstep(0.8, 1.0, age));
        col += u_a1 * (1.0 - smoothstep(0.003 * p_partSize, 0.003 * p_partSize + px, dp)) * life * 2.0 + u_a1 * glow2(dp, 0.006) * life * 0.35 * p_glow;
        arrive += life * gauss1(pp.x - (rcell + 0.5) * rs, rs * 0.6) * step(pp.y, postY + 0.012);
      }
    }
  }
  // receptor glyphs: little channel proteins that open when transmitter lands
  float open = sat(arrive * 0.8);
  vec2 rp = vec2(rf * rs, q.y - postY + 0.008);
  float rb = sdBox(rp, vec2(rs * 0.18, 0.009));
  float rgap = sdBox(rp, vec2(rs * 0.05 * (0.4 + open), 0.012));
  float rec = (1.0 - smoothstep(0.0, px, max(rb, -rgap))) * step(0.25, h11(rcell + 3.0));
  col += mix(u_ink * 0.4, u_a1 * 2.0, open) * rec + u_a1 * open * glow2(length(rp), 0.015) * 0.5 * p_glow * step(0.25, h11(rcell + 3.0));
  cover = max(cover, rec);
  // post-synaptic potential glow spreading below
  col += u_a0 * 0.25 * p_glow * smoothstep(0.0, -0.3, dPost) * pow(sat(arrive * 0.15), 0.5) * gauss1(dPost, 0.06);
  col = aces(col * 1.15);
  return vec4(col, max(cover, max(col.r, max(col.g, col.b))));
}

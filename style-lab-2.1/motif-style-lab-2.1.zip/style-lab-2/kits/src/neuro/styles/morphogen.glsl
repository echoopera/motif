// Morphogen — Turing patterns: spots, stripes and labyrinths bloom and morph from a band-limited wave field.
vec4 motif(vec2 uv, vec2 fc) {
  vec2 p = uv + p_warp * 0.06 * vec2(lfbm(uv * 2.0, 3, 1.0, 0.3), lfbm(uv * 2.0 + 5.0, 3, 1.0, 0.3));
  float k = 60.0 / p_wavelength;
  float f = 0.0, fx = 0.0, fy = 0.0;
  int N = p_waves;
  for (int i = 0; i < 24; i++) {
    if (i >= N) break;
    float fi = float(i);
    float a = p_hex ? TAU * (fi / 3.0) + (fi >= 3.0 ? h11(fi) * PI : 0.0) : h11(fi) * PI;
    vec2 d = vec2(cos(a), sin(a));
    float ph = h11(fi + 30.0) * TAU + TAU * float(p_drift) * u_p * (h11(fi + 60.0) < 0.5 ? 1.0 : -1.0);
    float s = dot(p, d) * k + ph;
    f += cos(s); fx += -sin(s) * d.x * k; fy += -sin(s) * d.y * k;
  }
  float nrm = 1.0 / sqrt(float(N));
  f *= nrm; fx *= nrm; fy *= nrm;
  // threshold sweeps across the frame (Pearson-map gradient) and breathes over the loop
  float thr = (p_feed - 0.5) * 1.6 + p_sweep * uv.x * 1.2 + 0.35 * p_breathe * lsin(1.0, 0.0);
  float sharp = mix(0.6, 0.04, p_sharp);
  float m = smoothstep(thr - sharp, thr + sharp, f);
  // relief shading from the field gradient
  vec3 N3 = normalize(vec3(-fx, -fy, k * 2.5 / (p_relief + 0.05)) );
  vec3 L = normalize(vec3(-0.5, 0.6, 0.7));
  float dif = sat(dot(N3, L)) * 0.7 + 0.3;
  float spec = pow(sat(dot(reflect(-L, N3), vec3(0.0, 0.0, 1.0))), 30.0) * p_specular * m;
  float hue = fract(f * 0.12 + float(p_cycle) * u_p * 0.0 + uv.y * 0.2);
  vec3 c = mix(u_a0, mix(u_a1, u_a2, sat(uv.y + 0.5)), sat(0.5 + 0.5 * sin(TAU * (hue + u_p * float(p_cycle)))));
  vec3 col = c * m * dif + u_ink * spec;
  col += c * 0.15 * smoothstep(thr - 0.8, thr, f) * (1.0 - m);
  return vec4(col, sat(m + 0.15 * smoothstep(thr - 0.8, thr, f)));
}

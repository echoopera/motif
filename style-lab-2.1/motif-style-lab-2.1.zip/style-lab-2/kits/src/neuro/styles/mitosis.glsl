// Mitosis — a cell condenses its chromosomes, aligns them on the spindle, splits in two, and the camera
// follows one daughter until it becomes the parent again: an infinite, seamless division loop.
const float R0 = 0.26;      // parent radius
const float SZ = 1.35;      // generation zoom
const float DD = 0.26;      // daughter offset after division
float st(float a, float b) { return smoothstep(a, b, u_p); }
// Interphase-style cell interior texture in local coords (unit radius), mirrored by m.
float chromatin(vec2 l, float m) { l.x *= m; return lfbm(l * 3.2 * p_detail + 2.0, 4, 1.0, 0.18); }
vec4 motif(vec2 uv, vec2 fc) {
  float camE = st(0.6, 1.0);
  float zoom = pow(SZ, camE);
  vec2 w = uv / zoom + vec2(DD * camE, 0.0);
  float px = aa() / zoom;
  float rD = R0 / SZ;
  // division geometry
  float sep = st(0.4, 0.72);                       // cell body separation
  float d = DD * sep;
  float rc = mix(R0, rD, sep);
  float k = 0.12 * p_cleave * smoothstep(0.36, 0.46, u_p) * (1.0 - smoothstep(0.55, 0.74, u_p)) + 0.001;
  vec2 c1 = vec2(d, 0.0), c2 = vec2(-d, 0.0);
  // local frame of the nearest body centre: parent at p=0 and daughter A at p=1 share textures,
  // daughter B and the cousin share a mirrored frame (keeps the zoom loop seamless)
  float sB = rc / R0;
  bool nearA = w.x >= 0.0;
  vec2 lb = (w - (nearA ? c1 : c2)) / rc; lb.x *= (nearA || sep < 0.001) ? 1.0 : -1.0;
  float body = smin(length(w - c1) - rc, length(w - c2) - rc, k);
  body += 0.004 * sB * ln2(lb * 5.0, 1.0, 0.3) * p_membrane;
  vec2 cc = vec2(-2.0 * DD * SZ, 0.0);
  vec2 lc_ = (w - cc) / R0; lc_.x = -lc_.x;
  float cous = length(w - cc) - R0 + 0.004 * ln2(lc_ * 5.0, 1.0, 0.3) * p_membrane;
  vec3 col = vec3(0.0); float cover = 0.0;
  bool fl = p_stain != STAIN_PHASE;
  vec3 memC = fl ? u_a0 : u_ink * 0.8;
  vec3 dnaC = fl ? u_a2 : u_ink * 0.9;
  vec3 tubC = fl ? u_a1 : u_ink * 0.5;
  for (int i = 0; i < 2; i++) {
    float sc = i == 0 ? sB : 1.0;
    float sd = (i == 0 ? body : cous) / sc;   // distance in parent-equivalent units
    vec2 l = i == 0 ? lb : lc_;
    float pxl = px / sc;
    float inside = 1.0 - smoothstep(-pxl, pxl, sd);
    float rim = gauss1(sd, 0.004 + 0.004 * p_membrane) + 0.35 * glow2(sd, 0.012) * p_glow;
    float gr = 0.5 + 0.5 * ln2(l * 10.0, 2.0, 0.2);
    col += (fl ? memC * 0.05 : u_ink * 0.08) * inside * (0.6 + 0.4 * gr) * p_cytoplasm + memC * rim * 0.9;
    if (!fl) col += u_ink * 0.25 * gauss1(sd - 0.012, 0.01);
    cover = max(cover, max(inside * 0.85, sat(rim)));
  }
  // nuclei: parent (fades in prometaphase), daughters (reform in telophase), cousin (always)
  float nr = 0.55 * p_nucleus;
  float parentN = 1.0 - st(0.16, 0.3);
  float daughterN = st(0.64, 0.8);
  for (int i = 0; i < 4; i++) {
    vec2 c; float r; float a; float m = 1.0;
    if (i == 0) { c = vec2(0.0); r = R0 * nr; a = parentN; }
    else if (i == 1) { c = c1; r = rD * nr; a = daughterN; }
    else if (i == 2) { c = c2; r = rD * nr; a = daughterN; m = -1.0; }
    else { c = cc; r = R0 * nr; a = 1.0; m = -1.0; }
    if (a <= 0.001) continue;
    vec2 l = (w - c) / r;
    float dn = length(l) - 1.0;
    float inN = 1.0 - smoothstep(-px / r, px / r, dn);
    float ch = chromatin(l, m);
    float dots = pow(sat(ch * 1.6 + 0.5), 3.0);
    col += dnaC * inN * a * (0.25 + 1.1 * dots) + dnaC * gauss1(dn, 0.06) * a * 0.5;
    // nucleolus
    col += mix(dnaC, u_ink, 0.5) * (1.0 - smoothstep(0.18, 0.24, length(l - vec2(0.25 * m, 0.15)))) * a * 0.6;
    cover = max(cover, inN * a);
  }
  // spindle + chromosomes (condense, align, separate, decondense)
  float cond = st(0.1, 0.28) * (1.0 - st(0.66, 0.8));
  float align = st(0.22, 0.36);
  float ana = st(0.4, 0.58);
  float spindle = st(0.18, 0.3) * (1.0 - st(0.6, 0.72));
  vec2 pole1 = vec2(mix(R0 * 0.75, DD + rD * 0.55, sep), 0.0), pole2 = -pole1;
  if (spindle > 0.001) {
    for (int s = 0; s < 2; s++) {
      vec2 pl = s == 0 ? pole1 : pole2;
      float dpole = length(w - pl);
      col += tubC * (gauss1(dpole, 0.012) * 1.2 + glow2(dpole, 0.03) * 0.25 * p_glow) * spindle;
      // astral rays
      float ang = atan(w.y - pl.y, w.x - pl.x);
      float ray = pow(0.5 + 0.5 * cos(ang * float(p_fibres) * 1.5), 30.0) * exp(-dpole * 9.0);
      col += tubC * ray * spindle * 0.5;
    }
  }
  if (cond > 0.001) {
    for (int i = 0; i < 8; i++) {
      if (i >= p_chromosomes) break;
      vec2 h = h22(vec2(float(i), 42.0));
      float fi = float(i) / max(1.0, float(p_chromosomes) - 1.0);
      vec2 scatter = (h - 0.5) * R0 * 0.8;
      vec2 plate = vec2(0.0, (fi - 0.5) * R0 * 1.1);
      vec2 cen = mix(scatter, plate, align);
      float ang = mix(h.x * TAU, PI * 0.5, align) + 0.1 * lsin(3.0, h.y);
      mat2 rm = rot(ang);
      float arm = 0.028 * (0.8 + 0.5 * h.y);
      for (int s = 0; s < 2; s++) {
        float sg = s == 0 ? 1.0 : -1.0;
        vec2 pl = s == 0 ? pole1 : pole2;
        vec2 cs = mix(cen + vec2(sg * 0.006, 0.0), mix(pl * 0.82, pl + (plate - pl) * 0.2 * 0.0, 0.0) + vec2(0.0, plate.y * 0.35), ana);
        // chromatid arms trail back toward the plate during anaphase (V shape)
        vec2 dA = rm * vec2(0.0, arm);
        vec2 tail = vec2(-sg * 0.02 * ana, 0.0);
        float dc = min(sdSeg(w, cs, cs + dA + tail), sdSeg(w, cs, cs - dA + tail));
        float th = 0.0075;
        float chrom = 1.0 - smoothstep(th - px, th + px, dc);
        col += mix(dnaC, u_ink, 0.25) * chrom * cond * 1.4 + dnaC * glow2(dc, 0.01) * cond * 0.2 * p_glow;
        cover = max(cover, chrom * cond);
        // kinetochore fibre from the pole
        if (spindle > 0.01) {
          float df = sdSeg(w, pl, cs);
          col += tubC * line(df, 0.0018) * spindle * 0.55;
        }
      }
    }
  }
  // microscope field of view (hides the generation seam)
  float fov = 1.0 - smoothstep(p_field * 0.62, p_field * 0.95, length(uv));
  col = aces(col * 1.1) * fov;
  return vec4(col, max(cover * fov, max(col.r, max(col.g, col.b))));
}

// Grid Cells — an explorer roams its arena; entorhinal grid cells fire on a hexagonal lattice and spikes pile up where fields are crossed.
float GC_field(vec2 x, float sc, float ori) {
  float k = TAU / (sc * 0.866);
  float s = 0.0;
  for (int i = 0; i < 3; i++) { float a = ori + float(i) * PI / 3.0; s += cos(k * dot(x, vec2(cos(a), sin(a)))); }
  return sat((s + 1.5) / 4.5);
}
float GC_rate(vec2 x) {
  float r = 0.0;
  for (int m = 0; m < 3; m++) {
    if (m >= p_modules) break;
    float sc = p_scale * 0.18 * pow(1.42, float(m));
    float ori = p_orientation * PI / 3.0 + float(m) * 0.17 + 0.05 * p_drift * lsin(1.0, float(m) * 0.3);
    r = max(r, pow(GC_field(x, sc, ori), 1.0 + 6.0 * p_sharp));
  }
  return r;
}
vec2 GC_path(float t) {
  vec2 p = vec2(0.0);
  for (int m = 1; m <= 4; m++) {
    vec2 h = h22(vec2(float(m), 21.0));
    float fm = float(m);
    p += (0.36 / fm) * vec2(cos(TAU * (fm * t + h.x)), sin(TAU * (fm * t * (m == 1 ? 1.0 : 1.0) + h.y)));
  }
  p *= 0.62;
  float l = length(p); float lim = 0.4;
  return l > lim * 0.8 ? p / l * (lim * 0.8 + (lim * 0.2) * tanh((l - lim * 0.8) / (lim * 0.2))) : p;
}
vec4 motif(vec2 uv, vec2 fc) {
  float R = 0.44;
  float arena = p_arena == ARENA_CIRCLE ? length(uv) - R : sdBox(uv, vec2(R));
  float inside = 1.0 - smoothstep(-aa(), aa(), arena);
  float rate = GC_rate(uv);
  vec3 col = (u_bg * 0.4 + mix(u_a2 * 0.35, u_a0 * 1.3, pow(rate, 1.2)) * pow(rate, 1.3) + u_a0 * 0.35 * pow(rate, 6.0)) * p_heat * inside;
  col += u_ink * 0.5 * line(abs(arena), 0.003);
  float cover = inside * p_heat * 0.9;
  // trail + spikes (samples on a fixed lattice of loop time so they stay put as the trail moves)
  float SPL = 360.0;
  float now = u_p * float(p_speed);
  float i0 = floor(now * SPL);
  float trailN = 40.0 + 200.0 * p_trail;
  float dmin = 1e9; float spikes = 0.0;
  vec2 prev = GC_path(now);
  float stp = max(1.0, floor(trailN / 60.0));
  for (int j = 0; j < 60; j++) {
    float idx = i0 - float(j) * stp;
    vec2 pnt = GC_path(idx / SPL);
    float age = float(j) / 60.0;
    vec2 pc = clamp(pnt, vec2(-R), vec2(R));
    dmin = min(dmin, sdSeg(uv, prev, pc) + age * 0.004);
    prev = pc;
  }
  col += u_ink * line(dmin, 0.0025) * 0.55 * inside + u_a2 * glow2(dmin, 0.005) * 0.05;
  // spikes across a long history window
  for (int j = 0; j < 90; j++) {
    float idx = i0 - float(j) * max(1.0, floor(trailN / 20.0));
    vec2 pnt = GC_path(idx / SPL);
    if (length(uv - pnt) > 0.05) continue;
    float r = GC_rate(pnt);
    float im = mod(idx, SPL);
    float hsp = h11(im + 5.0);
    if (hsp > sqrt(r) * p_spikeRate * 0.8) continue;
    vec2 jit = (h22(vec2(im, 3.0)) - 0.5) * 0.012;
    float d = length(uv - pnt - jit);
    float age = float(j) / 90.0;
    spikes += (1.0 - smoothstep(0.005, 0.005 + aa(), d)) * (1.0 - age * 0.6) + glow2(d, 0.008) * 0.3 * (1.0 - age) * p_glow;
  }
  col = mix(col, u_a1 * 1.6, sat(spikes));
  // the animal
  vec2 head = GC_path(now);
  float dh = length(uv - head);
  col += u_ink * (1.0 - smoothstep(0.008, 0.008 + aa(), dh)) + u_a0 * glow2(dh, 0.02) * 0.4 * p_glow;
  cover = max(cover, sat(spikes));
  col = aces(col * 1.1);
  return vec4(col, max(cover, max(max(col.r, col.g), col.b)));
}

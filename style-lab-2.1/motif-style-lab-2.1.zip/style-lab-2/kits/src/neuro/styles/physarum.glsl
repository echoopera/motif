// Physarum — a slime-mould transport network: veins pulse with shuttle streaming as the organism forages.
vec4 motif(vec2 uv, vec2 fc) {
  vec2 p = uv * p_scale * 3.0;
  vec2 wp = p + p_warp * 0.8 * vec2(lfbm(p * 0.5, 3, 1.0, 0.25), lfbm(p * 0.5 + 9.0, 3, 1.0, 0.25));
  // major veins: Voronoi edges on the warped domain
  vec3 v = lvoro(wp, 0.9, float(p_flow), 0.35);
  float edge = v.y - v.x;
  float vw = 0.06 * p_veins;
  float vein = 1.0 - smoothstep(vw * 0.5, vw * 0.5 + 0.03, edge);
  // capillary mesh: ridged noise
  float cap = pow(lridge(wp * 1.7, 4, float(p_flow), 0.3), 3.0);
  cap = smoothstep(0.55 - 0.25 * p_capillary, 0.95, cap) * p_capillary;
  // sparsity mask: the organism covers only part of the plate, fronts advance and retreat
  float cover = smoothstep(-0.2, 0.3, lfbm(p * 0.25 + 3.0, 3, 1.0, 0.35) + 0.6 - p_sparsity);
  // shuttle streaming: peristaltic waves along the network
  float wave = 0.5 + 0.5 * sin(v.x * 12.0 * p_wavelength - TAU * float(p_flow) * u_p * 2.0 + v.z * TAU);
  float thick = vein * (0.55 + 0.45 * wave * p_pulse);
  float tube = max(thick, cap * 0.7) * cover;
  // food sources: bright nodes that the veins converge on
  float food = 0.0;
  for (int i = 0; i < 6; i++) {
    if (i >= p_food) break;
    vec2 h = h22(vec2(float(i), 5.0));
    vec2 c = (h - 0.5) * M_asp() * 0.85;
    float d = length(uv - c);
    food += gauss1(d, 0.02) * (0.8 + 0.2 * lsin(2.0, h.x)) + glow2(d, 0.04) * 0.2;
    tube = max(tube, (1.0 - smoothstep(0.0, 0.15, d)) * vein);
  }
  float core = pow(tube, 1.5);
  vec3 col = mix(u_a2, u_a1, core) * tube * 1.2 + u_ink * pow(core, 4.0) * 0.8 * wave;
  col += u_a1 * glow2(1.0 - tube, 0.3) * 0.08 * p_glow * cover;
  col += u_a0 * food * p_glow;
  col = aces(col);
  return vec4(col, max(tube * 0.9, max(col.r, max(col.g, col.b))));
}

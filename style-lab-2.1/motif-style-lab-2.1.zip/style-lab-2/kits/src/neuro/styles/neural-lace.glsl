// Neural Lace — a holographic brain turns inside a glowing filament mesh; data pulses race across the lace.
float NL_brain(vec3 p) {
  vec3 q = p; q.x = abs(q.x) - 0.12 * p_gap - 0.02;
  float e = length(q / vec3(0.3, 0.3, 0.42)) - 1.0;
  e *= 0.28;
  float folds = sin(p.x * 38.0 + sin(p.z * 21.0)) * sin(p.y * 34.0 + sin(p.x * 17.0)) * sin(p.z * 29.0);
  float d = e + folds * 0.006 * p_folds;
  // flatten the base a little (brainstem side)
  d = smax(d, -p.y - 0.23, 0.05);
  return d;
}
vec4 motif(vec2 uv, vec2 fc) {
  float ang = TAU * u_p * float(p_spin) + 0.6;
  vec3 ro = vec3(sin(ang) * 1.45, 0.25, cos(ang) * 1.45);
  vec3 f = normalize(-ro), r = normalize(cross(vec3(0.0, 1.0, 0.0), f)), u = cross(f, r);
  vec3 rd = normalize(f * 1.7 + uv.x * r + uv.y * u);
  vec3 col = vec3(0.0); float a = 0.0;
  float t = 0.6, hit = 0.0; float glowAcc = 0.0;
  for (int i = 0; i < 70; i++) {
    vec3 p = ro + rd * t;
    float d = NL_brain(p);
    glowAcc += exp(-abs(d) * 60.0) * 0.02;
    if (d < 0.001) { hit = 1.0; break; }
    t += max(d * 0.8, 0.004);
    if (t > 3.0) break;
  }
  if (hit > 0.0) {
    vec3 p = ro + rd * t;
    vec2 e = vec2(0.0015, -0.0015);
    vec3 n = normalize(e.xyy * NL_brain(p + e.xyy) + e.yyx * NL_brain(p + e.yyx) + e.yxy * NL_brain(p + e.yxy) + e.xxx * NL_brain(p + e.xxx));
    float fres = pow(1.0 - sat(dot(n, -rd)), 2.0);
    // lace: triangular grid lines in object space (three families of planes)
    float dens = 18.0 * p_density;
    float l1 = abs(fract(dot(p, vec3(1.0, 0.0, 0.0)) * dens) - 0.5);
    float l2 = abs(fract(dot(p, vec3(0.5, 0.866, 0.0)) * dens) - 0.5);
    float l3 = abs(fract(dot(p, vec3(0.5, -0.433, 0.75)) * dens) - 0.5);
    float lm = min(l1, min(l2, l3));
    float lw = 0.04 * p_width;
    float lace = 1.0 - smoothstep(lw, lw + 0.05, lm);
    // pulses travel radially outward over the lace
    float pr = length(p) * 3.0;
    float pul = 0.0;
    for (int k = 0; k < 4; k++) { if (k >= p_pulses) break; pul += pulse(pr + dot(p, vec3(float(k) - 1.5, 1.0, 0.3)) * 0.5, float(p_pulseSpeed), float(k) * 0.23, 0.05); }
    vec3 holo = u_a0 * (0.15 + 0.85 * fres) * p_opacity;
    col = holo + u_a1 * lace * (0.5 + 1.8 * pul) * (0.35 + 0.65 * fres) + u_ink * lace * pul * 0.8;
    col *= 0.85 + 0.15 * sin(fc.y * 2.2 + u_p * TAU * 0.0) * p_scan;
    a = sat(0.25 * p_opacity + fres * 0.6 + lace * 0.8);
  }
  col += u_a0 * glowAcc * p_glow;
  col = aces(col * 1.2);
  return vec4(col, max(a, max(max(col.r, col.g), col.b)));
}

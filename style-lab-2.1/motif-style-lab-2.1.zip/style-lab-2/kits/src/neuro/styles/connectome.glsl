// Connectome — tractography bundles arc through a rotating brain volume; signal pulses stream along every fibre.
vec4 motif(vec2 uv, vec2 fc) {
  vec3 col = vec3(0.0); float cover = 0.0;
  float rotA = TAU * u_p * float(p_spin) * step(0.5, p_turn) + p_turn * 0.9 * lsin(1.0, 0.0);
  float cy = cos(rotA);
  for (int b = 0; b < 8; b++) {
    if (b >= p_bundles) break;
    float fb = float(b); vec3 h = h33(vec3(fb, 2.0, 5.0));
    // each bundle: family of elliptical arcs (level sets of a scaled radius), centre + tilt
    vec2 c = (h.xy - 0.5) * vec2(0.5, 0.25);
    float tilt = (h.z - 0.5) * 2.2;
    float zc = (h.x - 0.5) * 0.6; // depth of bundle
    vec2 cc = vec2(c.x * cy + zc * sin(rotA), c.y);
    vec2 q = rot(tilt) * (uv - cc);
    float sx = (0.25 + 0.3 * h.y) * mix(1.0, abs(cy) * 0.8 + 0.2, p_turn * 0.8);
    float sy = 0.18 + 0.2 * h.z;
    q += p_warp * 0.05 * vec2(ln2(q * 3.0 + fb, 1.0, 0.3), ln2(q * 3.0 - fb, 1.0, 0.3));
    vec2 e = q / vec2(sx, sy);
    float r = length(e);
    float th = atan(e.y, e.x);
    // arc spans an angular window (a "C" shape)
    float span = mix(0.35, 0.95, p_spread) * PI;
    float thc = th - (h.x - 0.5) * PI;
    thc = mod(thc + PI, TAU) - PI;
    float win = smoothstep(span, span * 0.8, abs(thc));
    float band = smoothstep(0.55, 0.62, r) * (1.0 - smoothstep(1.0, 1.08, r));
    float N = 14.0 * p_density;
    float lr = r * N + 0.3 * sin(th * 3.0 + fb);
    float fid = floor(lr);
    float fl = abs(fract(lr) - 0.5);
    float wpx = aa() * N / max(sx, sy);
    float fibre = 1.0 - smoothstep(0.08 * p_width, 0.08 * p_width + wpx * 1.5, fl);
    float halo = gauss1(fl, 0.25);
    float hf = h11(fid + fb * 50.0);
    // pulses along the fibre (angle coordinate)
    float s = (thc / span) * 0.5 + 0.5;
    float pl = pulse(s * 1.2, float(p_flow), hf, 0.06 * p_pulse + 0.01);
    // direction colour (DTI style): orientation of the fibre tangent
    vec2 tang = normalize(vec2(-e.y * sx, e.x * sy));
    tang = rot(-tilt) * tang;
    vec3 dirCol = p_dirColour ? normalize(abs(vec3(tang.x, tang.y, 0.55 * abs(h.z - 0.5) + 0.2))) : vec3(1.0);
    vec3 base = p_dirColour ? (u_a0 * dirCol.x + u_a1 * dirCol.y + u_a2 * dirCol.z) : mix(u_a0, u_a2, hf);
    float depthF = 1.0 - p_fog * sat(0.5 + (zc * cos(rotA) - c.x * sin(rotA)) * 1.2);
    float m = band * win * depthF;
    col += base * (fibre * (0.35 + 0.65 * hf) + halo * 0.05 * p_glow) * m + mix(base, u_ink, 0.6) * pl * (fibre * 2.2 + halo * 0.35 * p_glow) * m;
    cover = max(cover, fibre * m * 0.8);
  }
  col = aces(col);
  return vec4(col, max(cover, max(col.r, max(col.g, col.b))));
}

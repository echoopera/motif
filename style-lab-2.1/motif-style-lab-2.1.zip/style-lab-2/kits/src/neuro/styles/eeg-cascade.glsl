// EEG Cascade — multichannel traces scroll over a live spectrogram waterfall; spikes and spindles ripple across channels.
float EEG_sig(float x, float ch) {
  // x in loop units (periodic with period 1); sum of band oscillations with integer cycles per loop
  float s = 0.0;
  float d = float(p_speed);
  s += 0.9 * sin(TAU * (x * 3.0 + h11(ch)));                         // delta
  s += 0.6 * sin(TAU * (x * 9.0 + h11(ch + 1.0))) * (0.5 + 0.5 * sin(TAU * (x * 2.0 + ch * 0.1)));  // theta
  s += p_alpha * 1.3 * sin(TAU * (x * 24.0 + h11(ch + 2.0))) * pow(0.5 + 0.5 * sin(TAU * (x + ch * 0.07)), 2.0); // alpha spindles
  s += 0.35 * sin(TAU * (x * 61.0 + h11(ch + 3.0)));                  // beta
  s += p_noise * 0.6 * snoise(vec4(cos(TAU * x) * 9.0, sin(TAU * x) * 9.0, ch * 3.1, 0.0)); // broadband noise
  // spikes: sharp transients at hashed loop positions, propagating across channels
  for (int k = 0; k < 6; k++) {
    if (float(k) >= p_spikes * 6.0) break;
    float at = h11(float(k) + 40.0) + ch * 0.004 * (h11(float(k) + 41.0) - 0.5);
    float dx = fract(x - at + 0.5) - 0.5;
    s += 3.0 * exp(-dx * dx * 60000.0) - 1.2 * exp(-pow(dx - 0.004, 2.0) * 9000.0);
  }
  return s * 0.25;
}
vec4 motif(vec2 uv, vec2 fc) {
  vec2 A = M_asp() * 0.5;
  float x01 = (uv.x + A.x) / (2.0 * A.x);
  float x = x01 * 0.5 + u_p * float(p_speed) ;
  vec3 col = vec3(0.0); float cover = 0.0;
  // spectrogram waterfall: frequency up, time across, periodic in x
  float fy = (uv.y + A.y) / (2.0 * A.y);
  float band = 0.0;
  band += exp(-pow((fy - 0.08) * 14.0, 2.0)) * (0.7 + 0.3 * sin(TAU * (x * 2.0)));
  band += p_alpha * exp(-pow((fy - 0.3) * 18.0, 2.0)) * pow(0.5 + 0.5 * sin(TAU * x), 2.0) * 1.3;
  band += 0.5 * exp(-pow((fy - 0.55) * 8.0, 2.0)) * (0.5 + 0.5 * snoise(vec4(cos(TAU * x) * 3.0, sin(TAU * x) * 3.0, fy * 6.0, 1.0)));
  band += 0.25 * (0.5 + 0.5 * snoise(vec4(cos(TAU * x) * 12.0, sin(TAU * x) * 12.0, fy * 30.0, 2.0)));
  band = pow(sat(band * p_contrast * 0.8), 1.4);
  col += ramp(0.1 + band * 0.9) * p_spectro;
  // grid
  if (p_grid) {
    float gx = abs(fract(x01 * 16.0) - 0.5) * 2.0 * A.x / 16.0, gy = abs(fract(fy * 10.0) - 0.5) * 2.0 * A.y / 10.0;
    col += u_ink * 0.06 * (line(gx, 0.001) + line(gy, 0.001));
  }
  // traces
  int C = p_channels;
  float lane = 2.0 * A.y * 0.9 / float(C);
  float y0 = A.y * 0.9;
  float ci = floor((y0 - uv.y) / lane);
  for (int k = -1; k <= 1; k++) {
    float ch = ci + float(k);
    if (ch < 0.0 || ch >= float(C)) continue;
    float yc = y0 - (ch + 0.5) * lane;
    float amp = lane * 0.9 * p_amplitude;
    float v = EEG_sig(x, ch) * amp;
    float dx = 1.0 / (u_res.x) * 0.5;
    float v2 = EEG_sig(x + dx, ch) * amp;
    float slope = (v2 - v) / (dx * 2.0 * A.x / 0.5);
    float d = abs(uv.y - (yc + v)) / sqrt(1.0 + slope * slope);
    vec3 tc = mix(u_a0, u_a1, h11(ch + 9.0) * 0.6);
    col += tc * line(d, 0.0022 * p_lineWidth) * 1.4 + tc * glow2(d, 0.004 * p_lineWidth) * 0.12 * p_glow;
    cover = max(cover, line(d, 0.0022 * p_lineWidth));
    col += u_ink * 0.05 * line(abs(uv.y - yc), 0.0008);
  }
  // playhead
  float ph = abs(x01 - 0.82) * 2.0 * A.x;
  col += u_a2 * line(ph, 0.002) * 0.8;
  col = aces(col * 1.1);
  return vec4(col, max(cover, max(max(col.r, col.g), col.b)));
}

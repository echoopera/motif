// Chromatin — the double helix turns, unzips at a replication fork and zips back; nucleosome beads drift behind.
vec4 motif(vec2 uv, vec2 fc) {
  vec2 A = M_asp() * 0.5;
  vec2 q = rot(p_tilt * 0.6) * uv / p_scale;
  vec3 col = vec3(0.0); float cover = 0.0; float px = aa() / p_scale;
  // background nucleosomes: soft beads with wrapped DNA
  for (int i = 0; i < 10; i++) {
    if (float(i) >= p_beads * 10.0) break;
    vec3 h = h33(vec3(float(i), 4.0, 8.0));
    vec2 c = (h.xy - 0.5) * A * 2.2 / p_scale + 0.04 * lc(1.0, h.z);
    float r = 0.05 + 0.03 * h.z;
    float d = length(q - c) - r;
    float blur = 0.02 + 0.03 * p_fog;
    float bead = 1.0 - smoothstep(-blur, blur, d);
    float wrap = line(abs(fract((dot(q - c, vec2(0.8, 0.6)) / r) * 1.7 + u_p * 0.0) - 0.5) * r, 0.01) * bead;
    col += (u_a2 * 0.18 * bead + u_a2 * 0.12 * wrap) * (1.0 - 0.6 * p_fog);
  }
  float R = 0.07;
  float turns = 10.0 * p_turns;
  float th0 = TAU * float(p_twist) * u_p;
  // fork position sweeps along the helix and back
  float fork = mix(-A.x / p_scale - 0.2, A.x / p_scale * 0.6, p_unzip * (0.5 - 0.5 * cos(TAU * u_p)));
  float x = q.x;
  float th = x * turns + th0;
  float open = max(fork - x, 0.0);
  float sep = open * 0.55;
  float yA = R * sin(th) + sep, zA = cos(th);
  float yB = R * sin(th + PI * 0.75) - sep, zB = cos(th + PI * 0.75);
  float bw = 0.009 * p_width;
  // base pairs (rungs) on a fixed lattice along x
  float bp = 0.028 / p_basePairs;
  float xi = floor(x / bp + 0.5);
  float xr = xi * bp;
  float thr = xr * turns + th0;
  float oR = max(fork - xr, 0.0);
  float ya = R * sin(thr) + oR * 0.55, yb = R * sin(thr + PI * 0.75) - oR * 0.55;
  float zr = (cos(thr) + cos(thr + PI * 0.75)) * 0.5;
  float dx = abs(x - xr);
  float ymin = min(ya, yb), ymax = max(ya, yb);
  float inRung = step(ymin, q.y) * step(q.y, ymax);
  float zipped = 1.0 - smoothstep(0.0, 0.03, oR);
  float stubLen = mix(ymax - ymin, 0.03, 1.0 - zipped);
  float fromA = abs(q.y - ya), fromB = abs(q.y - yb);
  float rungMask = zipped > 0.5 ? inRung : max(step(fromA, stubLen) * step(0.0, (q.y - ya) * sign(yb - ya)), step(fromB, stubLen) * step(0.0, (q.y - yb) * sign(ya - yb)));
  float rung = (1.0 - smoothstep(0.0025, 0.0025 + px, dx)) * rungMask;
  float base = floor(h11(xi + 13.0) * 4.0);
  float half_ = step(abs(q.y - ya), abs(q.y - yb));
  vec3 bcol = p_rungMode == RUNG_MODE_BASES ? accent(base + half_ * 2.0) : mix(u_a0, u_a1, half_);
  if (base > 2.5) bcol = mix(bcol, u_ink, 0.5);
  float depthR = 0.45 + 0.55 * sat(zr * 0.5 + 0.5);
  // strands: draw back strand first, then front
  float dA = abs(q.y - yA), dB = abs(q.y - yB);
  float sA = 1.0 - smoothstep(bw - px, bw + px, dA);
  float sB = 1.0 - smoothstep(bw - px, bw + px, dB);
  vec3 cA = u_ink * (0.35 + 0.65 * sat(zA * 0.5 + 0.5)) + u_a0 * glow2(dA, bw * 2.0) * 0.25 * p_glow;
  vec3 cB = u_ink * (0.35 + 0.65 * sat(zB * 0.5 + 0.5)) + u_a1 * glow2(dB, bw * 2.0) * 0.25 * p_glow;
  vec4 layerR = vec4(bcol * depthR, 1.0) * rung;
  vec4 layerA = vec4(cA, 1.0) * sA, layerB = vec4(cB, 1.0) * sB;
  vec4 back = zA < zB ? layerA : layerB, front = zA < zB ? layerB : layerA;
  vec4 acc = vec4(col, 0.0);
  acc = over(layerR, acc);
  acc = over(zA < 0.0 && zB < 0.0 ? back : back, acc);
  acc = over(front, acc);
  // polymerase glow at the fork
  float df = length(vec2(q.x - fork, q.y));
  acc.rgb += u_a2 * glow2(df, 0.03) * 0.6 * p_glow * p_unzip;
  vec3 outc = aces(acc.rgb * 1.1);
  return vec4(outc, max(acc.a, max(max(outc.r, outc.g), outc.b)));
}

// Protein Fold — a random coil collapses into helices and sheets, holds its fold, then melts back to chaos.
vec3 foldedPos(int i, int N) {
  // helix bundle / sheet: segments of ~11 residues laid antiparallel around a ring
  int K = max(2, N / 11);
  float segLen = float(N) / float(K);
  float fs = float(i) / segLen;
  int s = int(floor(fs)); float j = fract(fs);
  float dir = (s % 2 == 0) ? 1.0 : -1.0;
  float a0 = TAU * float(s) / float(K);
  vec3 axis = vec3(cos(a0), 0.0, sin(a0)) * 0.11 * sqrt(float(K) / 4.0);
  float y = (j - 0.5) * 0.36 * dir;
  bool helix = h11(float(s) + 17.0) < p_helix;
  vec3 pos = axis + vec3(0.0, y, 0.0);
  if (helix) { float a = float(i) * 1.0; pos += vec3(cos(a), 0.0, sin(a)) * 0.05; pos.y *= 0.8; }
  else { vec3 side = normalize(vec3(-axis.z, 0.0, axis.x) + 1e-4); pos += side * (i % 2 == 0 ? 0.018 : -0.018); }
  return pos;
}
vec4 motif(vec2 uv, vec2 fc) {
  int N = p_residues;
  float fold = smoothstep(0.08, 0.4, u_p) * (1.0 - smoothstep(0.4 + 0.5 * p_hold, 0.95, u_p));
  float ang = TAU * u_p * float(p_spin);
  mat2 R = rot(ang);
  float persp = p_perspective;
  // pass 1: random-walk centroid
  vec3 w = vec3(0.0), cen = vec3(0.0);
  for (int i = 0; i < 72; i++) {
    if (i >= N) break;
    vec3 h = h33(vec3(float(i), 5.0, 2.0)) - 0.5;
    w += normalize(h + 1e-3) * 0.045;
    cen += w;
  }
  cen /= float(N);
  vec3 prev = vec3(0.0); vec2 prevS = vec2(0.0); float prevZ = 0.0;
  float bestZ = -1e9; vec3 bestC = vec3(0.0); float bestShade = 0.0; float hit = 0.0; float glowAcc = 0.0;
  w = vec3(0.0);
  for (int i = 0; i < 72; i++) {
    if (i >= N) break;
    vec3 h = h33(vec3(float(i), 5.0, 2.0)) - 0.5;
    w += normalize(h + 1e-3) * 0.045;
    vec3 coil = (w - cen) * 1.4 * p_coil + 0.02 * vec3(lc(2.0, h.x), ln2(vec2(float(i), 1.0), 1.0, 0.3));
    vec3 pos = mix(coil, foldedPos(i, N), fold);
    pos.xz = R * pos.xz;
    float sc = 1.0 / (1.0 + pos.z * persp * -1.2);
    vec2 S = pos.xy * sc * 1.9;
    float Z = pos.z;
    if (i > 0) {
      vec2 pa = uv - prevS, ba = S - prevS;
      float t = sat(dot(pa, ba) / max(dot(ba, ba), 1e-8));
      float d = length(pa - ba * t);
      float z = mix(prevZ, Z, t);
      float r = 0.022 * p_radius * mix(1.0, sc, 0.5);
      if (d < r) {
        float nz = sqrt(1.0 - (d / r) * (d / r));
        float zz = z + nz * r;
        if (zz > bestZ) {
          bestZ = zz; hit = 1.0;
          float fi = (float(i) - 1.0 + t) / float(N);
          int seg = int(floor((float(i) + t) / (float(N) / float(max(2, N / 11)))));
          bool hel = h11(float(seg) + 17.0) < p_helix;
          vec3 c = p_colour == COLOUR_INDEX ? mix(mix(u_a0, u_a1, sat(fi * 2.0)), u_a2, sat(fi * 2.0 - 1.0))
                 : p_colour == COLOUR_STRUCTURE ? (fold > 0.5 ? (hel ? u_a0 : u_a1) : mix(u_ink * 0.6, hel ? u_a0 : u_a1, fold * 2.0))
                 : (h11(float(i) + 3.0) < 0.45 ? u_a2 : u_ink * 0.75);
          bestC = c; bestShade = nz;
        }
      }
      glowAcc += glow2(d, 0.02) * 0.02;
    }
    prevS = S; prevZ = Z;
  }
  vec3 col = vec3(0.0); float a = 0.0;
  if (hit > 0.0) {
    float depthShade = mix(1.0, 0.55 + 0.45 * sat(bestZ * 3.0 + 0.5), p_depthShade);
    float rim = smoothstep(0.35, 0.0, bestShade) * p_outline;
    col = bestC * (0.25 + 0.75 * bestShade) * depthShade + u_ink * pow(bestShade, 18.0) * 0.6;
    col = mix(col, u_bg * 0.3, rim);
    a = 1.0;
  }
  col += mix(u_a0, u_a1, 0.5) * glowAcc * p_glow * (1.0 - a);
  col = aces(col * 1.1);
  return vec4(col, max(a, max(col.r, max(col.g, col.b))));
}

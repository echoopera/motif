// Epithelium — living tissue: domed cells jostle and breathe, nuclei drift, a calcium wave rolls through.
vec4 motif(vec2 uv, vec2 fc) {
  float sc = 9.0 / p_cellSize;
  vec2 p = uv * sc;
  p += p_texture * 0.25 * vec2(ln2(uv * 3.0, 1.0, 0.3), ln2(uv * 3.0 + 4.0, 1.0, 0.3));
  vec2 n = floor(p), f = fract(p);
  float d1 = 9.0, d2 = 9.0; vec2 site = vec2(0.0); float id = 0.0; vec2 cellN = vec2(0.0);
  for (int j = -1; j <= 1; j++) for (int i = -1; i <= 1; i++) {
    vec2 g = vec2(float(i), float(j)); vec2 h = h22(n + g);
    vec2 o = 0.5 + p_jitter * (h - 0.5) + 0.12 * p_motion * lc(float(p_speed), h.x);
    vec2 r = g + o - f;
    // breathing: each cell's weight oscillates (power-diagram style)
    float wgt = 0.08 * p_breathe * lsin(float(p_speed), h.y);
    float d = length(r) - wgt;
    if (d < d1) { d2 = d1; d1 = d; site = r; id = h.x; cellN = n + g; } else if (d < d2) d2 = d;
  }
  float edge = d2 - d1;
  float mw = 0.06 * p_membrane;
  float memb = 1.0 - smoothstep(mw, mw + 0.05, edge);
  float dome = sat(edge * 2.2);
  // nucleus: ellipse near the site, slowly rotating
  vec2 nq = rot(TAU * (id + 0.15 * lsin(1.0, id))) * site;
  float nuc = length(nq / vec2(1.0, 0.7)) - 0.22 * p_nucleus;
  float nucIn = 1.0 - smoothstep(-0.02, 0.02, nuc);
  // calcium wave: rolls across the tissue by cell centroid, k times per loop
  vec2 cw = (cellN + 0.5) / sc;
  float wave = pulse(dot(cw, normalize(vec2(1.0, 0.35))) * 0.6 + 0.5, float(p_waveSpeed), 0.0, 0.08 * p_waveWidth + 0.02);
  float lit = wave * (0.6 + 0.4 * id);
  vec3 col; float a;
  if (p_stain == STAIN_HE) {
    // H&E histology: pink cytoplasm, purple nuclei, pale membranes
    vec3 cyto = mix(u_a2, u_ink, 0.1) * (0.7 + 0.3 * dome);
    col = mix(cyto, u_a1 * 0.9, nucIn) * (0.85 + 0.15 * ln2(p * 3.0, 1.0, 0.2));
    col = mix(col, u_a0, memb * 0.6);
    col = mix(col, u_a0 * 1.3, lit * 0.35);
    a = 1.0;
  } else if (p_stain == STAIN_PHASE) {
    float g = 0.35 + 0.35 * dome - 0.3 * memb + 0.5 * gauss1(edge - mw - 0.04, 0.03) - 0.25 * nucIn;
    col = u_ink * g + u_a0 * lit * 0.3;
    a = 1.0;
  } else {
    // fluorescence: membrane marker, nuclear stain, calcium indicator
    col = u_a0 * memb * 1.2 + u_a0 * 0.08 * dome + u_a2 * nucIn * (0.6 + 0.4 * ln2(nq * 8.0, 1.0, 0.2)) + u_a1 * lit * dome * 1.3;
    col += u_a1 * lit * memb * 0.6;
    col = aces(col);
    a = max(max(col.r, col.g), col.b);
  }
  return vec4(col * (p_stain == STAIN_FLUOR ? 1.0 : 1.0), a);
}

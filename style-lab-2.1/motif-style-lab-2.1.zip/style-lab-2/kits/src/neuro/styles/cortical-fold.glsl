// Cortical Fold — gyri and sulci wrap a turning hemisphere while waves of activity sweep the surface.
// Gyri as a labyrinth: band-limited random plane waves (same wavelength), thresholded near zero.
float foldH(vec3 P) {
  P += p_warp * 0.12 * vec3(ln3(P * 2.0, float(p_flow), 0.2), ln3(P * 2.0 + 5.0, float(p_flow), 0.2), 0.0);
  float k = 52.0 * p_folds, f = 0.0;
  for (int i = 0; i < 14; i++) {
    vec3 h = h33(vec3(float(i), 2.0, 9.0));
    float z = h.x * 2.0 - 1.0, a = h.y * TAU; vec3 d = vec3(sqrt(1.0 - z * z) * vec2(cos(a), sin(a)), z);
    f += cos(k * dot(P, d) + h.z * TAU + TAU * u_p * float(p_flow) * (h.z < 0.5 ? 1.0 : -1.0));
  }
  f /= sqrt(14.0);
  return smoothstep(-0.55, 0.55, f);
}
vec4 motif(vec2 uv, vec2 fc) {
  float R = 0.42;
  vec2 q = uv;
  float r2 = dot(q, q) / (R * R);
  float globe = p_globe;
  float inside = 1.0 - smoothstep(1.0 - aa() * 3.0 / R, 1.0, r2) ;
  float z = sqrt(max(0.0, 1.0 - r2));
  // sphere mapping (blend with flat plane)
  float spin = TAU * u_p * float(p_spin);
  vec3 n0 = vec3(q / R, z);
  n0.xz = rot(spin) * n0.xz;
  vec3 P = mix(vec3(uv * 2.2, 0.0), n0, globe);
  vec2 tuv = P.xy * 4.0;
  float e = 0.0025;
  float h = foldH(P), hx = foldH(P + vec3(e, 0.0, 0.0)), hy = foldH(P + vec3(0.0, e, 0.0));
  vec3 bump = normalize(vec3(-(hx - h) / e * 0.02, -(hy - h) / e * 0.02, 1.0 / (p_depth + 0.05)));
  vec3 N = normalize(mix(vec3(0.0, 0.0, 1.0), vec3(q / R, z), globe * inside));
  // perturb the base normal by the bump
  vec3 T = normalize(cross(vec3(0.0, 1.0, 0.0), N) + 1e-4), B = cross(N, T);
  vec3 Np = normalize(T * bump.x + B * bump.y + N * bump.z);
  vec3 L = normalize(vec3(cos(p_light * TAU), sin(p_light * TAU), 0.9));
  float dif = sat(dot(Np, L));
  float spec = pow(sat(dot(reflect(-L, Np), vec3(0.0, 0.0, 1.0))), 24.0) * p_specular;
  float ao = mix(0.35, 1.0, h);
  // activity: travelling bands across the cortex
  float act = 0.0;
  for (int i = 0; i < 3; i++) {
    vec2 hh = h22(vec2(float(i), 11.0));
    vec2 dir = normalize(hh - 0.5);
    float s = dot(tuv, dir) * 0.35 - float(p_waves) * u_p - hh.x;
    act += pow(0.5 + 0.5 * sin(TAU * s), 12.0);
  }
  act *= p_activity * h;
  vec3 tissue = mix(u_a2 * 0.35, mix(u_ink, u_a2, 0.35), h);
  vec3 col = tissue * (0.15 + 0.85 * dif) * ao + u_ink * spec + u_a0 * act * 1.4;
  float rim = pow(1.0 - z, 3.0) * globe;
  col += u_a1 * rim * p_rim * 1.5;
  float a = mix(1.0, inside, globe);
  col = aces(col * 1.1);
  return vec4(col * a, a);
}

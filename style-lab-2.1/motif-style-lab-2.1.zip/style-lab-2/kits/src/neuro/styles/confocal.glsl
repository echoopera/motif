// Confocal — a z-stack sweeps through cultured neurons: three fluorescence channels drift in and out of focus.
vec3 CF_channels(vec2 p, float zf) {
  // green: neurites and somata (ridged 3D noise sliced at the focal plane)
  float r1 = 1.0 - abs(snoise(vec3(p * 3.0 * p_neurites, zf * 1.2) + vec3(M_seedOff(), 0.0)));
  float r2 = 1.0 - abs(snoise(vec3(p * 6.5 * p_neurites, zf * 2.0 + 3.0) + vec3(M_seedOff(), 0.0)));
  float neur = pow(r1, 18.0) + 0.5 * pow(r2, 22.0);
  float somaF = 0.0, nucF = 0.0, punc = 0.0;
  vec2 g = p * 2.2 * p_density;
  vec2 n = floor(g);
  for (int j = -1; j <= 1; j++) for (int i = -1; i <= 1; i++) {
    vec2 c = n + vec2(float(i), float(j)); vec3 h = h33(vec3(c, 1.0));
    vec2 s = c + 0.2 + 0.6 * h.xy;
    float zc = (h.z - 0.5) * 2.0;
    float foc = exp(-pow((zf - zc) * 1.6, 2.0));
    float d = length((g - s) * vec2(1.0, 1.2));
    somaF += exp(-d * d * 40.0) * foc * 1.4;
    nucF += exp(-pow(d * 9.0, 4.0)) * foc;
  }
  vec2 pg = p * 26.0 * p_puncta;
  vec2 pn = floor(pg);
  vec3 hp = h33(vec3(pn, 7.0));
  if (hp.z < 0.35) {
    float zc = (hp.x - 0.5) * 2.0;
    float d = length(pg - pn - 0.5 - (hp.xy - 0.5) * 0.6);
    punc = exp(-d * d * 16.0) * exp(-pow((zf - zc) * 2.5, 2.0)) * (0.5 + neur * 2.0);
  }
  return vec3(neur * 0.9 + somaF, punc * 1.8, nucF * 0.9);
}
vec4 motif(vec2 uv, vec2 fc) {
  vec2 A = M_asp() * 0.5;
  float zf = p_sweep * 1.3 * sin(TAU * u_p * float(p_sweepSpeed));
  vec2 p = uv;
  bool quad = p_view == VIEW_QUAD;
  int panel = 3;
  if (quad) {
    vec2 s = step(vec2(0.0), uv);
    panel = int(s.x + 2.0 * (1.0 - s.y));
    p = (uv - (s - 0.5) * A) * 2.0;
  }
  vec3 ch = CF_channels(p, zf) * p_gain;
  // detector noise (static pattern + slow shot noise, flash-safe)
  float nz = (h21(floor(fc * 0.5) + tslot(24.0)) - 0.5) * 0.12 * p_noise;
  ch = max(ch + nz, 0.0);
  vec3 m = vec3(p_green ? ch.x : 0.0, p_magenta ? ch.y : 0.0, p_blue ? ch.z : 0.0);
  if (quad && panel < 3) m = panel == 0 ? vec3(m.x, 0.0, 0.0) : panel == 1 ? vec3(0.0, m.y, 0.0) : vec3(0.0, 0.0, m.z);
  vec3 col = u_a0 * m.x + u_a1 * m.y + u_a2 * m.z;
  if (quad) { vec2 gl = abs(uv); col += u_ink * 0.3 * (line(gl.x, 0.002) + line(gl.y, 0.002)); }
  // scale bar
  vec2 sb = uv - vec2(A.x - 0.16, -A.y + 0.05);
  col += u_ink * 0.8 * (1.0 - smoothstep(0.0, aa(), sdBox(sb, vec2(0.08, 0.004))));
  col = aces(col * 1.2);
  return vec4(col, max(max(col.r, col.g), col.b));
}

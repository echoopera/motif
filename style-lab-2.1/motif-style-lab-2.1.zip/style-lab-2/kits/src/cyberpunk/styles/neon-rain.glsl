// Neon Rain — a night street under heavy rain: invented neon signage bleeds into puddles as streaks sheet down.
vec3 NR_signs(vec2 uv) {
  vec2 A = M_asp() * 0.5;
  vec3 col = vec3(0.0);
  for (int i = 0; i < 9; i++) {
    if (i >= p_signs) break;
    vec3 h = h33(vec3(float(i), 2.0, 5.0));
    vec2 c = vec2((h.x - 0.5) * A.x * 1.8, 0.05 + h.y * A.y * 0.8);
    bool vert = h.z < 0.4;
    vec2 sz = vert ? vec2(0.035, 0.11 + 0.1 * h.x) : vec2(0.09 + 0.08 * h.y, 0.035);
    vec2 q = uv - c;
    float d = sdBox(q, sz);
    // glyph blocks inside the sign
    vec2 gc = (q + sz) / (2.0 * sz);
    float n = vert ? 3.0 : 4.0;
    vec2 cell = vert ? vec2(gc.x, gc.y * n) : vec2(gc.x * n, gc.y);
    float gl = CP_glyph(vec2(fract(cell.x), fract(cell.y)) * vec2(1.2, 1.2) - 0.1, floor(vert ? cell.y : cell.x) + h.x * 50.0);
    // flicker (limited)
    float fl = 1.0 - 0.8 * step(0.93 - 0.15 * p_flicker, h11(tslot(24.0) + float(i) * 3.3)) * p_flicker;
    vec3 c3 = accent(floor(h.z * 3.0 + float(i)));
    float tube = 1.0 - smoothstep(0.0, 0.0035, abs(d) - 0.002);
    col += c3 * (tube * 1.6 + gl * step(d, 0.0) * 1.1 + exp(-max(d, 0.0) * 22.0) * 0.35 * p_glow) * fl;
  }
  return col;
}
vec4 motif(vec2 uv, vec2 fc) {
  vec2 A = M_asp() * 0.5;
  float horizon = -0.08;
  vec3 col = vec3(0.0);
  // sky / buildings silhouette
  float sky = smoothstep(horizon, A.y, uv.y);
  col += mix(u_a1 * 0.12, u_bg, sky) * 0.8;
  float bx = floor(uv.x * 9.0);
  float bh = horizon + 0.15 + 0.35 * h11(bx + 3.0);
  float bld = step(uv.y, bh) * step(horizon, uv.y);
  vec2 wq = vec2(uv.x * 60.0, uv.y * 45.0);
  float win = step(0.82, h21(floor(wq))) * step(0.2, fract(wq.x)) * step(0.3, fract(wq.y));
  col = mix(col, u_bg * 0.6 + accent(bx) * 0.25 * win, bld);
  if (uv.y > horizon) col += NR_signs(uv);
  else {
    // wet street: reflect the signs with ripple distortion and streaky blur
    float dpt = horizon - uv.y;
    vec2 ruv = vec2(uv.x, 2.0 * horizon - uv.y);
    // ripples from drops (loop-periodic)
    vec2 rg = uv * vec2(9.0, 22.0) * p_puddles;
    vec2 rn = floor(rg); vec3 rh = h33(vec3(rn, 4.0));
    float rt = fract(u_p * float(p_speed) * 3.0 + rh.x);
    float rr = length((rg - rn - 0.5 - (rh.xy - 0.5) * 0.4) * vec2(1.0, 2.2)) - rt * 0.5;
    float ring = exp(-rr * rr * 300.0) * (1.0 - rt);
    ruv.x += ring * 0.01 + 0.004 * ln2(uv * vec2(8.0, 40.0), float(p_speed), 0.3) * p_puddles;
    vec3 refl = NR_signs(ruv + vec2(0.0, dpt * 0.3 * ln2(vec2(uv.x * 40.0, 0.0), 1.0, 0.2))) * 0.55 * p_reflection;
    col = u_bg * 0.4 + refl * (0.6 + 0.4 * exp(-dpt * 3.0)) + u_ink * ring * 0.25;
  }
  // rain streaks: several depth layers, falling an integer number of tiles per loop
  for (int l = 0; l < 3; l++) {
    float fl = float(l);
    float cols = 60.0 + fl * 50.0;
    vec2 rq = vec2(uv.x + uv.y * 0.12 * p_wind, uv.y);
    float cx = floor(rq.x * cols);
    vec2 hh = h22(vec2(cx, fl + 7.0));
    if (hh.x > p_density) continue;
    float len = 0.05 + 0.08 * hh.y;
    float y = fract((rq.y + A.y) / (2.0 * A.y) + u_p * float(p_speed) * (2.0 + fl) + hh.y);
    float dx = abs(fract(rq.x * cols) - 0.5) / cols;
    float s = smoothstep(0.0, len, y) * (1.0 - step(len * 1.2, y));
    float streak = (1.0 - smoothstep(0.0, 0.0012 + fl * 0.0005, dx)) * pow(sat(y / len), 2.0) * step(y, len);
    col += mix(u_ink, u_a1, 0.3) * streak * (0.5 - fl * 0.1) * 1.6;
  }
  // fog
  col += u_a1 * 0.06 * p_fog * exp(-abs(uv.y - horizon) * 6.0);
  col = aces(col * 1.2);
  return vec4(col, 1.0);
}

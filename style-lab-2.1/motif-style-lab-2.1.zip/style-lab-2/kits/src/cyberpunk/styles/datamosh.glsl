// Datamosh (pass 2) — P-frame bleed: macroblocks drag stale pixels along their motion vectors, chroma smears, keyframes snap.
vec4 motif(vec2 uv, vec2 fc) {
  float bs = 8.0 + 24.0 * p_blockSize;
  vec2 blk = floor(fc / bs);
  // time slots between "keyframes"
  float slots = 6.0 * p_rate + 1.0;
  float sl = tslot(slots), sf = tfrac(slots);
  // motion vectors: coherent per region, accumulate within the slot (the bleed)
  vec2 mv = vec2(ln2(blk * 0.12 + sl * 3.7, 1.0, 0.2), ln2(blk * 0.12 - sl * 5.1, 1.0, 0.2));
  float moshing = step(0.35, h11(sl * 1.3)) * p_intensity;
  float grow = pow(sf, 0.7) * moshing;
  vec2 off = mv * bs * 6.0 * grow;
  // some blocks freeze (sample the "previous keyframe" position instead)
  float freeze = step(1.0 - 0.6 * p_freeze * p_intensity, h21(blk + sl));
  vec2 sfc = fc - off * (1.0 - freeze);
  // smear: sample along the motion vector (limited taps)
  vec3 c = vec3(0.0); float wsum = 0.0;
  for (int i = 0; i < 6; i++) { float t = float(i) / 5.0; float w = 1.0 - t * 0.7; c += texture(u_buf0, (sfc - mv * bs * 3.0 * p_smear * t * grow) / u_res).rgb * w; wsum += w; }
  c /= wsum;
  // chroma bleed (shift colour channels within the block)
  vec2 cs = mv * bs * 0.8 * grow * p_chroma;
  c.r = mix(c.r, texture(u_buf0, (sfc + cs) / u_res).r, 0.7);
  c.b = mix(c.b, texture(u_buf0, (sfc - cs) / u_res).b, 0.7);
  // macroblock quantisation artefacts: flatten some blocks to their mean
  if (h21(blk * 1.7 + sl) < 0.3 * p_quantise * p_intensity * moshing) c = texture(u_buf0, ((blk + 0.5) * bs) / u_res).rgb;
  // block edges faintly visible while moshing
  vec2 bf = fract(fc / bs);
  c *= 1.0 - 0.15 * grow * (step(bf.x, 1.0 / bs) + step(bf.y, 1.0 / bs));
  vec3 col = aces(c * 1.1);
  return vec4(col, 1.0);
}

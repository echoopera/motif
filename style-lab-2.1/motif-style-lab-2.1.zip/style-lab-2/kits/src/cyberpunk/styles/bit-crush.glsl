// Bit Crush (pass 2) — the image collapses in bit depth: ordered dither, palette snapping and pixel blocks breathe with the loop.
vec4 motif(vec2 uv, vec2 fc) {
  vec2 A = M_asp() * 0.5;
  // crush level breathes over the loop, bands can crush independently
  float band = floor(fc.y / (u_res.y / float(p_bands)));
  float lvl = sat(p_crush + 0.35 * p_breathe * lsin(1.0, band * 0.13));
  float px = floor(1.0 + lvl * 14.0 * p_pixelate);
  vec2 cell = floor(fc / px) * px + px * 0.5;
  vec3 c = texture(u_buf0, cell / u_res).rgb;
  float bits = mix(6.0, 1.0, lvl);
  float levels = pow(2.0, floor(bits));
  float th = CP_bayer(floor(fc / px)) - 0.5;
  vec3 q = floor(c * (levels - 1.0) + 0.5 + th * p_dither) / (levels - 1.0);
  // optional palette snap to the kit palette
  if (p_paletteSnap) {
    vec3 cand[5] = vec3[5](u_bg, u_ink, u_a0, u_a1, u_a2);
    float best = 1e9; vec3 bc = q;
    for (int i = 0; i < 5; i++) { float d = distance(c + th * 0.25 * p_dither, cand[i]); if (d < best) { best = d; bc = cand[i]; } }
    q = bc;
  }
  vec3 col = sat(q);
  // scan glitch rows (limited)
  float g = step(0.97, h21(vec2(band, tslot(12.0))));
  col = mix(col, col.gbr, g * p_glitch);
  return vec4(col, 1.0);
}

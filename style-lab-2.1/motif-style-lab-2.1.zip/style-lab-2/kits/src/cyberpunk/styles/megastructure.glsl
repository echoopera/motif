// Megastructure — a flight through a brutalist arcology: repeating slabs, neon window bands, fog and traffic in the voids.
vec2 MS_map(vec3 p) {
  float per = 2.0;
  vec3 q = p;
  q.z = mod(q.z, per) - per * 0.5;
  // central canyon: blocks either side
  float side = sign(p.x);
  vec3 b = vec3(abs(p.x) - 1.1 - 0.5 * p_width, p.y, q.z);
  float cell = floor(p.z / per);
  float hgt = 0.6 + 1.2 * h11(cell * 3.0 + side);
  float tower = sdBox3(b - vec3(0.0, hgt * 0.5 - 1.0, 0.0), vec3(0.45, hgt + 1.0, 0.8));
  // stacked slabs cantilever into the canyon
  vec3 s = vec3(abs(p.x) - 0.9, mod(p.y + 0.2, 0.55) - 0.275, q.z);
  float slab = sdBox3(s, vec3(0.35 * p_cantilever, 0.03, 0.6));
  slab = max(slab, p.y - hgt + 0.3);
  // bridges spanning the canyon
  vec3 br = vec3(p.x, p.y - (0.3 + 0.6 * h11(cell + 9.0)), q.z - 0.3);
  float bridge = step(0.5, h11(cell + 17.0)) > 0.5 ? sdBox3(br, vec3(1.5, 0.025, 0.08)) : 1e3;
  float d = min(min(tower, slab), bridge * (p_bridges > 0.5 ? 1.0 : 1e3));
  float mat = d == tower ? 0.0 : d == slab ? 1.0 : 2.0;
  return vec2(d, mat);
}
vec4 motif(vec2 uv, vec2 fc) {
  float per = 2.0;
  float z = u_p * per * float(p_speed) * 2.0;
  vec3 ro = vec3(0.12 * lsin(1.0, 0.0), 0.15 + 0.1 * lsin(1.0, 0.3) + p_height * 0.6, z);
  vec3 fw = normalize(vec3(0.05 * lsin(1.0, 0.6), -0.05 - p_height * 0.1, 1.0));
  vec3 rt = normalize(cross(vec3(0.0, 1.0, 0.0), fw)), up = cross(fw, rt);
  vec3 rd = normalize(fw * 1.4 + uv.x * rt + uv.y * up);
  float t = 0.05; vec2 h = vec2(0.0); float hit = 0.0;
  int steps = 50 + int(70.0 * p_quality);
  for (int i = 0; i < 120; i++) { if (i >= steps) break; h = MS_map(ro + rd * t); if (h.x < 0.001 * t) { hit = 1.0; break; } t += h.x * 0.9; if (t > 30.0) break; }
  vec3 col = vec3(0.0);
  vec3 fogC = mix(u_a1 * 0.25, u_a0 * 0.2, sat(uv.y + 0.4));
  if (hit > 0.0) {
    vec3 p = ro + rd * t;
    vec2 e = vec2(0.002, 0.0);
    vec3 n = normalize(vec3(MS_map(p + e.xyy).x - MS_map(p - e.xyy).x, MS_map(p + e.yxy).x - MS_map(p - e.yxy).x, MS_map(p + e.yyx).x - MS_map(p - e.yyx).x));
    float concrete = 0.5 + 0.5 * snoise(p * 9.0);
    vec3 base = u_bg * 1.5 + u_ink * 0.04 * concrete;
    // window bands on tower faces
    vec2 wg = vec2(p.z * 10.0, p.y * 14.0);
    float win = step(0.35, fract(wg.x)) * step(0.4, fract(wg.y)) * step(0.45, h21(floor(wg))) * step(0.5, abs(n.x));
    vec3 wc = accent(floor(h21(floor(wg) + 3.0) * 3.0));
    // neon strips along slab edges
    float strip = h.y == 1.0 ? exp(-abs(fract(p.y * 1.818 + 0.36) - 0.5) * 40.0) * step(0.5, abs(n.y) < 0.5 ? 1.0 : 0.0) : 0.0;
    float dif = 0.2 + 0.8 * sat(dot(n, normalize(vec3(0.4, 0.8, -0.3))));
    col = base * dif + wc * win * 1.4 * p_windows + u_a0 * strip * 2.0 * p_neon;
    col = mix(col, fogC, 1.0 - exp(-t * 0.12 * p_fog));
  } else {
    col = fogC + u_a1 * 0.2 * exp(-abs(uv.y - 0.1) * 6.0);
  }
  // traffic: light streams in the canyon
  for (int i = 0; i < 6; i++) {
    float fi = float(i);
    vec3 hh = h33(vec3(fi, 1.0, 2.0));
    float lane = (hh.x - 0.5) * 1.2, ly = 0.1 + hh.y * 0.9;
    // project a line along z at (lane, ly)
    vec3 a0 = vec3(lane, ly, 0.0) - ro;
    float dz = rd.z; if (dz < 0.01) continue;
    float tt = (lane - ro.x) / max(abs(rd.x), 1e-3);
    vec3 pp = ro + rd * max((ly - ro.y) / (rd.y + sign(rd.y) * 1e-4), 0.0);
    float dx = abs(pp.x - lane) / (0.02 + (pp.z - ro.z) * 0.01);
    float seg = fract(pp.z * 0.3 - u_p * float(p_speed) * 3.0 * (hh.z < 0.5 ? 1.0 : -1.0) + hh.z);
    float dd = step(0.0, (ly - ro.y) / (rd.y + sign(rd.y) * 1e-4)) * exp(-dx * dx * 4.0) * smoothstep(0.0, 0.5, seg) * (1.0 - smoothstep(0.5, 0.52, seg));
    float occl = hit > 0.0 && t < length(pp - ro) ? 0.0 : 1.0;
    col += (hh.z < 0.5 ? u_a0 : u_ink) * dd * 0.6 * p_traffic * occl * exp(-length(pp - ro) * 0.1);
  }
  col = aces(col * 1.3);
  return vec4(col, 1.0);
}

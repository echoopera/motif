// Smog Sprawl — a layered skyline breathes under smog: lit windows, blinking masts, searchlights and air traffic.
vec4 motif(vec2 uv, vec2 fc) {
  vec2 A = M_asp() * 0.5;
  vec3 col = mix(mix(u_a1 * 0.35, u_a0 * 0.2, sat(uv.y * 2.0 + 0.2)), u_bg, sat(uv.y * 1.5 + 0.1));
  // searchlights
  for (int i = 0; i < 3; i++) {
    if (i >= p_searchlights) break;
    vec2 o = vec2((float(i) - 1.0) * 0.5, -A.y);
    float a = 0.4 * lsin(1.0, float(i) * 0.3) + (float(i) - 1.0) * 0.25;
    vec2 d = vec2(sin(a), cos(a));
    vec2 q = uv - o;
    float al = dot(q, d), pe = abs(dot(q, vec2(-d.y, d.x)));
    col += mix(u_ink, u_a1, 0.5) * exp(-pe / (0.01 + max(al, 0.0) * 0.05)) * step(0.0, al) * 0.18 * exp(-max(al, 0.0) * 1.2);
  }
  // air traffic streaks (behind the front layers)
  for (int i = 0; i < 5; i++) {
    if (i >= p_traffic) break;
    vec3 h = h33(vec3(float(i), 2.0, 9.0));
    float y = 0.05 + h.y * A.y * 0.7;
    float x = (fract(h.x + u_p * float(p_speed) * (h.z < 0.5 ? 1.0 : -1.0)) - 0.5) * 2.4 * A.x;
    vec2 q = uv - vec2(x, y);
    float trail = exp(-q.y * q.y * 40000.0) * exp(-abs(q.x) * 12.0) * step(0.0, q.x * (h.z < 0.5 ? -1.0 : 1.0));
    col += (h.z < 0.5 ? u_a1 : u_ink) * (trail * 0.8 + exp(-dot(q, q) * 60000.0) * 2.0);
  }
  // skyline layers, back to front
  for (int l = 0; l < 4; l++) {
    float fl = float(l);
    float par = (0.02 + fl * 0.02) * p_parallax;
    float x = uv.x + par * lsin(1.0, 0.0) + fl * 3.1;
    float bw = 0.05 + 0.03 * fl;
    float bid = floor(x / bw);
    vec3 h = h33(vec3(bid, fl, 1.0));
    float top = -A.y + (0.25 + 0.45 * h.x * h.x) * (1.2 - fl * 0.2) * p_height + 0.05 * fl * 0.0 - fl * 0.06 + 0.25;
    top -= 0.2 * fl * 0.0;
    float inB = step(uv.y, top);
    // setbacks and spires
    float bx = fract(x / bw);
    float spire = step(0.8, h.y) * step(abs(bx - 0.5), 0.06) * step(uv.y, top + 0.08 * h.z) * step(top, uv.y);
    float mast = step(0.8, h.y) * exp(-dot(vec2((bx - 0.5) * bw, uv.y - top - 0.08 * h.z), vec2((bx - 0.5) * bw, uv.y - top - 0.08 * h.z)) * 60000.0) * step(0.5, fract(u_p * 6.0 + h.z));
    vec3 layerC = mix(u_bg, u_a1 * 0.15, 0.3 / (fl + 1.0)) * (0.5 + fl * 0.15);
    // windows
    vec2 wq = vec2(bx * (3.0 + fl), uv.y * (34.0 + fl * 12.0));
    float win = step(0.4, fract(wq.x)) * step(0.35, fract(wq.y)) * step(1.0 - p_windows * 0.6, h21(floor(wq) + bid * 7.0 + fl));
    vec3 wc = mix(u_a2, u_ink, h21(floor(wq))) * (0.4 + fl * 0.2);
    // holo billboards on some buildings
    float bb = step(0.85, h.z) * step(abs(bx - 0.5), 0.3) * step(abs(uv.y - top + 0.08), 0.04);
    vec3 bbc = accent(bid) * (0.6 + 0.4 * sin(uv.y * 400.0)) * (0.8 + 0.2 * lsin(4.0, h.x));
    vec3 lc2 = layerC + wc * win + bbc * bb * p_billboards;
    // smog between layers
    float smog = p_smog * (0.25 + 0.15 * lfbm(vec2(uv.x * 2.0 + fl, uv.y * 4.0), 3, 1.0, 0.3)) * (1.0 - fl / 4.0) * exp(-(uv.y + A.y) * 1.5);
    col = mix(col, lc2, max(inB, spire));
    col = mix(col, mix(u_a0, u_a1, 0.5) * 0.5, smog);
    col += u_a0 * mast * 2.0;
  }
  col = aces(col * 1.2);
  return vec4(col, 1.0);
}

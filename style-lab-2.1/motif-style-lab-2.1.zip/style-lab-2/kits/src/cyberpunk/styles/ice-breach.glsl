// ICE Breach — flying low over wireframe cyberspace: data towers stand guard until a red intrusion wave rips through the grid.
vec4 motif(vec2 uv, vec2 fc) {
  float hz = 0.08 + 0.1 * p_pitch;
  vec3 col = vec3(0.0);
  float travel = u_p * float(p_speed) * 8.0;       // grid cells per loop (multiple of the tower period)
  float cyc = fract(u_p * float(p_breaches));      // intrusion cycle
  if (uv.y < hz) {
    float dy = hz - uv.y;
    float z = 0.25 / dy;
    vec2 g = vec2(uv.x * z * 1.2 * p_gridDensity, z + travel);
    vec2 gf = abs(fract(g) - 0.5);
    float lw = 0.02 + 0.015 * z;
    float grid = max(1.0 - smoothstep(0.0, lw, gf.x * 1.0), 1.0 - smoothstep(0.0, lw, gf.y));
    // intrusion front: expands from a breach point across the grid (in world coords)
    vec2 w = vec2(g.x, g.y - travel);
    vec2 bp = vec2(0.0, 6.0);
    float dist = length(w - bp);
    float front = cyc * 14.0 * p_spread;
    float infected = smoothstep(front, front - 1.0, dist) * (1.0 - smoothstep(0.85, 1.0, cyc));
    float edge = exp(-pow(dist - front, 2.0) * 2.0) * (1.0 - smoothstep(0.85, 1.0, cyc));
    // data packets running along the grid lines
    float pk = pulse(fract(g.y * 0.25), float(p_speed) * 2.0, h11(floor(g.x)), 0.03) * (1.0 - smoothstep(0.0, lw, gf.x));
    vec3 gc = mix(u_a0, u_a1, infected);
    float fade = exp(-z * 0.05);
    col += gc * grid * fade * 0.9 + u_ink * pk * fade * 0.8 * p_packets + u_a1 * edge * fade * 1.5 * grid + u_a1 * edge * 0.15 * fade;
  } else {
    col += mix(u_a0 * 0.08, u_bg, sat((uv.y - hz) * 3.0));
  }
  // data towers: wireframe boxes standing on grid cells, projected in screen space
  for (int i = 0; i < 12; i++) {
    if (i >= p_towers) break;
    vec3 h = h33(vec3(float(i), 3.0, 9.0));
    float gz = floor(h.y * 8.0);
    float zz = mod(gz - travel, 8.0) + 1.0;                // wraps every 8 cells
    float gx = (h.x - 0.5) * 8.0;
    float sy = hz - 0.25 / zz;                            // base on screen
    float sx = gx / (zz * 1.2) ;
    float hgt = (0.4 + 1.6 * h.z) * 0.25 / zz * 3.0 * p_towerHeight;
    float wdt = 0.5 / (zz * 1.2);
    vec2 q = uv - vec2(sx, sy + hgt * 0.5);
    float d = sdBox(q, vec2(wdt * 0.5, hgt * 0.5));
    float wire = 1.0 - smoothstep(0.0, 0.0025, abs(d));
    float inner = step(d, 0.0) * (1.0 - smoothstep(0.0, 0.0025, abs(fract((q.y / hgt + 0.5) * 6.0) - 0.5) * hgt / 6.0 - 0.0));
    // tower gets infected when the front passes its world position
    float inf = smoothstep(cyc * 14.0 * p_spread, cyc * 14.0 * p_spread - 1.0, length(vec2(gx, zz) - vec2(0.0, 6.0))) * (1.0 - smoothstep(0.85, 1.0, cyc));
    vec3 tc = mix(u_a2, u_a1, inf);
    float glitch = inf * step(0.6, h21(vec2(floor(q.y / hgt * 20.0), tslot(24.0) + float(i))));
    float fade = exp(-zz * 0.08) * smoothstep(8.9, 8.0, zz) * smoothstep(1.0, 1.4, zz);
    col = mix(col, u_bg, step(d, 0.0) * 0.85 * smoothstep(8.9, 8.0, zz) * smoothstep(1.0, 1.4, zz));
    col += tc * (wire * 1.3 + inner * 0.4 + exp(-max(d, 0.0) * 60.0) * 0.2 * p_glow) * fade * (1.0 - glitch * 0.8);
  }
  col = aces(col * 1.2);
  return vec4(col, 1.0);
}

// Thermal Scan — a FLIR sweep over a night street: heat blooms from engines, vents and walkers under a targeting HUD.
vec4 motif(vec2 uv, vec2 fc) {
  vec2 A = M_asp() * 0.5;
  float T = 0.18;                                        // ambient
  // ground plane + building facades with cool windows and warm vents
  float hz = 0.02;
  float facade = step(hz, uv.y);
  T += facade * (0.1 + 0.05 * step(0.5, h21(floor(uv * vec2(18.0, 12.0))))) ;
  vec2 vq = uv * vec2(9.0, 7.0); vec2 vn = floor(vq);
  float vent = step(0.86, h21(vn + 4.0)) * exp(-length(fract(vq) - 0.5) * 6.0) * facade;
  T += vent * (0.5 + 0.2 * lsin(2.0, h21(vn)));
  // steam plumes rising from vents
  float plume = facade * pow(sat(lfbm(vec2(uv.x * 6.0, uv.y * 3.0 - u_p * 0.0) , 4, float(p_speed), 0.4) + 0.2), 3.0) * 0.25 * p_plumes;
  T += plume;
  // road with warm tyre tracks
  float road = (1.0 - facade) * smoothstep(-A.y, hz, uv.y);
  T += road * 0.05;
  // vehicles moving along the road (engines hot)
  for (int i = 0; i < 4; i++) {
    if (i >= p_vehicles) break;
    vec3 h = h33(vec3(float(i), 7.0, 1.0));
    float dir = h.x < 0.5 ? 1.0 : -1.0;
    float x = (fract(h.y + u_p * float(p_speed) * dir) - 0.5) * 2.4 * A.x;
    float y = -A.y * 0.35 - 0.12 * h.z;
    vec2 q = uv - vec2(x, y);
    float body = 1.0 - smoothstep(0.0, 0.01, sdBox(q, vec2(0.11, 0.035)) - 0.01);
    float engine = exp(-length(q - vec2(0.07 * dir, 0.0)) * 40.0);
    float exhaust = exp(-length((q + vec2(0.13 * dir, 0.02)) * vec2(0.6, 3.0)) * 18.0);
    T = mix(T, 0.45, body * 0.8); T += engine * 0.6 + exhaust * 0.3;
  }
  // walkers: warm capsules crossing
  for (int i = 0; i < 8; i++) {
    if (i >= p_walkers) break;
    vec3 h = h33(vec3(float(i), 3.0, 4.0));
    float dir = h.x < 0.5 ? 1.0 : -1.0;
    float x = (fract(h.y + u_p * float(p_speed) * dir) - 0.5) * 2.2 * A.x;
    float y = hz - 0.03 - 0.06 * h.z;
    vec2 q = uv - vec2(x, y + 0.05);
    float bob = 0.004 * sin(TAU * (u_p * float(p_speed) * 20.0 + h.x));
    float bodyD = min(length(q - vec2(0.0, 0.045 + bob)) - 0.012, sdSeg(q, vec2(0.0, 0.03 + bob), vec2(0.0, -0.03)) - 0.011);
    T = max(T, (1.0 - smoothstep(0.0, 0.006, bodyD)) * (0.72 + 0.1 * h.z));
  }
  // scan sweep
  float sweep = pulse((uv.x + A.x) / (2.0 * A.x), float(p_speed), 0.0, 0.02);
  T += sweep * 0.06 * p_sweep;
  // sensor noise and contrast
  T += (h21(fc + tslot(24.0)) - 0.5) * 0.03 * p_noise;
  T = sat((T - 0.12) * mix(1.0, 1.7, p_contrast));
  vec3 col;
  if (p_mode == MODE_WHITE_HOT) col = vec3(T);
  else { vec3 deep = u_bg * 0.6 + vec3(0.07, 0.0, 0.16); col = T < 0.3 ? mix(u_bg, deep, T / 0.3) : T < 0.55 ? mix(deep, u_a1, (T - 0.3) / 0.25) : T < 0.8 ? mix(u_a1, u_a0, (T - 0.55) / 0.25) : mix(u_a0, u_ink, (T - 0.8) / 0.2); }
  // HUD: crosshair, temperature scale, corner brackets
  vec2 cq = abs(uv);
  float ch = (step(cq.x, 0.0012) * step(0.02, cq.y) * step(cq.y, 0.06) + step(cq.y, 0.0012) * step(0.02, cq.x) * step(cq.x, 0.06));
  float scale = step(A.x - 0.06, uv.x) * step(uv.x, A.x - 0.04) * step(abs(uv.y), A.y * 0.6);
  vec3 scC = mix(u_a2, u_a0, (uv.y + A.y * 0.6) / (A.y * 1.2));
  vec2 bq = abs(uv) - A * 0.88;
  float brk = step(0.0, bq.x + 0.06) * step(bq.x, 0.0) * step(abs(bq.y), 0.0015) + step(0.0, bq.y + 0.06) * step(bq.y, 0.0) * step(abs(bq.x), 0.0015);
  col = mix(col, u_ink, (ch + brk) * p_hud);
  col = mix(col, scC, scale * p_hud);
  return vec4(col, 1.0);
}

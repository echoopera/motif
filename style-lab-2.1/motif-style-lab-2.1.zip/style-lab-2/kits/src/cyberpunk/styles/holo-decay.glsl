// Holo Decay — a failing hologram: a turning wireframe form, scanlines, tear bands, colour split and dropouts.
float HD_edge(vec3 p, int shape) {
  // wireframe distance: edges of a polyhedron-like form approximated by folded planes
  if (shape == 0) { // icosahedral-ish: abs folds
    p = abs(p); float d = 1e9;
    vec3 n1 = normalize(vec3(1.0, 1.618, 0.0)), n2 = normalize(vec3(0.0, 1.0, 1.618)), n3 = normalize(vec3(1.618, 0.0, 1.0));
    float a = dot(p, n1), b = dot(p, n2), c = dot(p, n3);
    float m = max(a, max(b, c)) - 0.5;
    // edges: where two planes are nearly equal
    d = min(abs(a - b), min(abs(b - c), abs(a - c)));
    return max(abs(m), d * 0.35);
  }
  if (shape == 1) { vec2 q = vec2(length(p.xz) - 0.42, p.y); float th = atan(p.z, p.x), ph = atan(q.y, q.x); float g = min(abs(fract(th * 18.0 / TAU) - 0.5), abs(fract(ph * 10.0 / TAU) - 0.5)); return max(abs(length(q) - 0.16), g * 0.05); }
  // sphere lat/long
  float r = length(p); float th = atan(p.z, p.x), ph = acos(clamp(p.y / max(r, 1e-4), -1.0, 1.0));
  float g = min(abs(fract(th * 16.0 / TAU) - 0.5), abs(fract(ph * 9.0 / PI) - 0.5));
  return max(abs(r - 0.5), g * 0.06);
}
vec4 motif(vec2 uv, vec2 fc) {
  vec2 A = M_asp() * 0.5;
  float sl = tslot(20.0);
  // tear bands: horizontal slices displaced
  float band = floor((uv.y + A.y) * 14.0);
  float tear = step(1.0 - 0.25 * p_decay, h21(vec2(band, sl))) * (h21(vec2(band, sl + 3.0)) - 0.5) * 0.12 * p_decay;
  vec2 q = uv + vec2(tear, 0.0);
  float ang = TAU * u_p * float(p_spin);
  vec3 col = vec3(0.0);
  for (int ch = 0; ch < 3; ch++) {
    vec2 qo = q + vec2((float(ch) - 1.0) * 0.006 * p_split, 0.0);
    // orthographic ray through the form: march a few samples in depth to find nearest edge
    float best = 1e9;
    for (int k = 0; k < 24; k++) {
      float z = -0.7 + float(k) / 23.0 * 1.4;
      vec3 p = vec3(qo / p_size, z);
      p.xz = rot(ang) * p.xz; p.yz = rot(0.35) * p.yz;
      best = min(best, HD_edge(p, p_shape));
    }
    float w = line(best, 0.012) * 1.0 + glow2(best, 0.02) * 0.25;
    col[ch] = w;
  }
  vec3 tint = mix(u_a1, u_ink, 0.25);
  col = tint * (col.r + col.g + col.b) / 3.0 + vec3(col.r - col.b, 0.0, col.b - col.r) * 0.35 * p_split;
  col = max(col, 0.0);
  // scanlines + rolling bar
  col *= 0.7 + 0.3 * sin(fc.y * PI * 0.5 * p_scanDensity);
  col *= 0.8 + 0.4 * pulse((uv.y + A.y) / (2.0 * A.y), safeCycles(1.0), 0.0, 0.08);
  // projector cone from below
  float cone = exp(-abs(uv.x) * 8.0 / (1.0 + (uv.y + A.y) * 2.0)) * smoothstep(A.y * 0.2, -A.y, uv.y) * 0.15 * p_cone;
  col += u_a1 * cone;
  col += u_a1 * exp(-length((uv - vec2(0.0, -A.y * 0.85)) * vec2(1.0, 4.0)) * 12.0) * p_cone;
  // flicker + dropouts (limited)
  float fl = 1.0 - 0.6 * step(0.8, h11(sl + 7.0)) * p_flicker;
  float drop = step(1.0 - 0.1 * p_decay, h21(vec2(floor(fc.y / 3.0), sl)));
  col *= fl * (1.0 - drop);
  col += u_ink * 0.05 * (h21(fc + sl) - 0.5) * p_noise;
  col = aces(col * 1.5);
  return vec4(col, max(max(col.r, col.g), col.b));
}

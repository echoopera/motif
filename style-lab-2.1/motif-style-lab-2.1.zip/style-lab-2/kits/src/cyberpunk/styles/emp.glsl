// EMP — an electromagnetic pulse tears through the grid: shock rings warp space, arcs of lightning crawl, static floods the signal.
float EMP_bolt(vec2 uv, vec2 a, vec2 b, float seed, float t) {
  vec2 ab = b - a; float L = length(ab); vec2 dir = ab / L, nn = vec2(-dir.y, dir.x);
  float s = dot(uv - a, dir) / L;
  if (s < 0.0 || s > 1.0) return 0.0;
  float off = 0.0, amp = 0.08 * L;
  for (int i = 0; i < 5; i++) { float fi = float(i); off += amp * (h11(floor(s * pow(2.0, fi + 2.0)) + seed * 17.0 + fi + t * 31.0) - 0.5) * (1.0 - fract(s * pow(2.0, fi + 2.0)) * 0.0); amp *= 0.55; }
  off *= sin(PI * s);
  float d = abs(dot(uv - a, nn) - off);
  return exp(-d * d * 60000.0) + exp(-d * 60.0) * 0.08;
}
vec4 motif(vec2 uv, vec2 fc) {
  vec2 A = M_asp() * 0.5;
  float ncyc = safeCycles(float(p_pulses)); float cyc = ncyc < 1.0 ? 0.5 : fract(u_p * ncyc);
  // shock ring
  float R = pow(cyc, 0.6) * 1.4 * p_reach;
  float r = length(uv);
  float ring = exp(-pow((r - R) * 25.0 / p_ringWidth, 2.0)) * (1.0 - cyc);
  vec2 warp = normalize(uv + 1e-4) * ring * 0.04 * p_warp;
  vec2 q = uv - warp;
  // background: city grid being hit
  vec2 g = abs(fract(q * 10.0) - 0.5);
  float grid = 1.0 - smoothstep(0.0, 0.03, min(g.x, g.y));
  float hit = smoothstep(R, R - 0.3, r) * (1.0 - cyc);
  vec3 col = mix(u_a2 * 0.25, u_a1 * 0.9, hit) * grid * (0.6 + 0.4 * hit) * p_grid;
  // arcs: bolts between nodes, re-strike each time slot (limited)
  float ts = tslot(16.0 * p_arcRate + 1.0);
  for (int i = 0; i < 6; i++) {
    if (i >= p_arcs) break;
    vec3 h = h33(vec3(float(i), ts, 2.0));
    vec2 a = (h.xy - 0.5) * A * 1.8;
    vec2 b = a + (h33(vec3(float(i), ts, 5.0)).xy - 0.5) * 0.6;
    float bolt = EMP_bolt(q, a, b, float(i), ts);
    float live = step(0.4, h.z) * smoothstep(1.0, 0.0, tfrac(16.0 * p_arcRate + 1.0) * 1.5);
    col += mix(u_a0, u_ink, 0.5) * bolt * live * 1.4;
  }
  col += mix(u_a0, u_ink, 0.4) * ring * 1.2 + u_a0 * exp(-r * 8.0) * flashAmt(exp(-cyc * 20.0)) * p_flash * 2.0;
  // static bursts: horizontal noise bands (limited rate)
  float sb = step(1.0 - 0.3 * p_static, h11(tslot(18.0) + 9.0)) * hit;
  float noise = h21(floor(fc / vec2(2.0, 1.0)) + tslot(18.0) * 13.0);
  col = mix(col, vec3(noise) * mix(u_ink, u_a0, 0.3), sb * 0.6 * p_static);
  // row shift during the pulse
  col *= 1.0 - 0.3 * step(0.8, h21(vec2(floor(fc.y / 6.0), tslot(18.0)))) * hit * p_static;
  col = aces(col * 1.2);
  return vec4(col, max(max(col.r, col.g), col.b));
}

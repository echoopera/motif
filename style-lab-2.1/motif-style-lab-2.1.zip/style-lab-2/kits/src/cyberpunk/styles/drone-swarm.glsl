// Drone Swarm — a flock of drones morphs between formations over the city while targeting reticles lock and track.
vec2 DS_pos(float i, float N) {
  vec3 h = h33(vec3(i, 4.0, 2.0));
  float a = i / N * TAU;
  // formation morph: ring -> grid -> helix-ish, loop-periodic blend
  float m = 0.5 + 0.5 * lsin(float(p_morphs), 0.0);
  vec2 ring = vec2(cos(a + TAU * u_p * float(p_speed)), sin(a + TAU * u_p * float(p_speed)) * 0.5) * 0.32;
  float gs = ceil(sqrt(N));
  vec2 grid = (vec2(mod(i, gs), floor(i / gs)) / gs - 0.45) * vec2(0.9, 0.5) + vec2(0.05 * lsin(float(p_speed), h.x), 0.0);
  vec2 p = mix(ring, grid, smoothstep(0.2, 0.8, m));
  // boid-like jitter
  p += 0.03 * p_chaos * vec2(ln2(vec2(i, 1.0), float(p_speed), 0.4), ln2(vec2(i, 7.0), float(p_speed), 0.4));
  return p;
}
vec4 motif(vec2 uv, vec2 fc) {
  vec2 A = M_asp() * 0.5;
  vec3 col = vec3(0.0);
  // city silhouette + haze
  float bx = floor(uv.x * 14.0);
  float bh = -A.y + 0.1 + 0.25 * h11(bx) + 0.1 * h11(floor(uv.x * 37.0));
  float city = step(uv.y, bh);
  col += mix(u_a1 * 0.15, u_bg, sat((uv.y + A.y) * 1.2)) * (1.0 - city) + u_bg * 0.5 * city;
  vec2 wq = uv * vec2(80.0, 60.0);
  col += u_a2 * 0.5 * city * step(0.75, h21(floor(wq))) * step(0.3, fract(wq.x)) * step(0.3, fract(wq.y));
  float N = float(p_drones);
  float sz = 0.012 * p_size;
  for (int i = 0; i < 48; i++) {
    if (i >= p_drones) break;
    float fi = float(i);
    vec2 p = DS_pos(fi, N) + vec2(0.0, 0.08);
    vec2 q = uv - p;
    if (dot(q, q) > 0.01) continue;
    // body: X frame with four rotor discs
    vec2 aq = abs(rot(0.785) * q);
    float arm = min(sdBox(aq, vec2(sz, sz * 0.12)), sdBox(aq.yx, vec2(sz, sz * 0.12)));
    float rotor = 1e9;
    for (int r = 0; r < 4; r++) { vec2 rp = rot(float(r) * 1.5708 + 0.785) * vec2(sz, 0.0); rotor = min(rotor, abs(length(q - rp) - sz * 0.5)); }
    float body = 1.0 - smoothstep(0.0, aa(), min(arm, length(q) - sz * 0.3));
    float rot_ = (1.0 - smoothstep(0.0, aa() * 2.0, rotor - sz * 0.05)) * 0.5;
    // nav light blink (limited)
    float blink = strobe(12.0, 0.5);
    col = mix(col, u_bg * 0.3, body);
    col += u_ink * 0.3 * rot_ + mix(u_a0, u_a1, step(0.5, h11(fi + 3.0))) * exp(-dot(q, q) * 90000.0) * (0.4 + 0.8 * blink) * 1.5;
  }
  // targeting: reticles lock onto a subset, cycling targets
  for (int k = 0; k < 6; k++) {
    if (k >= p_targets) break;
    float slot = floor(u_p * float(p_retargets) + float(k) * 0.37);
    float lockFrac = fract(u_p * float(p_retargets) + float(k) * 0.37);
    float tgt = floor(h11(mod(slot, float(p_retargets)) * 11.0 + float(k) * 3.0) * N);
    vec2 tp = DS_pos(tgt, N) + vec2(0.0, 0.08);
    float s = mix(0.08, 0.025, smoothstep(0.0, 0.3, lockFrac));
    vec2 q = abs(uv - tp);
    float bracket = max(step(q.x, s) * step(s - 0.003, q.x), step(q.y, s) * step(s - 0.003, q.y)) * step(s * 0.6, max(q.x, q.y));
    float cross_ = step(min(q.x, q.y), 0.0012) * step(max(q.x, q.y), s * 0.35) * step(s * 0.12, max(q.x, q.y));
    float locked = smoothstep(0.28, 0.32, lockFrac);
    vec3 rc = mix(u_a2, u_a0, locked);
    col += rc * (bracket + cross_) * 1.2;
    // data tag: bars beside the target
    vec2 tq = uv - tp - vec2(s + 0.01, s * 0.6);
    float bars = step(0.0, tq.x) * step(tq.x, 0.06 * (0.4 + 0.6 * h11(float(k) + slot))) * step(abs(tq.y), 0.003) + step(0.0, tq.x) * step(tq.x, 0.035) * step(abs(tq.y + 0.01), 0.002);
    col += rc * bars * locked * 0.9;
    // tracking line to the frame edge
    col += rc * 0.25 * line(abs(uv.y - tp.y), 0.0008) * step(uv.x, tp.x - s) * locked * p_lines;
  }
  // scanning grid overlay
  vec2 gq = abs(fract(uv * 8.0) - 0.5);
  col += u_a2 * 0.04 * (1.0 - smoothstep(0.0, 0.01, min(gq.x, gq.y))) * p_grid;
  col = aces(col * 1.15);
  return vec4(col, 1.0);
}

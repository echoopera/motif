// CRT Burn (pass 2) — phosphor persistence: the source a few moments earlier, decaying.
vec4 motif(vec2 uv, vec2 fc) {
  vec3 acc = vec3(0.0);
  // re-render the scene at earlier phases (stateless persistence)
  for (int i = 1; i <= 3; i++) {
    float dp = float(i) * 0.012 * p_persistence;
    vec2 A = M_asp() * 0.5;
    // shift the scene's motion by sampling the source displaced along its dominant motion (approximation)
    acc += texture(u_buf0, (fc - vec2(float(i) * 3.0 * p_persistence, 0.0)) / u_res).rgb * pow(0.55, float(i));
  }
  return vec4(acc, 1.0);
}

// Net Tunnel — racing down an endless data corridor: panels of streaming code, light bars and packet trails rush past.
vec4 motif(vec2 uv, vec2 fc) {
  vec2 q = uv;
  q += 0.04 * p_sway * vec2(lsin(1.0, 0.0), lsin(1.0, 0.25));
  // square tunnel: distance to the nearest wall in "square polar" coordinates
  vec2 aq = abs(q);
  float r = max(aq.x * (1.0 - 0.4 * p_round) + length(q) * 0.4 * p_round, aq.y);
  float z = 0.35 / max(r, 1e-3);                          // depth
  float travel = u_p * float(p_speed) * 8.0;              // integer panels per loop
  float wall = aq.x > aq.y ? (q.x > 0.0 ? 0.0 : 2.0) : (q.y > 0.0 ? 1.0 : 3.0);
  float s = aq.x > aq.y ? q.y / aq.x : q.x / aq.y;        // -1..1 across the wall
  float zz = z + travel;
  vec2 pc = vec2(s * float(p_panels), zz);
  vec2 id = floor(pc), f = fract(pc);
  vec3 h = h33(vec3(id.x + wall * 10.0, mod(id.y, 64.0), 1.0));
  // panel frames
  float frame = 1.0 - smoothstep(0.0, 0.03, min(min(f.x, 1.0 - f.x), min(f.y, 1.0 - f.y)));
  // code rows inside panels (glyph micro-texture)
  vec2 gc = fract(pc * vec2(4.0, 6.0));
  float g = CP_glyph(gc * 1.1 - 0.05, floor(h21(floor(pc * vec2(4.0, 6.0)) + wall) * 40.0));
  float lit = step(0.45, h.x);
  // light bars: rings around the tunnel every few units
  float ringPos = fract(zz / 4.0);
  float ring = exp(-pow((ringPos - 0.5) * 30.0, 2.0)) * p_rings;
  // packet trails: bright streaks moving faster than the camera
  float lane = floor(s * 6.0);
  float pk = pulse(fract(zz * 0.125 + h11(lane + wall * 7.0)), float(p_speed) * 3.0, 0.0, 0.02) * (1.0 - smoothstep(0.0, 0.08, abs(fract(s * 6.0) - 0.5)));
  float fog = exp(-z * 0.12 * p_fog);
  vec3 wc = accent(wall + h.y * 2.0);
  vec3 col = (wc * g * lit * 0.8 * p_code + u_ink * frame * 0.25 + wc * ring * 1.6 + u_ink * pk * 1.8 * p_packets) * fog;
  // end of the tunnel glow
  col += mix(u_a0, u_ink, 0.5) * exp(-r * 20.0) * 0.8 * p_glow;
  col = aces(col * 1.2);
  return vec4(col, 1.0);
}

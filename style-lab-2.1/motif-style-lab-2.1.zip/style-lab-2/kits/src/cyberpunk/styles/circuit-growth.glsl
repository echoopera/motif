// Circuit Growth — traces autoroute across a board at 45 degrees, vias bloom, and current pulses race home.
vec4 motif(vec2 uv, vec2 fc) {
  float sc = 16.0 * p_density;
  vec2 p = uv * sc;
  vec2 id = floor(p), f = fract(p) - 0.5;
  vec3 h = h33(vec3(id, 1.0));
  // tile types: straight, 45-degree bend, via, empty (truchet PCB)
  float d = 1e9; float along = 0.0;
  float type = floor(h.x * 4.0);
  float r = floor(h.y * 4.0);
  vec2 q = f;
  for (float k = 0.0; k < 4.0; k++) if (k < r) q = vec2(-q.y, q.x);
  if (type < 1.0) { d = abs(q.y); along = q.x + 0.5; }
  else if (type < 2.0) { d = min(sdSeg(q, vec2(-0.5, 0.0), vec2(0.0, 0.0)), sdSeg(q, vec2(0.0, 0.0), vec2(0.5, 0.5))); along = q.x + 0.5; }
  else if (type < 3.0) { d = min(abs(q.y), abs(q.x)); along = max(abs(q.x), abs(q.y)); }
  else { d = sdSeg(q, vec2(-0.5, 0.0), vec2(0.0, 0.0)); along = q.x + 0.5; }
  bool via = h.z < 0.18 * p_vias;
  // growth: a wavefront spreading from routed sources, retracts at the end of the loop
  float g = growEnv(0.4) * (1.6 * p_reach);
  float wave = 0.0;
  float src = 1e9;
  for (int i = 0; i < 4; i++) { if (i >= p_sources) break; vec2 s = (h22(vec2(float(i), 6.0)) - 0.5) * M_asp() * 0.9; src = min(src, length(uv - s) + 0.08 * abs(ln2(uv * 3.0 + float(i), 1.0, 0.2))); }
  float grown = smoothstep(g, g - 0.05, src);
  float front = exp(-pow((src - g) * 40.0, 2.0)) * step(0.02, g);
  float w = 0.07 * p_traceWidth;
  float trace = (1.0 - smoothstep(w, w + 0.04, d)) * grown;
  float pr = 0.18 * p_padSize; float pad = via ? (1.0 - smoothstep(pr - 0.02, pr + 0.02, length(f))) * (smoothstep(pr * 0.35, pr * 0.55, length(f))) * grown : 0.0;
  // current pulses along the traces (direction by tile)
  float pl = pulse(along * 0.25 + (id.x + id.y) * 0.25, float(p_current), 0.0, 0.05) * trace;
  vec3 board = u_bg + u_a2 * 0.05 * (0.5 + 0.5 * ln2(uv * 30.0, 1.0, 0.1)) * p_substrate;
  vec3 copper = mix(u_a2 * 0.8, u_a0, 0.3);
  vec3 col = board + copper * trace * 0.7 + u_ink * pad * 0.8 + u_a0 * pl * 1.8 + u_a1 * front * trace * 2.0 + u_a0 * glow2(d, 0.12) * 0.1 * grown * p_glow;
  // solder mask texture
  col *= 0.92 + 0.08 * h21(floor(fc / 2.0));
  col = aces(col * 1.1);
  return vec4(col, 1.0);
}

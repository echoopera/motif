// Cipher Fall — cascades of invented glyphs pour down in depth layers, heads burning bright, tails decaying.
vec4 motif(vec2 uv, vec2 fc) {
  vec2 A = M_asp() * 0.5;
  vec3 col = vec3(0.0);
  for (int l = 0; l < 3; l++) {
    if (l >= p_layers) break;
    float fl = float(l);
    float gs = (0.035 - fl * 0.008) * p_glyphSize;       // glyph cell height
    vec2 cell = vec2(gs * 0.72, gs);
    vec2 q = uv + vec2(fl * 0.013, 0.0);
    vec2 id = floor(q / cell);
    vec2 f = fract(q / cell);
    vec3 h = h33(vec3(id.x, fl, 3.0));
    if (h.x > p_density) continue;
    // the column's stream: head position falls an integer number of wraps per loop
    float rows = ceil(2.0 * A.y / cell.y) + 1.0;
    float speed = float(p_speed) * (1.0 + floor(h.y * 3.0));
    float tailLen = 6.0 + 18.0 * p_tail;
    float head = fract(h.z + u_p * speed) * (rows + tailLen);
    float r = floor((A.y - q.y) / cell.y);
    float fromHead = head - r;
    float trail = fromHead >= 0.0 ? exp(-fromHead / (tailLen * 0.35)) : 0.0;
    // glyph changes over time (slots, limited)
    float gid = floor(h21(id * 1.3) * 64.0) + floor(tslot(18.0 * p_mutate + 1.0) * step(0.7, h21(id + 5.0)));
    float g = CP_glyph(f * vec2(1.1, 1.05) - vec2(0.05, 0.02), gid);
    float isHead = fromHead >= 0.0 && fromHead < 1.0 ? 1.0 : 0.0;
    vec3 base = p_colourMode == COLOUR_MODE_ACCENTS ? accent(id.x) : u_a0;
    vec3 c = mix(base, u_ink, isHead * 0.85) * (isHead * 1.6 * p_headGlow + trail);
    float depth = 1.0 - fl * 0.35;
    col += c * g * depth * (fl == 0.0 ? 1.0 : 0.6) + u_a0 * trail * 0.04 * depth * p_glow;
  }
  col = aces(col * 1.2);
  return vec4(col, max(max(col.r, col.g), col.b));
}

// Shared source pass for the signal-damage styles (uses p_source).
vec4 motif(vec2 uv, vec2 fc) { return vec4(CP_scene(uv, p_source), 1.0); }

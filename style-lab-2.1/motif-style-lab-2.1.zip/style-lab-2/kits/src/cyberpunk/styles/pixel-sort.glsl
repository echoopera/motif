// Pixel Sort (pass 2) — threshold-sorted smears: bright spans melt into ordered gradients along a turning axis.
vec4 motif(vec2 uv, vec2 fc) {
  float ang = p_angle * PI + 0.2 * p_sway * lsin(1.0, 0.0);
  vec2 dir = vec2(sin(ang), -cos(ang));
  float thr = mix(0.03, 0.75, p_threshold) + 0.15 * p_breathe * lsin(1.0, 0.25);
  float hiThr = p_band > 0.99 ? 2.0 : thr + 0.2 + 0.8 * p_band;
  vec3 c0 = texture(u_buf0, fc / u_res).rgb;
  float l0 = luma(c0);
  if (l0 < thr || l0 > hiThr) return vec4(aces(c0), 1.0);
  // walk both ways to find the span within the threshold band
  float stepPx = 2.0 + 4.0 * p_length;
  float back = 0.0, fwd = 0.0;
  vec3 cLo = c0, cHi = c0; float lLo = l0, lHi = l0;
  for (int i = 1; i <= 40; i++) {
    vec3 c = texture(u_buf0, (fc - dir * stepPx * float(i)) / u_res).rgb; float l = luma(c);
    if (l < thr) break; back = float(i);
    if (l < lLo) { lLo = l; cLo = c; } if (l > lHi) { lHi = l; cHi = c; }
  }
  for (int i = 1; i <= 40; i++) {
    vec3 c = texture(u_buf0, (fc + dir * stepPx * float(i)) / u_res).rgb; float l = luma(c);
    if (l < thr) break; fwd = float(i);
    if (l < lLo) { lLo = l; cLo = c; } if (l > lHi) { lHi = l; cHi = c; }
  }
  float span = back + fwd;
  float tpos = span > 0.0 ? back / span : 0.0;
  if (p_reverse) tpos = 1.0 - tpos;
  // the sorted span: a luminance-ordered gradient between its darkest and brightest samples
  vec3 sorted = mix(cLo, cHi, smoothstep(0.0, 1.0, tpos));
  float amt = smoothstep(2.0, 6.0, span) * p_amount;
  vec3 col = mix(c0, sorted, amt);
  col += u_ink * 0.04 * step(0.985, tpos) * amt;
  return vec4(aces(col * 1.05), 1.0);
}

// Chrome Liquid — mercury metaballs merge and split, mirroring a neon room in their polished skin.
vec3 CL_env(vec3 d) {
  // neon strip room: vertical and horizontal tubes on dark walls
  float a = atan(d.z, d.x), e = d.y;
  float strips = pow(0.5 + 0.5 * cos(a * float(p_strips)), 60.0);
  float bands = exp(-pow((e - 0.35) * 30.0, 2.0)) + exp(-pow((e + 0.2) * 40.0, 2.0)) * 0.6;
  vec3 c = accent(floor((a + PI) / TAU * float(p_strips))) * strips * 1.4 + mix(u_a0, u_a1, 0.5 + 0.5 * sin(a * 2.0)) * bands * 1.2;
  c += mix(u_bg, u_a2 * 0.2, sat(e + 0.5)) * 0.6;
  c += u_ink * pow(sat(e), 40.0) * 2.0;                 // overhead softbox
  return c;
}
float CL_map(vec3 p) {
  float d = 1e9;
  for (int i = 0; i < 8; i++) {
    if (i >= p_blobs) break;
    vec3 h = h33(vec3(float(i), 3.0, 7.0));
    vec3 c = vec3(0.45 * cos(TAU * (u_p * float(p_speed) * (h.x < 0.5 ? 1.0 : 2.0) + h.y)), 0.25 * sin(TAU * (u_p * float(p_speed) + h.z)), 0.3 * sin(TAU * (u_p * float(p_speed) * (h.z < 0.5 ? 1.0 : 2.0) + h.x))) * p_spread;
    float r = 0.16 + 0.12 * h.z;
    d = smin(d, length(p - c) - r, 0.18 * p_viscosity + 0.02);
  }
  d += 0.004 * p_ripple * sin(p.x * 40.0 + TAU * u_p * 3.0) * sin(p.y * 40.0);
  return d;
}
vec4 motif(vec2 uv, vec2 fc) {
  float ang = 0.3 * lsin(1.0, 0.0) * p_orbit;
  vec3 ro = vec3(sin(ang) * 2.2, 0.2, cos(ang) * 2.2);
  vec3 fw = normalize(-ro), rt = normalize(cross(vec3(0.0, 1.0, 0.0), fw)), up = cross(fw, rt);
  vec3 rd = normalize(fw * 1.8 + uv.x * rt + uv.y * up);
  float t = 0.8, hit = 0.0;
  for (int i = 0; i < 80; i++) { float d = CL_map(ro + rd * t); if (d < 0.001) { hit = 1.0; break; } t += d; if (t > 5.0) break; }
  vec3 col; float a;
  if (hit > 0.0) {
    vec3 p = ro + rd * t;
    vec2 e = vec2(0.0015, -0.0015);
    vec3 n = normalize(e.xyy * CL_map(p + e.xyy) + e.yyx * CL_map(p + e.yyx) + e.yxy * CL_map(p + e.yxy) + e.xxx * CL_map(p + e.xxx));
    vec3 r = reflect(rd, n);
    float fres = 0.6 + 0.4 * pow(1.0 - sat(dot(n, -rd)), 5.0);
    vec3 tint = mix(vec3(1.0), u_a2 + 0.5, 0.25 * p_tint);
    col = CL_env(r) * fres * tint;
    // second bounce hint
    col += CL_env(reflect(r, n)) * 0.08;
    a = 1.0;
  } else {
    col = CL_env(rd) * 0.12 * p_room;
    a = 0.0;
  }
  col = aces(col * 1.1);
  return vec4(col, max(a, max(max(col.r, col.g), col.b)));
}

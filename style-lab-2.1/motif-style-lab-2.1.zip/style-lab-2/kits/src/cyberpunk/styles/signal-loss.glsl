// Signal Loss (pass 2) — worn videotape: tracking errors roll through, chroma bleeds, dropouts streak, the head switch tears.
vec4 motif(vec2 uv, vec2 fc) {
  vec2 A = M_asp() * 0.5;
  vec2 t = fc / u_res;
  float y = t.y;
  // tracking band travels down the frame (integer passes per loop)
  float band = fract(y + u_p * float(p_roll));
  float trk = exp(-pow((band - 0.5) * 9.0 / (0.3 + p_tracking), 2.0)) * p_tracking;
  float jit = (h21(vec2(floor(fc.y), tslot(30.0))) - 0.5) * 2.0;
  float xoff = trk * (0.02 + 0.03 * jit) + jit * 0.0015 * p_jitter;
  // head-switching noise at the bottom lines
  float hs = smoothstep(0.035, 0.0, y) * p_headSwitch;
  xoff += hs * (0.04 + 0.03 * sin(fc.y * 0.7));
  // wrinkle: sinusoidal skew band
  xoff += p_wrinkle * 0.01 * sin(y * 40.0 + TAU * u_p * 2.0) * smoothstep(0.2, 0.0, abs(y - 0.7 + 0.2 * lsin(1.0, 0.0)));
  vec2 st = vec2(t.x + xoff, t.y);
  // luma sharp, chroma blurred horizontally and shifted (composite video)
  vec3 c0 = texture(u_buf0, st).rgb;
  float Y = luma(c0);
  vec3 cb = vec3(0.0);
  for (int i = -4; i <= 4; i++) cb += texture(u_buf0, st + vec2(float(i) * 0.004 * p_chroma + 0.006 * p_chroma, 0.0)).rgb;
  cb /= 9.0;
  vec3 chroma = cb - luma(cb);
  vec3 col = Y + chroma * (1.0 - 0.5 * trk);
  // tracking noise inside the band
  col += (h21(fc * 0.5 + tslot(30.0)) - 0.5) * trk * 0.8;
  // dropouts: short white horizontal streaks
  vec2 dq = vec2(floor(fc.x / 40.0), floor(fc.y));
  float drop = step(1.0 - 0.004 * p_dropouts, h21(dq + tslot(30.0) * 7.0));
  col = mix(col, u_ink, drop * 0.9);
  // generation loss: softness + saturation drop + noise
  col = mix(col, vec3(luma(col)), 0.2 * p_wear) + (h21(fc + tslot(30.0) * 3.0) - 0.5) * 0.08 * p_wear;
  col *= 1.0 - hs * 0.4;
  col = aces(max(col, 0.0) * 1.05);
  return vec4(col, 1.0);
}

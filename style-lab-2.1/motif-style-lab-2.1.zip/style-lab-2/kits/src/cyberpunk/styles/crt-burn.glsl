// CRT Burn (pass 3) — curved glass, shadow mask, scanlines, halation and phosphor burn-in.
vec4 motif(vec2 uv, vec2 fc) {
  vec2 t = fc / u_res;
  vec2 c = t * 2.0 - 1.0;
  // barrel distortion
  float k = 0.12 * p_curvature;
  vec2 cd = c * (1.0 + k * dot(c, c));
  vec2 st = cd * 0.5 + 0.5;
  float inside = step(0.0, st.x) * step(st.x, 1.0) * step(0.0, st.y) * step(st.y, 1.0);
  vec3 src = texture(u_buf0, st).rgb;
  vec3 ghost = texture(u_buf1, st).rgb;
  // burn-in: a static layout etched into the phosphor (from the source at a fixed phase is not available, use a frame grid)
  vec3 col = src + ghost * 0.5 * p_persistence;
  // halation: wide blur of bright parts
  vec3 hal = vec3(0.0);
  for (int i = 0; i < 12; i++) { float a = float(i) * 0.5236; hal += texture(u_buf0, st + vec2(cos(a), sin(a)) * 0.012 * p_halation).rgb; }
  col += max(hal / 12.0 - 0.2, 0.0) * 0.8 * p_halation;
  // scanlines (beam profile)
  float lines = u_res.y / (2.0 + 2.0 * p_scanlines);
  float sl = 0.5 + 0.5 * cos(st.y * lines * TAU);
  col *= mix(1.0, 0.45 + 0.75 * sl, p_scanlines);
  // shadow mask (aperture grille)
  float m = mod(fc.x, 3.0);
  vec3 mask = vec3(m < 1.0 ? 1.0 : 0.55, m >= 1.0 && m < 2.0 ? 1.0 : 0.55, m >= 2.0 ? 1.0 : 0.55);
  col *= mix(vec3(1.0), mask * 1.3, p_mask);
  // rolling refresh bar
  col *= 1.0 + 0.08 * pulse(1.0 - st.y, 1.0, 0.0, 0.06) * p_roll;
  // vignette + glass reflection
  float vig = pow(16.0 * st.x * st.y * (1.0 - st.x) * (1.0 - st.y), 0.25);
  col *= vig;
  col += u_ink * 0.04 * exp(-length(c - vec2(-0.5, 0.55)) * 3.0) * p_glass;
  col = aces(col * 1.15) * inside;
  // bezel
  vec3 bz = u_bg * 0.6 + u_ink * 0.03;
  col = mix(bz, col, inside);
  return vec4(col, 1.0);
}

// AR Overlay — an augmented-reality HUD tracks moving targets over a blurred city: reticles, data tags, rings, tapes and readouts.
vec2 AR_target(float i) {
  vec3 h = h33(vec3(i, 6.0, 3.0));
  vec2 A = M_asp() * 0.5;
  return vec2((h.x - 0.5) * A.x * 1.5 + 0.12 * lsin(1.0, h.z), (h.y - 0.5) * A.y * 1.2 + 0.06 * lsin(2.0, h.x));
}
vec4 motif(vec2 uv, vec2 fc) {
  vec2 A = M_asp() * 0.5;
  vec3 col = CP_scene(uv, 0) * 0.35 * p_background;
  vec3 hud = mix(u_a0, u_ink, 0.2);
  float px = aa();
  // central rotating rings with ticks
  float r = length(uv), a = atan(uv.y, uv.x);
  float spin = TAU * u_p * float(p_speed);
  float ring1 = line(abs(r - 0.18), 0.002) * step(0.5, fract((a + spin) / TAU * 3.0 + 0.1));
  float ticks = line(abs(r - 0.21), 0.012) * step(0.8, fract((a - spin * 0.5) / TAU * 72.0));
  float ring2 = line(abs(r - 0.25), 0.0015) * step(0.2, fract((a - spin) / TAU * 5.0));
  col += hud * (ring1 + ticks * 0.8 + ring2 * 0.6) * p_rings;
  // compass tape at the top
  float tapeY = A.y - 0.06;
  if (abs(uv.y - tapeY) < 0.03) {
    float hx = uv.x * 8.0 + u_p * float(p_speed) * 8.0;
    float tk = step(0.92, fract(hx)) * step(abs(uv.y - tapeY), 0.01 + 0.01 * step(0.5, fract(hx / 4.0)));
    col += hud * tk * p_tape;
  }
  col += hud * line(abs(uv.x), 0.002) * step(abs(uv.y - tapeY), 0.035) * p_tape;
  // target reticles with tags and leader lines
  for (int i = 0; i < 8; i++) {
    if (i >= p_targets) break;
    float fi = float(i);
    vec2 tp = AR_target(fi);
    vec2 q = uv - tp;
    float s = 0.035 + 0.01 * sin(TAU * (u_p * float(p_speed) * 2.0 + fi * 0.3));
    vec2 aq = abs(q);
    float corners = (step(aq.x, s) * step(s - 0.002, aq.x) + step(aq.y, s) * step(s - 0.002, aq.y)) * step(s * 0.55, max(aq.x, aq.y));
    float dot_ = 1.0 - smoothstep(0.004, 0.004 + px, length(q));
    vec3 tc = h11(fi + 2.0) < 0.3 ? u_a1 : hud;
    col += tc * (corners + dot_) * 1.2;
    // leader + tag
    vec2 tagP = tp + vec2(0.09, 0.06) * (h11(fi) < 0.5 ? 1.0 : -1.0);
    col += tc * line(sdSeg(uv, tp + normalize(tagP - tp) * s * 1.2, tagP), 0.0015) * 0.8;
    vec2 tq = uv - tagP;
    float dir = sign(tagP.x - tp.x);
    float bars = 0.0;
    for (int b = 0; b < 3; b++) { float w = 0.02 + 0.05 * h11(fi * 3.0 + float(b) + floor(tslot(6.0))); bars += step(0.0, tq.x * dir) * step(tq.x * dir, w) * step(abs(tq.y + float(b) * 0.009), 0.0022); }
    col += tc * bars * p_tags;
    // distance readout bar that fills
    float fillv = fract(u_p * float(p_speed) + h11(fi));
    col += tc * 0.8 * step(0.0, tq.x * dir) * step(tq.x * dir, 0.07 * fillv) * step(abs(tq.y - 0.012), 0.0015) * p_tags;
  }
  // waveform readout bottom-left
  vec2 wq = uv - vec2(-A.x + 0.2, -A.y + 0.08);
  if (abs(wq.x) < 0.16 && abs(wq.y) < 0.05) {
    float w = 0.025 * sin(wq.x * 60.0 + spin * 3.0) * sin(wq.x * 13.0 - spin);
    col += hud * line(abs(wq.y - w), 0.0015) * p_readouts + hud * 0.3 * line(abs(abs(wq.y) - 0.05), 0.001) * p_readouts;
  }
  // bar graph bottom-right
  vec2 bq = uv - vec2(A.x - 0.2, -A.y + 0.04);
  if (bq.x > -0.14 && bq.x < 0.14 && bq.y > 0.0 && bq.y < 0.1) {
    float bi = floor((bq.x + 0.14) / 0.02);
    float hgt = 0.02 + 0.08 * (0.5 + 0.5 * sin(TAU * (u_p * float(p_speed) * 2.0 + bi * 0.17)));
    col += mix(hud, u_a1, step(0.07, hgt)) * step(bq.y, hgt) * step(0.004, fract((bq.x + 0.14) / 0.02) * 0.02) * p_readouts;
  }
  // frame corners + scan line
  vec2 fq = abs(uv) - (A - 0.03);
  col += hud * 0.8 * ((step(-0.08, fq.x) * step(abs(fq.y), 0.0015)) + (step(-0.08, fq.y) * step(abs(fq.x), 0.0015))) * step(fq.x, 0.002) * step(fq.y, 0.002);
  col += hud * 0.15 * pulse((uv.y + A.y) / (2.0 * A.y), float(p_speed), 0.0, 0.01) * p_scan;
  col = aces(col * 1.2);
  return vec4(col, max(max(col.r, col.g), col.b) * 0.0 + 1.0);
}

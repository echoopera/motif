// CYBERPUNK kit common helpers.
// Procedural block glyph (5x7 bit grid) for id g; cell coords c in 0..1. Not any real alphabet.
float CP_glyph(vec2 c, float g) {
  if (c.x < 0.0 || c.y < 0.0 || c.x >= 1.0 || c.y >= 1.0) return 0.0;
  vec2 b = floor(c * vec2(5.0, 7.0));
  float bit = h21(vec2(g * 13.0 + b.x, b.y + g * 7.0));
  // symmetric-ish structure reads as a glyph rather than noise
  float mirror = h21(vec2(g * 13.0 + (4.0 - b.x), b.y + g * 7.0));
  float on = step(0.52, b.x < 2.0 ? bit : (b.x > 2.0 ? mirror : h21(vec2(g, b.y))));
  vec2 f = fract(c * vec2(5.0, 7.0));
  return on * step(0.12, f.x) * step(0.12, f.y);
}
// Neon source scene shared by the signal-damage styles. mode 0 city bokeh, 1 test bars, 2 neon grid.
vec3 CP_scene(vec2 uv, int mode) {
  vec2 A = M_asp() * 0.5;
  vec3 col = vec3(0.0);
  if (mode == 1) {
    float x = (uv.x + A.x) / (2.0 * A.x);
    float bar = floor(x * 7.0);
    vec3 bars[7] = vec3[7](u_ink, u_a2, u_a1, u_a0, mix(u_a0, u_a1, 0.5), mix(u_a1, u_a2, 0.5), u_bg * 0.5 + 0.02);
    col = bars[int(clamp(bar, 0.0, 6.0))] * 0.9;
    if (uv.y < -A.y * 0.45) col = mix(u_bg * 0.3, u_ink, x) * 0.9;
    // moving disc
    vec2 c = vec2(0.45 * lsin(1.0, 0.0) * A.x, 0.1 * lsin(2.0, 0.25));
    col = mix(col, u_a0 * 1.2, 1.0 - smoothstep(0.1, 0.105, length(uv - c)));
    return col;
  }
  if (mode == 2) {
    // neon perspective grid + sun
    float hz = -0.02;
    if (uv.y < hz) {
      float z = 0.12 / (hz - uv.y + 0.001);
      vec2 g = vec2(uv.x * z * 2.0, z + u_p * 4.0);
      vec2 gf = abs(fract(g) - 0.5);
      float ln = max(1.0 - smoothstep(0.0, 0.04 * z, gf.x), 1.0 - smoothstep(0.0, 0.04 * z, gf.y));
      col = u_a0 * ln * exp(-z * 0.06) * 1.3 + u_a1 * 0.08;
    } else {
      float s = length(uv - vec2(0.0, 0.18)) - 0.22;
      float bands = step(0.5, fract((uv.y - 0.1) * 18.0 - u_p * 2.0)) + step(0.25, uv.y);
      col = mix(u_a1, u_a2, sat((uv.y + 0.1) * 2.5)) * (1.0 - smoothstep(0.0, 0.003, s)) * min(bands, 1.0) * 1.2;
      col += u_a1 * 0.25 * exp(-max(s, 0.0) * 8.0) + mix(u_bg, u_a1 * 0.3, sat(1.0 - uv.y * 2.0)) * 0.6;
    }
    return col;
  }
  // city bokeh: out-of-focus lights and signage blocks
  col = mix(u_bg, u_a1 * 0.1 + u_a0 * 0.04, sat(0.5 - uv.y));
  for (int i = 0; i < 26; i++) {
    vec3 h = h33(vec3(float(i), 3.0, 1.0));
    vec2 p = (h.xy - 0.5) * A * 2.2 + vec2(0.04 * lsin(1.0, h.z), 0.0);
    float r = 0.02 + 0.07 * h.z;
    float d = length(uv - p) - r;
    col += accent(floor(h.x * 3.0)) * (1.0 - smoothstep(-0.01, 0.01, d)) * (0.35 + 0.4 * h.y) * (0.75 + 0.25 * smoothstep(-r, 0.0, d));
  }
  for (int i = 0; i < 5; i++) {
    vec3 h = h33(vec3(float(i), 8.0, 2.0));
    vec2 p = (h.xy - 0.5) * A * 1.6;
    vec2 s = vec2(0.05 + 0.12 * h.z, 0.03 + 0.03 * h.x);
    float d = sdBox(uv - p, s);
    col += accent(float(i)) * (1.0 - smoothstep(0.0, 0.004, abs(d) - 0.004)) * 1.4 + accent(float(i)) * exp(-max(d, 0.0) * 30.0) * 0.25;
  }
  return col;
}
// Bayer 4x4 threshold.
float CP_bayer(vec2 fc) {
  ivec2 p = ivec2(mod(fc, 4.0));
  int i = p.x + p.y * 4;
  int m[16] = int[16](0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5);
  return (float(m[i]) + 0.5) / 16.0;
}

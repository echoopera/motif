// Orbitals — hydrogen probability clouds rendered volumetrically; a superposition sloshes at the transition frequency.
float OR_fact(int n) { float f = 1.0; for (int k = 2; k < 10; k++) { if (k > n) break; f *= float(k); } return f; }
// Generalised Laguerre L_k^a(x) by recurrence.
float OR_lag(int k, float a, float x) {
  float l0 = 1.0, l1 = 1.0 + a - x; if (k == 0) return l0; float lk = l1;
  for (int i = 1; i < 6; i++) { if (i >= k) break; float fi = float(i); float l2 = ((2.0 * fi + 1.0 + a - x) * l1 - (fi + a) * l0) / (fi + 1.0); l0 = l1; l1 = l2; lk = l2; }
  return lk;
}
float OR_R(int n, int l, float r) {
  float rho = 2.0 * r / float(n);
  return pow(rho, float(l)) * exp(-rho * 0.5) * OR_lag(n - l - 1, float(2 * l + 1), rho);
}
// Real spherical harmonics (unnormalised shape) up to l = 3.
float OR_Y(int l, int m, vec3 d) {
  float x = d.x, y = d.y, z = d.z;
  if (l == 0) return 0.5;
  if (l == 1) return m == 0 ? z : (m > 0 ? x : y);
  if (l == 2) { if (m == 0) return 3.0 * z * z - 1.0; if (m == 1) return x * z * 2.0; if (m == -1) return y * z * 2.0; if (m == 2) return x * x - y * y; return 2.0 * x * y; }
  if (m == 0) return z * (5.0 * z * z - 3.0); if (m == 1) return x * (5.0 * z * z - 1.0); if (m == -1) return y * (5.0 * z * z - 1.0);
  if (m == 2) return z * (x * x - y * y) * 3.0; if (m == -2) return 6.0 * x * y * z; if (m == 3) return x * (x * x - 3.0 * y * y); return y * (3.0 * x * x - y * y);
}
float OR_psi(int n, int l, int m, vec3 p) { float r = length(p); return OR_R(n, l, r) * OR_Y(l, m, p / max(r, 1e-4)); }
vec4 motif(vec2 uv, vec2 fc) {
  int n = p_n, l = min(p_l, n - 1), m = clamp(p_m, -l, l);
  float ang = TAU * u_p * float(p_spin);
  vec3 ro = vec3(sin(ang), 0.35 * p_elevation, cos(ang)) * 3.0;
  vec3 fw = normalize(-ro), rt = normalize(cross(vec3(0.0, 1.0, 0.0), fw)), up = cross(fw, rt);
  vec3 rd = normalize(fw * 2.2 + uv.x * rt + uv.y * up);
  float scale = (float(n * n) * 2.3 + 3.0) / p_size;     // orbital extent in Bohr radii
  float T = 1.4;
  vec3 col = vec3(0.0); float acc = 0.0;
  int steps = 40 + int(60.0 * p_quality);
  float ds = 2.0 * T / float(steps);
  float jitter = h21(fc) * ds;
  // superposition partner: 1s, or the next lower state, beating at the transition frequency
  float beat = TAU * u_p * float(p_beat);
  float rmax = 0.0; for (int k = 1; k <= 24; k++) rmax = max(rmax, abs(OR_R(n, l, float(k) * float(n * n) * 0.12)));
  float nrm = 1.0 / max(rmax, 1e-4);
  for (int i = 0; i < 100; i++) {
    if (i >= steps) break;
    float t = 3.0 - T + float(i) * ds + jitter;
    vec3 p = ro + rd * t;
    vec3 q = p.xzy * scale;                      // z up
    float a = OR_psi(n, l, m, q) * nrm;
    float b = p_superpose > 0.0 ? OR_psi(1, 0, 0, q * 0.6) * 1.2 : 0.0;
    float re = a + p_superpose * b * cos(beat), im = p_superpose * b * sin(beat);
    float dens = (re * re + im * im) * p_density * 0.9;
    float sgn = re;
    vec3 c = sgn >= 0.0 ? u_a0 : u_a1;
    if (p_colour == COLOUR_PHASE) { float ph = atan(im, re) / TAU + 0.5; c = mix(mix(u_a0, u_a1, sat(ph * 2.0)), u_a2, sat(ph * 2.0 - 1.0)); }
    col += c * dens * ds * (1.0 - acc) * (1.0 - 0.7 * p_dots);
    // Monte-Carlo electron cloud: world-locked sample points, probability proportional to density
    if (p_dots > 0.0) { vec3 cell = floor(q * 1.6); vec3 hq = h33(cell); float dd = length(fract(q * 1.6) - hq); col += mix(c, u_ink, 0.4) * step(hq.x * 3.0, dens) * (1.0 - smoothstep(0.08, 0.14, dd)) * p_dots * 0.6 * (1.0 - acc); }
    acc += dens * ds * 0.25 * p_opacity;
    if (acc > 0.98) break;
  }
  // nucleus
  vec3 oc = -ro; float tc = dot(oc, rd); float dn = length(oc - rd * tc);
  col += u_ink * exp(-dn * dn * 9000.0) * 1.5 * (1.0 - acc * 0.7);
  col = aces(col * 1.4);
  return vec4(col, max(max(col.r, col.g), col.b));
}

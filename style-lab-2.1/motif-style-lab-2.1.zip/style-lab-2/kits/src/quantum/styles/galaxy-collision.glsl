// Galaxy Collision — two spirals swing past each other; tides pull their arms into long luminous tails and bridges.
vec3 GC_galaxy(vec2 q, float spin, float arms, float tilt, vec3 tint, float seedOff) {
  q.y /= tilt;
  float r = length(q), a = atan(q.y, q.x);
  float spiral = 0.5 + 0.5 * cos(arms * (a - log(r + 1e-3) * 2.6 * p_winding) - spin);
  float disk = exp(-r * 9.0);
  float bulge = exp(-r * r * 900.0) * 1.6 + exp(-r * 28.0) * 0.6;
  float clumps = pow(sat(lfbm(q * 14.0 + seedOff, 4, 1.0, 0.25) + 0.3), 3.0);
  float dust = 1.0 - 0.55 * p_dust * smoothstep(0.4, 0.9, spiral) * exp(-r * 6.0) * sat(lfbm(q * 30.0 + seedOff, 3, 1.0, 0.2) + 0.6);
  vec3 armC = mix(tint, u_a2, 0.5) * pow(spiral, 2.0) * disk * (0.6 + 1.6 * clumps);
  return (armC + mix(u_a1, u_ink, 0.5) * bulge) * dust;
}
vec4 motif(vec2 uv, vec2 fc) {
  vec2 q = uv / p_scale;
  // encounter orbit: periodic ellipse in the loop, closest approach twice per cycle
  float ph = TAU * u_p * float(p_orbits);
  vec2 rel = vec2(cos(ph) * 0.34 * p_separation, sin(ph) * 0.14 * p_separation);
  float close = exp(-length(rel) * 5.0);
  vec2 c1 = rel * 0.5, c2 = -rel * 0.5;
  // tidal warp: stretch each galaxy toward the companion, strongest at close approach
  vec2 d12 = normalize(c2 - c1 + 1e-4);
  vec2 q1 = q - c1, q2 = q - c2;
  float tide = p_tides * (0.3 + close);
  q1 -= d12 * dot(q1, d12) * tide * 0.35 * smoothstep(0.0, 0.2, length(q1));
  q2 += d12 * dot(q2, -d12) * tide * 0.35 * smoothstep(0.0, 0.2, length(q2));
  float spin = TAU * u_p * float(p_orbits) * 2.0;
  vec3 col = GC_galaxy(q1, spin, 2.0, 0.55, u_a0, 0.0) + GC_galaxy(rot(0.8) * q2, -spin * 0.5, 2.0, 0.7, u_a2, 9.0) * 0.9;
  // tidal tails: long curved streams trailing each galaxy, plus the bridge between them
  for (int g = 0; g < 2; g++) {
    vec2 c = g == 0 ? c1 : c2;
    vec2 away = g == 0 ? -d12 : d12;
    vec2 perp = vec2(-away.y, away.x) * (g == 0 ? 1.0 : -1.0);
    vec2 dq = q - c;
    float s = dot(dq, away);
    float curve = 0.9 * s * s * p_tailCurve;
    float n = dot(dq, perp) - curve;
    float len = 0.7 * p_tails * (0.4 + close);
    float tail = exp(-n * n / pow(0.02 + s * 0.05, 2.0)) * smoothstep(0.0, 0.08, s) * exp(-s / max(len, 0.01) * 2.0);
    float knots = pow(sat(lfbm(vec2(s * 12.0, n * 30.0) + float(g) * 5.0, 4, 1.0, 0.25) + 0.4), 2.0);
    col += mix(u_a2, u_ink, 0.3) * tail * (0.4 + knots) * 0.8;
  }
  float b = abs(dot(q - c1, vec2(-d12.y, d12.x)));
  float along = dot(q - c1, d12) / max(length(c2 - c1), 1e-3);
  col += u_a2 * exp(-b * b * 800.0) * step(0.0, along) * step(along, 1.0) * close * 0.6 * p_tails;
  // starburst knots triggered by the encounter
  col += u_a1 * close * p_starburst * pow(sat(lfbm(q * 20.0, 3, 1.0, 0.2) + 0.1), 6.0) * exp(-min(length(q1), length(q2)) * 8.0) * 3.0;
  col += Q_stars2(uv, p_stars, 0.4) * 0.6;
  col = aces(col * 1.3);
  return vec4(col, max(max(col.r, col.g), col.b));
}

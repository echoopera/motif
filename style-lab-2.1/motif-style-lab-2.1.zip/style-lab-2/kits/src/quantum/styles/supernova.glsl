// Supernova — a star collapses and detonates; a Rayleigh-Taylor shock shell tears outward and cools into a remnant.
vec4 motif(vec2 uv, vec2 fc) {
  float ph = fract(u_p * safeCycles(float(p_cycles)) + 0.72);   // 0.0 = detonation (offset so the loop opens mid-remnant)
  vec2 q = uv / p_scale;
  float r = length(q);
  float a = atan(q.y, q.x);
  vec3 col = vec3(0.0);
  // progenitor: bright star that swells before collapse (ph near 1)
  float pre = smoothstep(0.55, 0.97, ph);
  float starR = mix(0.004, 0.02, pre);
  col += mix(u_ink, u_a1, 0.3) * exp(-r * r / (starR * starR)) * (0.6 + 1.6 * pre) * (1.0 - smoothstep(0.985, 1.0, ph));
  // shock radius (fast then slowing: Sedov-Taylor ~ t^0.4)
  float age = sat(ph / 0.9);
  float R = 0.62 * pow(age, 0.4) * p_size;
  float fade = 1.0 - smoothstep(0.55, 0.95, ph);
  // Rayleigh-Taylor fingers: noisy radius by angle (loop via ln2 on a circle in angle space)
  vec2 ac = vec2(cos(a), sin(a));
  float fing = lridge(ac * 2.2 * p_filaments + 3.0, 4, 1.0, 0.3);
  float rr = R * (1.0 - 0.18 * p_instability * fing);
  float shell = exp(-pow((r - rr) / (0.012 + 0.03 * age), 2.0));
  float limb = 1.0 / sqrt(max(1.0 - sat(r / max(rr, 1e-3)) * sat(r / max(rr, 1e-3)), 0.04));
  // filament texture inside the shell
  float fil = lfbm3(vec3(q * 7.0 * p_filaments, age * 2.0), 5, 1.0, 0.3);
  float inner = smoothstep(rr, rr * 0.2, r) * pow(sat(0.55 + fil), 2.0);
  float temp = 1.0 - age;
  vec3 hotC = mix(u_a0, u_ink, sat(temp * 1.5));
  vec3 coolC = mix(u_a2, u_a1, sat(fil + 0.5));
  vec3 ej = mix(coolC, hotC, sat(temp * 1.2));
  col += ej * inner * 1.3 * fade * p_ejecta;
  col += mix(u_a1, u_ink, sat(temp)) * shell * min(limb, 4.0) * 0.7 * fade;
  // detonation flash (limited under the photosensitive guard)
  float flash = exp(-ph * 60.0) + exp(-(1.0 - ph) * 400.0) * 0.0;
  col += mix(u_ink, u_a1, 0.2) * flashAmt(flash) * p_flash * (0.4 + 2.0 * exp(-r * 6.0));
  // light echoes: faint rings at larger radii
  for (int i = 1; i <= 3; i++) {
    float er = R * (1.4 + float(i) * 0.5);
    col += u_a2 * exp(-pow((r - er) * 60.0, 2.0)) * 0.12 * p_echoes * fade * (0.6 + 0.4 * lfbm(ac * 3.0 + float(i), 3, 1.0, 0.3));
  }
  // neutron star remnant
  col += u_a2 * exp(-r * r * 20000.0) * 2.0 * step(0.02, ph) * step(ph, 0.95);
  col += Q_stars2(uv, p_stars, 0.8) * 0.8;
  col = aces(col * 1.2);
  return vec4(col, max(max(col.r, col.g), col.b));
}

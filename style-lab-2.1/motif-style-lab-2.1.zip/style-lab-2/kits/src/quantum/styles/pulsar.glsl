// Pulsar — a spinning neutron star sweeps twin lighthouse beams through its magnetosphere and wind nebula.
vec4 motif(vec2 uv, vec2 fc) {
  vec2 q = uv / p_scale;
  float rot_ = TAU * u_p * floor(safeCycles(2.0 * float(p_spin)) * 0.5);
  float tilt = p_obliquity * 0.9;
  vec3 col = vec3(0.0);
  float r = length(q);
  // wind nebula: torus + jets with wisps
  vec2 tq = q / vec2(1.0, 0.35);
  float torus = exp(-pow((length(tq) - 0.22) * 9.0, 2.0)) * (0.6 + 0.4 * lfbm(tq * 6.0, 4, 1.0, 0.3));
  float wisp = pow(0.5 + 0.5 * sin(length(tq) * 60.0 - TAU * u_p * float(p_spin) * 2.0), 6.0) * exp(-length(tq) * 5.0);
  float jet = exp(-q.x * q.x * 900.0) * exp(-abs(q.y) * 4.0) * (0.6 + 0.4 * lfbm(vec2(q.y * 10.0, 0.0), 3, float(p_spin), 0.3));
  col += (u_a2 * torus + u_a0 * wisp * 0.4 + u_a1 * jet * 0.6) * p_nebula;
  // magnetic dipole field lines, rotating with the star (projected)
  vec2 mq = rot(tilt * sin(rot_)) * q;
  float mr = length(mq), mth = atan(mq.x, mq.y);
  float s2 = sin(mth); s2 *= s2;
  float L = mr / max(s2, 1e-3);             // dipole: r = L sin^2(theta)
  float lines = 0.0;
  for (int i = 1; i <= 6; i++) {
    float Li = 0.06 * float(i) * p_field;
    lines += exp(-pow((L - Li) / (0.004 * float(i)), 2.0)) * exp(-mr * 2.0);
  }
  col += u_a2 * lines * 0.5;
  // beams: two cones along the magnetic axis, axis precesses around the spin axis
  float bx = sin(tilt) * cos(rot_);           // projected beam axis component toward viewer
  vec2 bdir = normalize(vec2(sin(tilt) * sin(rot_), cos(tilt)));
  float face = abs(bx);                       // beam pointing at the viewer
  for (int b = 0; b < 2; b++) {
    vec2 d = b == 0 ? bdir : -bdir;
    float al = dot(q, d);
    float pe = abs(dot(q, vec2(-d.y, d.x)));
    float cone = exp(-pe * pe / pow(0.006 + al * 0.12 * p_beamWidth, 2.0)) * step(0.0, al) * exp(-al * 1.5);
    col += mix(u_a0, u_ink, 0.4) * cone * 1.5;
  }
  // pulse: flash when a beam crosses the line of sight (limited)
  float pulseA = pow(face, 40.0 * (1.0 - p_beamWidth * 0.5) + 4.0);
  col += mix(u_ink, u_a0, 0.3) * flashAmt(pulseA) * p_pulse * exp(-r * 4.0) * 1.5;
  // neutron star
  col += u_ink * (1.0 - smoothstep(0.012, 0.014, r)) + u_a0 * glow2(r, 0.02) * 0.8;
  col += Q_stars2(uv, p_stars, 0.5) * 0.7;
  col = aces(col * 1.1);
  return vec4(col, max(max(col.r, col.g), col.b));
}

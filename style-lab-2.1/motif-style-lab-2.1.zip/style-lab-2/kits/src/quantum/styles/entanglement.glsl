// Entanglement — pairs fly apart from a source bound by a shared thread; measure one and both states snap, always opposite.
vec3 EN_bloch(vec2 q, float R, vec3 s, vec3 c) {
  // simple Bloch sphere: outline, equator, state arrow
  float d = abs(length(q) - R);
  vec3 col = u_ink * line(d, 0.003) * 0.6;
  vec2 eq = q / vec2(1.0, 0.3);
  col += u_ink * line(abs(length(eq) - R), 0.003) * 0.25;
  vec2 tip = vec2(s.x, s.z * 0.95 + s.y * 0.3) * R;
  float da = sdSeg(q, vec2(0.0), tip);
  col += c * (line(da, 0.006) + exp(-length(q - tip) * length(q - tip) * 4000.0) * 1.5);
  return col;
}
vec4 motif(vec2 uv, vec2 fc) {
  vec2 A = M_asp() * 0.5;
  float D = A.x * 0.72;              // detector distance
  vec3 col = vec3(0.0);
  int NP = p_pairs;
  float lastMeasure = -1.0; float outcome = 0.0; float measT = 1.0;
  for (int i = 0; i < 8; i++) {
    if (i >= NP) break;
    float fi = float(i);
    float t = fract(u_p * float(p_rate) + fi / float(NP));
    float x = t * D * 1.15;
    float yOff = (h11(fi + 3.0) - 0.5) * 0.25 * p_spread;
    vec2 pa = vec2(x, yOff * t), pb = vec2(-x, -yOff * t);
    float measured = step(D, x);
    float res = step(0.5, h11(fi * 7.0 + mod(floor(u_p * float(p_rate) + fi / float(NP)), float(p_rate)) * 13.0));
    // superposed spin: fuzzy, rotating; after measurement: definite and opposite
    float spin = TAU * (u_p * float(p_rate) * 3.0 + fi * 0.37);
    vec3 cA = measured > 0.5 ? (res > 0.5 ? u_a0 : u_a1) : mix(u_a0, u_a1, 0.5 + 0.5 * sin(spin));
    vec3 cB = measured > 0.5 ? (res > 0.5 ? u_a1 : u_a0) : mix(u_a1, u_a0, 0.5 + 0.5 * sin(spin));
    float fadeOut = 1.0 - smoothstep(0.92, 1.0, t);
    for (int s = 0; s < 2; s++) {
      vec2 pp = s == 0 ? pa : pb;
      float d = length(uv - pp);
      float r = 0.012 * p_size;
      float halo = measured > 0.5 ? 0.0 : (0.5 + 0.5 * sin(spin * 2.0)) * p_superposition;
      col += (s == 0 ? cA : cB) * ((1.0 - smoothstep(r, r + aa(), d)) * 1.2 + glow2(d, r * (1.5 + 2.0 * halo)) * 0.35 * p_glow) * fadeOut;
    }
    // entanglement thread: a standing wave strung between the pair
    if (measured < 0.5) {
      vec2 ab = pa - pb; float L = length(ab); vec2 dir = ab / max(L, 1e-4), nn = vec2(-dir.y, dir.x);
      float s = dot(uv - pb, dir), n = dot(uv - pb, nn);
      if (s > 0.0 && s < L) {
        float wave = sin(s / max(L, 1e-3) * PI * float(p_threadModes)) * 0.02 * p_thread * sin(spin);
        float dd = abs(n - wave);
        col += mix(u_a2, u_ink, 0.3) * (line(dd, 0.002) * 0.7 + glow2(dd, 0.006) * 0.15) * p_thread;
      }
    } else if (t > lastMeasure) { lastMeasure = t; outcome = res; measT = (x - D) / (D * 0.15); }
  }
  // detectors + Bloch spheres showing the most recent correlated outcome
  for (int s = 0; s < 2; s++) {
    float sg = s == 0 ? 1.0 : -1.0;
    vec2 dp = vec2(sg * D, 0.0);
    float det = sdBox(uv - dp, vec2(0.006, A.y * 0.55));
    col += u_ink * 0.35 * (1.0 - smoothstep(0.0, aa(), det));
    vec2 bq = uv - vec2(sg * (D + A.x * 0.13), -A.y * 0.55);
    float up = lastMeasure >= 0.0 ? (s == 0 ? outcome : 1.0 - outcome) : 0.5;
    vec3 st = normalize(vec3(0.0, 0.0, up > 0.5 ? 1.0 : -1.0) + vec3(0.001));
    col += EN_bloch(bq, 0.07, st, up > 0.5 ? u_a0 : u_a1) * p_bloch;
  }
  // source
  col += u_ink * exp(-dot(uv, uv) * 3000.0) * 1.5 + u_a2 * glow2(length(uv), 0.03) * 0.3;
  col = aces(col * 1.1);
  return vec4(col, max(max(col.r, col.g), col.b));
}

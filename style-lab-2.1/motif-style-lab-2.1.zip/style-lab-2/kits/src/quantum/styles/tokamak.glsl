// Tokamak — a burning plasma torus confined by twisted field lines; D-shaped coils ring it as edge bursts flicker.
float TK_torus(vec3 p, float R, float r) { vec2 q = vec2(length(p.xz) - R, p.y / 1.3); return length(q) - r; }
vec4 motif(vec2 uv, vec2 fc) {
  float ang = 0.35 + p_orbit * 0.4 * lsin(1.0, 0.0);
  vec3 ro = vec3(sin(ang) * 3.0, 1.1 + 0.9 * p_elevation, cos(ang) * 3.0);
  vec3 fw = normalize(vec3(0.0, -0.1, 0.0) - ro), rt = normalize(cross(vec3(0.0, 1.0, 0.0), fw)), up = cross(fw, rt);
  vec3 rd = normalize(fw * 2.0 + uv.x * rt + uv.y * up);
  float R = 0.7, rp = 0.24;
  vec3 col = vec3(0.0); float trans = 1.0;
  float t = 0.4;
  float spin = TAU * u_p * float(p_flow);
  int steps = 40 + int(60.0 * p_quality);
  for (int i = 0; i < 100; i++) {
    if (i >= steps) break;
    vec3 p = ro + rd * t;
    float dt = TK_torus(p, R, rp);
    // coils (D-shaped rings at fixed toroidal angles) as solid occluders
    float phi = atan(p.z, p.x);
    float nc = max(float(p_coils), 1.0);
    float cphi = (floor(phi / TAU * nc + 0.5)) * TAU / nc;
    vec3 cp = vec3(cos(cphi), 0.0, sin(cphi));
    vec3 lp = vec3(dot(p, cp) - R, p.y, dot(p, vec3(-cp.z, 0.0, cp.x)));
    float coil = length(vec2(length(lp.xy / vec2(1.0, 1.35)) - rp * 1.75, lp.z)) - 0.009 + (p_coils == 0 ? 1e3 : 0.0);
    if (coil < 0.002) {
      vec3 n = normalize(vec3(lp.x, lp.y, 0.0) + 1e-4);
      float lit = 0.3 + 0.7 * sat(dot(n, normalize(-lp + vec3(0.0, 0.0, 0.0) - vec3(0.0, 0.3, 0.0))));
      col += (u_bg * 2.0 + u_ink * 0.12 * lit) * trans * p_coilLight + u_a0 * 0.15 * trans * p_coilLight;
      trans = 0.0; break;
    }
    if (dt < 0.0) {
      // plasma: dense core, twisted field lines (safety factor q), turbulence
      vec2 pq = vec2(length(p.xz) - R, p.y / 1.3);
      float rr = length(pq) / rp;
      float th = atan(pq.y, pq.x);
      float qf = 1.0 + 3.0 * p_twist;
      float lines = pow(0.5 + 0.5 * sin(float(p_fieldLines) * (th - phi * qf) + spin * 3.0), 8.0);
      float core = exp(-rr * rr * 2.2);
      float turb = 0.6 + 0.4 * ln3(p * 4.0, float(p_flow), 0.4);
      float elm = pow(sat(sin(phi * 5.0 + th * 2.0 - spin * 4.0)), 20.0) * p_bursts * smoothstep(0.6, 1.0, rr);
      vec3 em = mix(u_a1, u_a0, core) * (0.25 + core * 1.4) * turb + mix(u_a0, u_ink, 0.3) * lines * (0.3 + 0.7 * (1.0 - rr)) * 0.8 + u_ink * elm * 1.4;
      float dens = (0.15 + core * 0.6 + lines * 0.25 + elm * 0.4) * p_density;
      col += em * dens * 0.07 * trans;
      trans *= 1.0 - dens * 0.035;
      t += 0.012;
    } else {
      t += max(min(dt, coil) * 0.8, 0.01);
    }
    if (t > 7.0 || trans < 0.02) break;
  }
  // vessel wall glow
  col += u_a0 * 0.03 * (1.0 - trans) * p_glow;
  col = aces(col * 1.4 * p_glow);
  return vec4(col, max(max(col.r, col.g), col.b));
}

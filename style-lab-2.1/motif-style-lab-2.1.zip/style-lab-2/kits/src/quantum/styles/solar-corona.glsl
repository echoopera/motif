// Solar Corona — a limb-darkened star boils with granulation while magnetic loops, prominences and streamers flow above it.
vec4 motif(vec2 uv, vec2 fc) {
  float R = 0.3 * p_size;
  vec2 c = vec2(p_offset * 0.3, -0.05);
  vec2 q = uv - c;
  float r = length(q);
  float a = atan(q.y, q.x);
  vec3 col = vec3(0.0);
  // corona streamers (radial)
  float str = pow(0.5 + 0.5 * lfbm(vec2(a * 3.0, 0.0) * 1.0 + 3.0, 4, 1.0, 0.3), 3.0);
  float corona = exp(-(r - R) * 5.0 / p_corona) * step(R, r) * (0.3 + str * 1.6);
  col += mix(u_a0, u_ink, 0.2) * corona * 0.5;
  // disc: granulation + limb darkening + sunspots
  if (r < R) {
    float mu = sqrt(1.0 - (r / R) * (r / R));
    vec2 sp = q / R;
    vec3 sph = vec3(sp, mu);
    sph.xz = rot(TAU * u_p * float(p_rotation) * 0.25) * sph.xz;
    vec2 tq = vec2(atan(sph.x, sph.z), sph.y);
    vec3 v = lvoro(tq * 16.0 * p_granulation, 0.9, float(p_boil), 0.25);
    float gran = 0.75 + 0.25 * smoothstep(0.0, 0.25, v.y - v.x) - 0.15 * v.x;
    float spots = smoothstep(0.55, 0.62, lfbm(tq * 2.0, 3, 1.0, 0.1)) * p_spots;
    float limb = pow(mu, 0.55);
    vec3 disc = mix(u_a0, mix(u_a1, u_ink, 0.5), limb) * limb * gran * (1.0 - 0.85 * spots) * 1.3;
    col = disc;
  }
  // coronal loops: magnetic arcs anchored on the limb, plasma flowing along them
  for (int i = 0; i < 8; i++) {
    if (i >= p_loops) break;
    float fi = float(i);
    vec3 h = h33(vec3(fi, 4.0, 2.0));
    float ang0 = (h.x - 0.5) * 2.2 + PI * 0.5 * (h.z < 0.5 ? 1.0 : -0.6) ;
    float span = 0.15 + 0.25 * h.y;
    vec2 f1 = c + vec2(cos(ang0 - span), sin(ang0 - span)) * R;
    vec2 f2 = c + vec2(cos(ang0 + span), sin(ang0 + span)) * R;
    vec2 mid = (f1 + f2) * 0.5;
    vec2 out_ = normalize(mid - c);
    float height = (0.08 + 0.18 * h.z) * p_loopHeight * (1.0 + 0.1 * lsin(1.0, h.x));
    // loop as an ellipse arc: parametrise by the chord coordinate
    vec2 chord = f2 - f1; float cl = length(chord); vec2 cd = chord / cl;
    vec2 lq = q + c - mid;
    float x = dot(lq, cd) / (cl * 0.5);
    float y = dot(lq, out_);
    float yArc = height * sqrt(max(1.0 - x * x, 0.0));
    float d = abs(y - yArc) * step(abs(x), 1.0) + step(1.0, abs(x)) * 1.0;
    float s = acos(clamp(x, -1.0, 1.0)) / PI;
    float flow = pulse(s, float(p_flow), h.y, 0.08) * 0.8 + 0.4;
    float above = step(R * 0.98, r);
    float lw = 0.004 * (0.6 + h.y);
    col += mix(u_a1, u_ink, flow * 0.4) * (line(d, lw) * flow * 1.2 + glow2(d, lw * 3.0) * 0.18 * p_glow) * above;
  }
  // prominence: a curtain of plasma on one limb
  float pa = PI * 0.12;
  vec2 pc = c + vec2(cos(pa), sin(pa)) * R;
  vec2 pq = rot(-pa) * (uv - pc);
  float prom = smoothstep(0.0, 0.01, pq.x) * exp(-pq.x * 14.0 / p_prominence) * exp(-pq.y * pq.y * 60.0) * pow(sat(lfbm(pq * vec2(8.0, 20.0), 5, 1.0, 0.3) + 0.5), 2.0);
  col += mix(u_a1, u_a0, 0.3) * prom * 1.6 * p_prominence;
  col = aces(col * 1.1);
  return vec4(col, max(max(col.r, col.g), col.b));
}

// Gravitational Wave — two black holes spiral in and merge; the chirp ripples outward across a spacetime grid.
vec4 motif(vec2 uv, vec2 fc) {
  float ncyc = safeCycles(float(p_cycles)); float cyc = ncyc < 1.0 ? 0.45 : fract(u_p * ncyc);
  // inspiral: separation shrinks, orbital phase accelerates (chirp), merger at tm
  float tm = 0.72;
  float tau = max(tm - cyc, 0.0) / tm;           // 1 -> 0
  float sep = 0.16 * p_separation * pow(tau, 0.25);
  float orb = -18.0 * pow(tau, 0.625) * p_chirp;   // orbital phase
  float merged = step(tm, cyc);
  float fadeIn = smoothstep(0.0, 0.08, cyc), fadeOut = 1.0 - smoothstep(0.9, 1.0, cyc);
  // camera tilt: project the plane
  float tilt = 0.25 + 0.6 * p_tilt;
  vec2 w = vec2(uv.x, uv.y / tilt);
  float r = length(w);
  float phi = atan(w.y, w.x);
  // retarded time: wave at radius r was emitted at cyc - r / c
  float c = 0.9 * p_speed;
  float tr = cyc - r / c;
  tr = tr < 0.0 ? tr + 1.0 : tr;
  float taur = sat(max(tm - tr, 0.0) / tm);
  float orbr = -18.0 * pow(taur, 0.625) * p_chirp;
  float ampEmit = tr < tm ? pow(1.0 - taur, 1.5) : exp(-(tr - tm) * 30.0);   // grows toward merger, ringdown after
  float ringF = tr >= tm ? sin((tr - tm) * 180.0) : 1.0;
  float h = ampEmit * (tr < tm ? cos(2.0 * (phi - orbr)) : ringF * cos(2.0 * phi)) / (1.0 + r * 6.0);
  h *= p_amplitude;
  // gravity wells
  vec2 b1 = vec2(cos(orb), sin(orb)) * sep, b2 = -b1;
  float m = merged > 0.5 ? 0.0 : 1.0;
  float well = (m * (0.012 / (length(w - b1) + 0.03) + 0.012 / (length(w - b2) + 0.03)) + (1.0 - m) * 0.024 / (r + 0.035)) * p_well * fadeIn * fadeOut;
  // displaced grid
  float N = 8.0 * p_gridDensity;
  vec2 g = w * N + vec2(0.0, (h * 0.8 - well * 3.0) * N);
  vec2 gf = abs(fract(g) - 0.5) / N;
  float lw = 0.0012;
  float grid = max(line(gf.x * tilt, lw), line(gf.y * tilt, lw));
  float fog = exp(-r * 1.2);
  vec3 col = mix(u_a0 * 0.45, mix(u_a0, u_a1, step(0.0, h)) * 1.4, sat(abs(h) * 6.0)) * grid * (0.25 + 0.75 * fog);
  col += mix(u_a0, u_a1, step(0.0, h)) * abs(h) * 0.9 * p_strain * fog;
  // black holes: shadows with lensing rings
  for (int i = 0; i < 2; i++) {
    if (merged > 0.5 && i == 1) break;
    vec2 bp = merged > 0.5 ? vec2(0.0) : (i == 0 ? b1 : b2);
    float rb = merged > 0.5 ? 0.028 : 0.02;
    float d = length(w - bp);
    col = mix(col, u_bg * 0.0, (1.0 - smoothstep(rb * 0.9, rb, d)) * fadeIn * fadeOut);
    col += mix(u_a1, u_ink, 0.5) * exp(-pow((d - rb * 1.35) * 90.0, 2.0)) * fadeIn * fadeOut * 1.2;
  }
  // merger flash (limited)
  float fl = exp(-max(cyc - tm, 0.0) * 40.0) * step(tm, cyc);
  col += mix(u_ink, u_a1, 0.3) * flashAmt(fl) * p_flash * exp(-r * 5.0) * 1.5;
  col = aces(col * 1.1);
  return vec4(col, max(max(col.r, col.g), col.b));
}

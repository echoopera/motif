// Double Slit — wavefronts pass two slits and interfere; single particles land one by one and the fringes build.
float DS_I(float y, float d, float w, float k, bool which) {
  float beta = k * w * y * 0.5; float env = beta == 0.0 ? 1.0 : pow(sin(beta) / beta, 2.0);
  float fr = which ? 0.5 : pow(cos(k * d * y * 0.5), 2.0);
  return env * fr;
}
vec4 motif(vec2 uv, vec2 fc) {
  vec2 A = M_asp() * 0.5;
  float bx = -A.x * 0.15;              // barrier x
  float sx = A.x * 0.72;               // screen x
  float d = 0.12 * p_separation, w = 0.02 * p_slitWidth;
  float k = 90.0 / p_wavelength;
  vec3 col = vec3(0.0); float cover = 0.0;
  float cyc = fract(u_p * float(p_cycles));
  bool which = p_detector;
  // source waves (left of the barrier): plane waves moving right
  if (uv.x < bx) {
    float ph = uv.x * k * 0.35 - TAU * u_p * float(p_waveSpeed) * 4.0;
    float wv = 0.5 + 0.5 * cos(ph);
    col += u_a2 * wv * 0.35 * p_waves * smoothstep(-A.x, bx, uv.x);
  } else if (uv.x < sx) {
    // two-source interference
    vec2 s1 = vec2(bx, d * 0.5), s2 = vec2(bx, -d * 0.5);
    float r1 = length(uv - s1), r2 = length(uv - s2);
    float ph = -TAU * u_p * float(p_waveSpeed) * 4.0;
    vec2 a1 = vec2(cos(r1 * k * 0.35 + ph), sin(r1 * k * 0.35 + ph)) / sqrt(r1 + 0.02);
    vec2 a2 = vec2(cos(r2 * k * 0.35 + ph), sin(r2 * k * 0.35 + ph)) / sqrt(r2 + 0.02);
    vec2 a = which ? a1 : a1 + a2;
    float I = which ? (dot(a1, a1) + dot(a2, a2)) * 0.5 : dot(a, a) * 0.25;
    float crest = which ? max(0.5 + 0.5 * a1.x * sqrt(r1 + 0.02), 0.5 + 0.5 * a2.x * sqrt(r2 + 0.02)) : 0.5 + 0.5 * a.x * 0.5 * sqrt(min(r1, r2) + 0.02);
    col += mix(u_a2, u_a0, sat(I * 0.8)) * (I * 0.12 + crest * 0.25) * p_waves;
  }
  // barrier with slits
  float bar = step(abs(uv.x - bx), 0.006) * (1.0 - step(abs(abs(uv.y) - d * 0.5), w * 0.5));
  col = mix(col, u_ink * 0.7, bar); cover = max(cover, bar);
  // screen + accumulated hits
  float scr = step(abs(uv.x - sx), 0.004);
  col = mix(col, u_ink * 0.25, scr);
  float hits = 0.0;
  if (uv.x > sx - 0.04) {
    float count = floor(pow(smoothstep(0.02, 0.85, cyc), 1.3) * 900.0 * p_rate);
    float fade = 1.0 - smoothstep(0.9, 1.0, cyc);
    // hits live on a vertical strip right of the screen; test candidates in this pixel's row band
    float band = floor((uv.y + A.y) / (2.0 * A.y) * 90.0);
    for (int i = 0; i < 24; i++) {
      float id = band * 24.0 + float(i);
      vec3 h = h33(vec3(id, 5.0, 2.0));
      float order = h.z * 900.0;
      if (order > count) continue;
      float y = (band + h.x) / 90.0 * 2.0 * A.y - A.y;
      // acceptance by the interference distribution (rejection sampling)
      if (h.y > DS_I(y / (sx - bx) * 0.6, d, w, k, which)) continue;
      vec2 hp = vec2(sx + 0.01 + h.x * 0.06 * p_spread, y);
      float dd = length(uv - hp);
      float age = sat((count - order) / 40.0);
      hits += (1.0 - smoothstep(0.0025, 0.0025 + aa(), dd)) * fade + glow2(dd, 0.004) * (1.0 - age) * 0.6 * fade;
    }
  }
  col += mix(u_a1, u_ink, 0.3) * hits * 1.3;
  cover = max(cover, sat(hits));
  // expected distribution curve on the screen
  float I = DS_I(uv.y / (sx - bx) * 0.6, d, w, k, which);
  col += u_a0 * line(abs(uv.x - (sx - 0.02 - I * 0.12)), 0.002) * p_curve * step(uv.x, sx);
  col = aces(col * 1.2);
  return vec4(col, max(cover, max(max(col.r, col.g), col.b)));
}

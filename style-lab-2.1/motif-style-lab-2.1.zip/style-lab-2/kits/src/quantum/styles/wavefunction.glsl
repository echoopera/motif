// Wavefunction — a 2D quantum harmonic oscillator: superposed eigenstates slosh through the well; density as light, phase as colour.
float WF_herm(int n, float x) {
  float h0 = 1.0, h1 = 2.0 * x;
  if (n == 0) return h0;
  float hn = h1;
  for (int k = 1; k < 8; k++) { if (k >= n) break; float h2 = 2.0 * x * h1 - 2.0 * float(k) * h0; h0 = h1; h1 = h2; hn = h2; }
  return hn;
}
float WF_phi(int n, float x) {
  float f = 1.0; for (int k = 2; k < 9; k++) { if (k > n) break; f *= float(k); }
  float norm = 1.0 / sqrt(pow(2.0, float(n)) * f) * 0.7511;
  return norm * WF_herm(n, x) * exp(-0.5 * x * x);
}
vec4 motif(vec2 uv, vec2 fc) {
  vec2 x = uv / (0.09 * p_width);
  vec2 psi = vec2(0.0);   // complex amplitude
  int S = p_states;
  for (int i = 0; i < 8; i++) {
    if (i >= S) break;
    vec3 h = h33(vec3(float(i), 3.0, 1.0));
    int nx = int(h.x * float(p_excitation + 1)), ny = int(h.y * float(p_excitation + 1));
    float amp = 1.0 / sqrt(float(S)) * (0.6 + 0.8 * h.z);
    float E = float(nx + ny + 1);
    float ph = -E * TAU * u_p * float(p_speed) + h.z * TAU;
    float v = WF_phi(nx, x.x) * WF_phi(ny, x.y) * amp;
    psi += v * vec2(cos(ph), sin(ph));
  }
  float rho = dot(psi, psi);
  float arg = atan(psi.y, psi.x) / TAU + 0.5;
  float I = 1.0 - exp(-rho * 40.0 * p_contrast);
  // phase colour cycles through the three accents
  vec3 pc = arg < 1.0 / 3.0 ? mix(u_a0, u_a1, arg * 3.0) : arg < 2.0 / 3.0 ? mix(u_a1, u_a2, arg * 3.0 - 1.0) : mix(u_a2, u_a0, arg * 3.0 - 2.0);
  vec3 col;
  if (p_view == VIEW_DENSITY) col = mix(u_a2 * 0.3, mix(u_a0, u_ink, I), I) * I;
  else if (p_view == VIEW_REAL) { float re = psi.x * 8.0 * p_contrast; col = (re > 0.0 ? u_a0 : u_a1) * sat(abs(re)); }
  else col = pc * I * 1.3 + u_ink * pow(I, 6.0) * 0.4;
  // contours of |psi|^2
  if (p_contours > 0.0) {
    float c = fract(rho * 60.0 * p_contrast);
    float wline = fwidth(rho * 60.0 * p_contrast);
    col += u_ink * p_contours * 0.5 * (1.0 - smoothstep(0.0, wline * 1.5, min(c, 1.0 - c))) * sat(rho * 30.0);
  }
  // potential well rings
  if (p_grid) { float pr = length(uv) / (0.09 * p_width); float gr = abs(fract(pr * 0.5) - 0.5); col += u_ink * 0.07 * (1.0 - smoothstep(0.0, 0.03, gr)) * exp(-pr * 0.12); }
  return vec4(col, max(max(col.r, col.g), col.b));
}

// Event Horizon (pass 1) — photon paths bent around a black hole; accretion disk with Doppler beaming, lensed starfield.
vec4 motif(vec2 uv, vec2 fc) {
  float incl = mix(0.04, 0.55, p_tilt);
  float orbit = 0.25 * lsin(1.0, 0.0) * 0.3;
  vec3 ro = vec3(sin(orbit) * 22.0, 22.0 * sin(incl), -22.0 * cos(incl) * cos(orbit));
  vec3 fw = normalize(-ro), rt = normalize(cross(vec3(0.0, 1.0, 0.0), fw)), up = cross(fw, rt);
  vec3 rd = normalize(fw * 2.4 * p_fov + uv.x * rt + uv.y * up);
  vec3 pos = ro, vel = rd;
  float rs = 1.0;                         // Schwarzschild radius
  float rin = 3.0 * rs * p_innerEdge, rout = rin + 6.0 * p_diskSize;
  vec3 col = vec3(0.0); float trans = 1.0; float captured = 0.0; float ringGlow = 0.0;
  float dt = 0.16;
  int steps = 60 + int(100.0 * p_quality);
  for (int i = 0; i < 160; i++) {
    if (i >= steps) break;
    float r = length(pos);
    if (r < rs) { captured = 1.0; break; }
    if (r > 40.0 && dot(pos, vel) > 0.0) break;
    // null geodesic in Schwarzschild, Binet-style acceleration: a = -1.5 rs h^2 / r^5 * pos
    vec3 hv = cross(pos, vel); float h2 = dot(hv, hv);
    vec3 acc = -1.5 * rs * h2 * pos / pow(r, 5.0) * p_lensing;
    float stepLen = dt * clamp(r * 0.4, 0.08, 3.0);
    vec3 np = pos + vel * stepLen; vel = normalize(vel + acc * stepLen);
    ringGlow += exp(-pow((r - 1.5 * rs) * 6.0, 2.0)) * stepLen * 0.25;
    // disk crossing (y = 0 plane)
    if (pos.y * np.y < 0.0) {
      float t = pos.y / (pos.y - np.y);
      vec3 hp = mix(pos, np, t);
      float rr = length(hp.xz);
      if (rr > rin && rr < rout) {
        float ang = atan(hp.z, hp.x);
        float x = (rr - rin) / (rout - rin);
        // spiral inflow arms rotating rigidly + loop turbulence
        float arms = 0.5 + 0.5 * sin(ang * 3.0 + log(rr) * 9.0 * p_spiral - TAU * u_p * float(p_rotation) * 3.0);
        float turb = lfbm(vec2(ang * 3.0 / TAU * 8.0, log(rr) * 6.0), 4, float(p_rotation), 0.35) * 0.5 + 0.5;
        float dens = pow(1.0 - x, 1.2) * smoothstep(0.0, 0.04, x) * mix(1.0, turb * 1.6, p_turbulence) * mix(1.0, 0.55 + arms, 0.6 * p_turbulence);
        // Doppler beaming: disk rotates, approaching side brighter
        vec3 v = normalize(vec3(-hp.z, 0.0, hp.x)) * sqrt(0.5 * rs / rr);
        float beam = pow(sat(1.0 + dot(v, -normalize(vel)) * 2.2 * p_doppler), 3.0);
        float temp = pow(rin / rr, 0.75);
        vec3 c = Q_heat(temp * 0.9 + 0.1 * turb) * dens * beam * 0.9 * p_brightness;
        col += c * trans;
        trans *= 1.0 - sat(dens * 0.5);
      }
    }
    pos = np;
    if (trans < 0.02) break;
  }
  if (captured < 0.5) col += Q_stars(normalize(vel), p_stars) * trans * 1.2;
  col += (u_a1 * 0.35 + u_ink * 0.15) * ringGlow * p_photonRing * trans * (1.0 - 0.85 * captured);
  return vec4(col, 1.0);
}

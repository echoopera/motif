// Nebula Genesis — a volumetric stellar nursery: emission gas, dark pillars and newborn stars under a drifting camera.
vec4 motif(vec2 uv, vec2 fc) {
  vec2 cam = 0.08 * p_drift * lc(1.0, 0.0);
  vec3 col = vec3(0.0); float trans = 1.0;
  int L = 6 + int(10.0 * p_quality);
  for (int i = 0; i < 16; i++) {
    if (i >= L) break;
    float z = float(i) / float(L);               // 0 = near, 1 = far
    float par = mix(1.0, 0.25, z);
    vec2 q = (uv + cam * par) * p_scale * mix(1.6, 0.9, z) + float(i) * 1.37;
    float n = lfbm(q * 1.3, 5, 1.0, 0.18 + 0.1 * p_turbulence);
    float w = lfbm(q * 0.6 + 7.0, 3, 1.0, 0.2);
    float dens = smoothstep(0.0, 0.6, n + w * 0.6 + p_density - 0.55);
    // pillars: dark, dense columns rising from the bottom in the near layers
    float pil = smoothstep(0.15, 0.55, -uv.y * 0.9 + 0.35 * lfbm(vec2(q.x * 2.0, q.y * 0.4), 4, 1.0, 0.15)) * smoothstep(0.55, 0.9, 0.5 + 0.5 * sin(q.x * 3.0 + w * 3.0)) * p_pillars * (1.0 - z);
    // emission: H-alpha (a0) vs OIII (a2) by ionisation (distance from the hot core)
    float ion = sat(1.0 - length(uv - vec2(0.15, 0.12)) * 1.4 + n * 0.3);
    vec3 em = mix(u_a0, u_a2, ion * p_ionisation) * dens * (0.35 + 0.65 * sat(n + 0.4)) * 0.22 * p_glow;
    col += em * trans;
    trans *= 1.0 - sat(dens * 0.12 * p_dust + pil * 0.6);
    // rim lighting on pillars
    col += mix(u_a1, u_ink, 0.4) * pil * (1.0 - pil) * 1.2 * trans * ion;
  }
  // newborn stars (embedded, with spikes)
  vec3 st = Q_stars2(uv + cam * 0.5, p_stars, p_spikes) * 1.4;
  col += st * (0.3 + 0.7 * trans);
  // the central cluster
  float dc = length(uv - vec2(0.15, 0.12));
  col += mix(u_ink, u_a2, 0.3) * exp(-dc * 30.0) * 0.8 * p_glow;
  col = aces(col * 1.3);
  return vec4(col, max(max(col.r, col.g), col.b));
}

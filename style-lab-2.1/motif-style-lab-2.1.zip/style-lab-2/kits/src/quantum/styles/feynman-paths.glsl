// Feynman Paths — every path from source to detector at once: phases swirl, and the classical path emerges where they agree.
vec4 motif(vec2 uv, vec2 fc) {
  vec2 A = M_asp() * 0.5;
  vec2 a = vec2(-A.x * 0.8, 0.0), b = vec2(A.x * 0.8, 0.0);
  float L = b.x - a.x;
  float s = (uv.x - a.x) / L;
  vec3 col = vec3(0.0); float cover = 0.0;
  vec2 sumA = vec2(0.0);
  float omega = TAU * u_p * float(p_speed);
  if (s > 0.0 && s < 1.0) {
    for (int i = 0; i < 64; i++) {
      if (i >= p_paths) break;
      float fi = float(i);
      // path = classical straight line + Fourier modes with fixed endpoints
      float y = 0.0, dy = 0.0, action = 0.0;
      float spread = p_spread * (0.3 + 1.2 * pow(h11(fi + 1.0), 2.0));
      for (int k = 1; k <= 5; k++) {
        if (k > p_modes) break;
        float fk = float(k);
        float ak = (h11(fi * 7.0 + fk) - 0.5) * 0.35 * spread / fk * (1.0 + 0.15 * lsin(1.0, h11(fi + fk * 3.0)));
        y += ak * sin(PI * fk * s);
        dy += ak * PI * fk * cos(PI * fk * s) / L;
        action += ak * ak * fk * fk;
      }
      float phase = action * 60.0 * p_hbar - omega;
      vec3 c = mix(mix(u_a0, u_a1, 0.5 + 0.5 * cos(phase)), u_a2, 0.5 + 0.5 * sin(phase) * 0.5);
      float d = abs(uv.y - y) / sqrt(1.0 + dy * dy);
      float wgt = 1.0 / float(p_paths) * 30.0;
      float coherence = exp(-action * 20.0 * p_hbar);
      col += c * (line(d, 0.0018 * p_lineWidth) * (0.25 + 0.75 * coherence) + glow2(d, 0.004) * 0.05 * p_glow) * wgt * 0.3;
      cover = max(cover, line(d, 0.0018) * 0.5);
    }
  }
  // the classical path emerges (stationary action)
  float dcl = abs(uv.y);
  col += mix(u_ink, u_a2, 0.3) * line(dcl, 0.003) * p_classical * step(0.0, s) * step(s, 1.0) + u_a2 * glow2(dcl, 0.01) * 0.2 * p_classical * step(0.0, s) * step(s, 1.0);
  // phasor sum: arrows chained head to tail at the bottom (Feynman's little arrows)
  vec2 o = vec2(-A.x * 0.55, -A.y * 0.72);
  vec2 cur = o; float arrows = 0.0;
  for (int i = 0; i < 24; i++) {
    if (i >= p_paths) break;
    float fi = float(i); float action = 0.0;
    float spread = p_spread * (0.3 + 1.2 * pow(h11(fi + 1.0), 2.0));
    for (int k = 1; k <= 5; k++) { if (k > p_modes) break; float fk = float(k); float ak = (h11(fi * 7.0 + fk) - 0.5) * 0.35 * spread / fk * (1.0 + 0.15 * lsin(1.0, h11(fi + fk * 3.0))); action += ak * ak * fk * fk; }
    float phase = action * 60.0 * p_hbar - omega;
    vec2 nx = cur + vec2(cos(phase), sin(phase)) * 0.028 * p_arrows;
    arrows += line(sdSeg(uv, cur, nx), 0.0025);
    cur = nx;
  }
  col += u_a1 * arrows * 0.9 * step(0.001, p_arrows);
  col += u_ink * line(sdSeg(uv, o, cur), 0.003) * step(0.001, p_arrows);
  // source + detector
  col += u_ink * (exp(-dot(uv - a, uv - a) * 4000.0) + exp(-dot(uv - b, uv - b) * 4000.0)) * 1.5;
  col = aces(col * 1.2);
  return vec4(col, max(cover, max(max(col.r, col.g), col.b)));
}

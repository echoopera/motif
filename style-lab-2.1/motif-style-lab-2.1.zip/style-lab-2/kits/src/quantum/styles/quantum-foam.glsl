// Quantum Foam — spacetime froth at the Planck scale: bubbles form and pop while virtual pairs flicker into existence.
vec4 motif(vec2 uv, vec2 fc) {
  vec2 p = uv * 7.0 * p_scale;
  // curvature noise warps the metric
  vec2 wq = p + p_curvature * 0.9 * vec2(lfbm(p * 0.35, 4, float(p_speed), 0.3), lfbm(p * 0.35 + 5.0, 4, float(p_speed), 0.3));
  vec3 v = lvoro(wq, 1.0, float(p_speed), 0.4);
  float edge = v.y - v.x;
  // each bubble has its own life cycle (loop-periodic): grow, shimmer, pop
  float life = fract(u_p * float(p_speed) + v.z * 7.0);
  float alive = smoothstep(0.0, 0.25, life) * (1.0 - smoothstep(0.8, 0.95, life));
  float popped = smoothstep(0.85, 1.0, life);
  // thin-film interference on the bubble wall
  float film = edge * 18.0 + v.z * 5.0 + life * 3.0;
  vec3 irid = 0.5 + 0.5 * cos(TAU * (vec3(0.0, 0.33, 0.67) + film * 0.15 * p_iridescence));
  vec3 filmC = u_a0 * irid.x + u_a1 * irid.y + u_a2 * irid.z;
  float wall = (1.0 - smoothstep(0.02 * p_wall, 0.02 * p_wall + 0.06, edge)) * alive;
  vec3 col = filmC * wall * 1.1 + u_ink * pow(wall, 6.0) * 0.4;
  // interior sheen
  col += filmC * 0.08 * (1.0 - v.x) * alive;
  // pop burst
  col += u_ink * exp(-v.x * 10.0) * popped * (1.0 - popped) * 4.0 * p_pops;
  // virtual particle pairs: appear, separate, annihilate (per cell of a finer grid)
  vec2 g = uv * 16.0 * p_pairDensity;
  vec2 n = floor(g);
  float pairs = 0.0;
  for (int j = -1; j <= 1; j++) for (int i = -1; i <= 1; i++) {
    vec2 c = n + vec2(float(i), float(j));
    vec3 h = h33(vec3(c, 9.0));
    if (h.z > p_pairs) continue;
    float t = fract(u_p * float(p_speed) * 2.0 + h.x);
    float sepa = sin(PI * t) * 0.35;
    vec2 dir = vec2(cos(TAU * h.y), sin(TAU * h.y));
    vec2 ctr = c + 0.5 + (h.xy - 0.5) * 0.5;
    vec2 e1 = ctr + dir * sepa, e2 = ctr - dir * sepa;
    float d1 = length(g - e1), d2 = length(g - e2);
    float br = sin(PI * t);
    pairs += (exp(-d1 * d1 * 80.0) + exp(-d2 * d2 * 80.0)) * br;
    // annihilation spark at the end of the life
    pairs += exp(-length(g - ctr) * 18.0) * smoothstep(0.9, 1.0, t) * 2.0;
  }
  col += mix(u_a1, u_ink, 0.3) * pairs * p_glow;
  col = aces(col * 1.1);
  return vec4(col, max(max(col.r, col.g), col.b));
}

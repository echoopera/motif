// Shared post pass: upsample pass 1, add a wide bloom and tone map. Uses p_bloom if the style defines it.
vec4 motif(vec2 uv, vec2 fc) {
  vec2 t = fc / u_res; vec2 px = 1.0 / u_res;
  vec3 c = texture(u_buf0, t).rgb;
  vec3 bl = vec3(0.0); float wsum = 0.0;
  for (int i = 0; i < 16; i++) {
    float a = float(i) * 2.39996; float r = sqrt(float(i) + 0.5) * 3.2;
    vec2 o = vec2(cos(a), sin(a)) * r * px * (u_res.y / 360.0);
    vec3 s = texture(u_buf0, t + o).rgb; float w = 1.0 / (1.0 + r * 0.3);
    bl += max(s - 0.6, 0.0) * w; wsum += w;
  }
  bl /= wsum;
  vec3 col = aces((c + bl * 2.5 * p_bloom) * 1.05);
  return vec4(col, max(max(col.r, col.g), col.b));
}

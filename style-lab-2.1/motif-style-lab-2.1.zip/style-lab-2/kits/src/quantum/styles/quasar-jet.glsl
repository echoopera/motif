// Quasar Jet — a feeding supermassive black hole fires relativistic jets; knots race outward along a kinking helix.
vec4 motif(vec2 uv, vec2 fc) {
  float ang = p_angle * PI;
  vec2 ax = vec2(cos(ang), sin(ang)), nx = vec2(-ax.y, ax.x);
  vec2 q = uv / p_scale;
  float s = dot(q, ax), n = dot(q, nx);
  vec3 col = vec3(0.0);
  // host galaxy glow + dust lane
  float gal = exp(-length(q * vec2(1.0, 1.8)) * 3.0);
  float dust = 1.0 - 0.7 * p_dust * exp(-pow(dot(q, vec2(0.3, 1.0)) * 18.0, 2.0)) * (0.6 + 0.4 * lfbm(q * 8.0, 3, 1.0, 0.2));
  col += mix(u_a1, u_ink, 0.3) * gal * 0.5 * p_host * dust;
  // accretion disk seen at an angle (ellipse)
  vec2 dq = rot(ang) * q; dq.y /= 0.25;
  float dr = length(dq);
  float disk = exp(-pow((dr - 0.05) * 30.0, 2.0)) + exp(-dr * 40.0) * 2.0;
  col += Q_heat(0.8) * disk * p_core * dust;
  // jets (approaching: s>0, bright; receding: s<0, dimmed by Doppler)
  for (int j = 0; j < 2; j++) {
    float sg = j == 0 ? 1.0 : -1.0;
    float ss = s * sg;
    if (ss < 0.0) continue;
    float doppler = j == 0 ? 1.0 : 0.25 + 0.5 * (1.0 - p_beaming);
    float width = 0.006 + ss * 0.07 * p_opening;
    // helical kink: offset grows with distance, pattern travels outward
    float kink = p_kink * 0.05 * ss * sin(ss * 26.0 - TAU * u_p * float(p_speed) * 2.0);
    float kink2 = p_kink * 0.02 * ss * sin(ss * 61.0 - TAU * u_p * float(p_speed) * 5.0 + 1.0);
    float dn = n - kink - kink2;
    float core = exp(-dn * dn / (width * width));
    float sheath = exp(-dn * dn / (width * width * 9.0)) * 0.25;
    // knots: bright blobs moving outward, loop-periodic
    float kn = 0.0;
    for (int k = 0; k < 5; k++) {
      float x = fract(u_p * float(p_speed) + float(k) / 5.0 + h11(float(k) + sg));
      float pos = pow(x, 1.4) * 1.1;
      kn += exp(-pow((ss - pos) / (0.02 + pos * 0.04), 2.0)) * (1.0 - x) * 2.0;
    }
    float fall = exp(-ss * 1.4 / p_length);
    float turb = 0.7 + 0.3 * lfbm(vec2(ss * 12.0, dn * 40.0), 3, float(p_speed), 0.3);
    vec3 jc = mix(u_a2, u_a0, sat(ss * 1.5)) ;
    col += (jc * (core + sheath) * turb * fall + mix(u_ink, u_a2, 0.3) * kn * core * p_knots) * doppler * 1.6;
    // terminal lobe / hotspot
    float L = 0.9 * p_length;
    vec2 lp = vec2(ss - L, dn * 1.3);
    float lobe = exp(-dot(lp, lp) * 25.0) * (0.6 + 0.4 * lfbm(lp * 8.0, 4, 1.0, 0.3));
    col += u_a0 * lobe * p_lobes * doppler + u_ink * exp(-dot(lp, lp) * 900.0) * p_lobes * doppler;
  }
  col += Q_stars2(uv, p_stars, 0.6) * 0.8;
  col = aces(col * 1.2);
  return vec4(col, max(max(col.r, col.g), col.b));
}

// Bubble Chamber — charged particles spiral through a magnetic field, bleeding energy into tightening curls; pairs fork in V's.
vec4 motif(vec2 uv, vec2 fc) {
  vec2 A = M_asp() * 0.5;
  vec3 col = vec3(0.0); float cover = 0.0;
  float px = aa();
  // chamber background: faint liquid texture
  float bgT = lfbm(uv * 3.0, 3, 1.0, 0.15) * 0.5 + 0.5;
  col += u_a2 * 0.04 * bgT * p_liquid;
  for (int i = 0; i < 24; i++) {
    if (i >= p_tracks) break;
    float fi = float(i);
    vec3 h = h33(vec3(fi, 2.0, 7.0));
    // event timing: each track appears, grows, lingers, fades (loop-periodic)
    float t = fract(u_p * float(p_rate) + h.x);
    float grow = smoothstep(0.0, 0.25, t);
    float fade = 1.0 - smoothstep(0.7, 1.0, t);
    if (fade <= 0.0) continue;
    float charge = h.y < 0.5 ? 1.0 : -1.0;
    // entry: particles stream in from the left edge; some are created in the chamber (pair production)
    bool pair = h.z < p_pairs;
    vec2 start = pair ? (h33(vec3(fi, 5.0, 1.0)).xy - 0.5) * A * 1.4 : vec2(-A.x - 0.05, (h.z - 0.5) * A.y * 1.6);
    float dir0 = pair ? TAU * h.x : (h.y - 0.5) * 0.6;
    float R0 = (0.15 + 0.9 * pow(fract(h.x * 13.0), 2.0)) * p_momentum;    // initial radius (momentum)
    float b = 0.06 + 0.25 * fract(h.z * 7.0) * p_energyLoss;                // spiral tightening
    // log-spiral centre
    vec2 nrm = vec2(-sin(dir0), cos(dir0)) * charge;
    vec2 ctr = start + nrm * R0;
    vec2 q = uv - ctr;
    float r = length(q);
    float th = atan(q.y, q.x);
    float th0 = atan(start.y - ctr.y, start.x - ctr.x);
    // angle travelled along the spiral (in the direction of motion)
    float dth = charge * (th0 - th);
    dth = mod(dth, TAU);
    float best = 1e9; float bestS = 0.0;
    float turns = 1.0 + 4.0 * p_energyLoss;
    for (int k = 0; k < 6; k++) {
      float tk = dth + TAU * float(k);
      if (tk > turns * TAU) break;
      float rk = R0 * exp(-b * tk);
      float d = abs(r - rk);
      if (d < best) { best = d; bestS = tk / (turns * TAU); }
    }
    float visible = step(bestS, grow);
    // bubbles: dotted along the track, denser as the particle slows
    float s = bestS * 300.0 * p_bubbleDensity;
    float bub = step(0.35, h11(floor(s) + fi * 1000.0));
    float trackW = 0.0018 * p_width * (1.0 + bestS);
    float tr = (1.0 - smoothstep(trackW, trackW + px, best)) * visible * bub;
    vec3 tc = charge > 0.0 ? u_a0 : u_a1;
    if (p_mono) tc = u_ink;
    col += tc * tr * fade * 1.2 + tc * glow2(best, 0.004) * 0.08 * visible * fade * p_glow;
    cover = max(cover, tr * fade);
    // pair vertex marker
    if (pair) col += u_ink * exp(-dot(uv - start, uv - start) * 30000.0) * grow * fade;
  }
  // beam flash lines (entry markers)
  col = aces(col * 1.2);
  return vec4(col, max(cover, max(max(col.r, col.g), col.b)));
}

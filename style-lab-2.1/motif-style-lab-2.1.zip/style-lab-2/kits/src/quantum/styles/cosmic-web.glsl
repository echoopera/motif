// Cosmic Web — an infinite flight into the dark-matter scaffold: filaments, clusters and galaxies at every scale.
float CW_web(vec2 p, float lvl) {
  vec3 v = lvoro(p, 0.95, 1.0, 0.15);
  float e = v.y - v.x;
  float fil = exp(-e * e * 220.0 / (p_thickness * p_thickness)) * (0.4 + 0.6 * step(0.35, fract(v.z * 13.0)));
  float node = exp(-v.x * v.x * 30.0) * step(0.5, fract(v.z * 7.0 + lvl)) * p_nodes;
  return fil * 0.7 + node * 1.4;
}
vec4 motif(vec2 uv, vec2 fc) {
  // log-periodic zoom: four octaves blended so the loop closes after one doubling
  float z = u_p * float(p_zoomSpeed);
  vec3 col = vec3(0.0);
  vec2 q = rot(p_twist * 0.35 * lsin(1.0, 0.0)) * uv;
  for (int i = 0; i < 5; i++) {
    float fi = float(i);
    float lvl = fi - fract(z);
    float sc = pow(2.0, lvl) * 0.9 * p_scale;
    float w = sat(1.0 - abs(lvl - 2.0) / (1.5 + 1.5 * p_depth));   // fade in from far, out when too close
    w = w * w * (3.0 - 2.0 * w);
    float oct = mod(floor(z) + fi, float(p_zoomSpeed) * 4.0 > 0.0 ? float(p_zoomSpeed) : 1.0); // identity per octave, periodic over the loop
    vec2 pp = q * sc + vec2(h11(oct + 1.0), h11(oct + 9.0)) * 50.0;
    float web = CW_web(pp, oct);
    float gas = lfbm(pp * 0.5, 3, 1.0, 0.2) * 0.5 + 0.5;
    vec3 c = mix(u_a1, u_a0, sat(web * 0.8)) * web + u_a1 * pow(gas, 4.0) * 0.18 * p_gas;
    // galaxies: sparkles concentrated along filaments
    vec2 gp = pp * 6.0; vec2 gn = floor(gp); vec3 gh = h33(vec3(gn, oct));
    float gd = length(gp - gn - 0.2 - 0.6 * gh.xy);
    c += mix(u_ink, u_a1, gh.z) * exp(-gd * gd * 90.0) * step(1.0 - web * 0.9 * p_galaxies, gh.z) * 1.5;
    col += c * w * 0.55;
  }
  col = aces(col * 1.3 * p_brightness);
  return vec4(col, max(max(col.r, col.g), col.b));
}

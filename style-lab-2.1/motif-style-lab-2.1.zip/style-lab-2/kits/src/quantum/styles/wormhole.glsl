// Wormhole — an Einstein-Rosen throat: one sky lensed around the rim, another universe glowing through it.
vec3 WH_sky(vec3 d, float which) {
  vec3 s = Q_stars(d, p_stars) * 1.2;
  float neb = lfbm3(d * 2.5 + which * 11.0, 4, 1.0, 0.25) * 0.5 + 0.5;
  vec3 tint = which > 0.5 ? mix(u_a1, u_a2, neb) : mix(u_a0 * 0.4, u_a2 * 0.5, neb);
  return s + tint * pow(neb, 3.0) * (which > 0.5 ? 1.2 : 0.35) * p_nebula;
}
vec4 motif(vec2 uv, vec2 fc) {
  float R = 0.27 * p_size;
  float r = length(uv);
  float a = atan(uv.y, uv.x);
  float spin = TAU * u_p * float(p_spin);
  vec3 col;
  if (p_mode == MODE_TRANSIT) {
    // flying through the throat: log-polar tunnel with streaming walls
    float z = log(max(r, 1e-3)) * 1.6;
    vec2 tq = vec2(a / TAU * float(p_arms) + z * p_twist * 0.3, z - u_p * float(p_spin) * 2.0);
    float walls = Q_tnoise(vec2(tq.x / float(p_arms), tq.y * 0.5), vec2(1.3, 1.1), 5);
    float streaks = pow(0.5 + 0.5 * sin(TAU * (tq.x * 3.0 + walls)), 8.0);
    vec3 wc = mix(u_a0, u_a1, 0.5 + 0.5 * walls) * (0.4 + walls) + u_ink * streaks * 0.6;
    float depth = smoothstep(0.0, 0.5, r);
    col = wc * depth * 1.4 + mix(u_a2, u_ink, 0.5) * exp(-r * 18.0) * 2.0;
  } else {
    vec3 d;
    float which = 0.0;
    if (r > R) {
      // outside: deflection ~ R^2/r (Einstein ring at r = R)
      float defl = p_lensing * R * R / r * 2.2;
      float rr = r - defl;
      vec2 duv = (rr < 0.0 ? -1.0 : 1.0) * normalize(uv) * abs(rr);
      d = normalize(vec3(duv * 1.4, -1.0));
    } else {
      // inside: the other universe, inverted and twisted
      which = 1.0;
      float ri = R * R / max(r, 1e-4);
      float tw = p_twist * 3.0 * (1.0 - r / R) + spin;
      vec2 duv = rot(tw) * normalize(uv) * ri;
      d = normalize(vec3(duv * 0.6, -1.0));
    }
    d.xz = rot(0.3 * lsin(1.0, 0.0)) * d.xz;
    col = WH_sky(d, which);
    // photon ring at the throat
    float ring = exp(-pow((r - R) / (0.006 + 0.01 * p_ring), 2.0));
    float swirl = 0.5 + 0.5 * sin(a * float(p_arms) + log(max(r, 1e-3)) * 10.0 - spin * 2.0);
    col += mix(u_a1, u_ink, 0.4) * ring * (1.2 + swirl) * p_ring;
    col += u_a0 * glow2(r - R, 0.03) * 0.25 * p_ring * swirl;
  }
  col = aces(col * 1.1);
  return vec4(col, max(max(col.r, col.g), col.b));
}

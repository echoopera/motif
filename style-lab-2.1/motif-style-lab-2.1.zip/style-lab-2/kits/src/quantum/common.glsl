// QUANTUM kit common helpers.
// Starfield on the view sphere: dir must be normalised. density 0..1, returns radiance.
vec3 Q_stars(vec3 dir, float density) {
  vec3 col = vec3(0.0);
  for (int l = 0; l < 3; l++) {
    float sc = 60.0 + float(l) * 90.0;
    vec3 p = dir * sc;
    vec3 c = floor(p);
    vec3 h = h33(c + float(l) * 17.0);
    if (h.x < density * (0.35 - float(l) * 0.08)) {
      vec3 sp = c + 0.2 + 0.6 * h;
      float d = length(p - sp);
      float br = pow(h.y, 6.0) * 3.0 + 0.2;
      float tw = 0.75 + 0.25 * lsin(float(1 + int(h.z * 3.0)), h.x * 7.0);
      col += bb(3000.0 + 9000.0 * h.z) * br * tw * exp(-d * d * (18.0 + float(l) * 10.0));
    }
  }
  return col;
}
// 2D starfield in uv space with occasional diffraction spikes.
vec3 Q_stars2(vec2 uv, float density, float spikes) {
  vec3 col = vec3(0.0);
  for (int l = 0; l < 3; l++) {
    float sc = 22.0 + float(l) * 30.0;
    vec2 p = uv * sc + float(l) * 13.1;
    vec2 c = floor(p); vec3 h = h33(vec3(c, float(l) + 4.0));
    if (h.x < density * (0.5 - float(l) * 0.12)) {
      vec2 d = p - c - 0.2 - 0.6 * h.xy;
      float br = pow(h.z, 5.0) * 2.5 + 0.12;
      float tw = 0.8 + 0.2 * lsin(float(1 + int(h.y * 3.0)), h.z * 5.0);
      float core = exp(-dot(d, d) * 60.0);
      float spk = spikes * br * (exp(-abs(d.x) * 60.0) * exp(-abs(d.y) * 4.0) + exp(-abs(d.y) * 60.0) * exp(-abs(d.x) * 4.0)) * step(0.85, h.z);
      col += bb(2800.0 + 9000.0 * fract(h.y * 7.0)) * (core * br + spk * 0.25) * tw;
    }
  }
  return col;
}
// Accretion-style colour ramp from temperature 0..1 using the palette.
vec3 Q_heat(float t) { t = sat(t); return mix(mix(u_a2 * 0.3, u_a0, sat(t * 1.8)), mix(u_a1, u_ink, sat(t * 2.0 - 1.0)), sat(t * 1.6 - 0.5)); }
// Noise on a torus: periodic with period 1 in both t.x and t.y. r = radii (feature density).
float Q_tnoise(vec2 t, vec2 r, int oct) {
  float s = 0.0, a = 0.5; vec2 rr = r;
  for (int i = 0; i < 6; i++) {
    if (i >= oct) break;
    vec4 p = vec4(rr.x * cos(TAU * t.x), rr.x * sin(TAU * t.x), rr.y * cos(TAU * t.y), rr.y * sin(TAU * t.y));
    s += a * snoise(p + vec4(M_seedOff(), float(i) * 3.1, 1.7));
    rr *= 2.0; a *= 0.5;
  }
  return s;
}

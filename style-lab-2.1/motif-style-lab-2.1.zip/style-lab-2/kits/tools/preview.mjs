// Dev preview: compile every style of a kit in Chromium (WebGL2/SwiftShader), render a contact sheet
// (4 phases per style), check the loop closes (p=0 vs p=1) and time each frame.
// usage: node kits/tools/preview.mjs kits/src/neuro [styleId ...] [--w=320 --h=180 --pal=<id>]
import fs from 'node:fs'; import path from 'node:path';
import { chromium } from '/home/claude/.npm-global/lib/node_modules/playwright/index.mjs';
import { kitGlSource, readKitDir, root } from './load.mjs';
const args = process.argv.slice(2); const opt = Object.fromEntries(args.filter(a => a.startsWith('--')).map(a => a.slice(2).split('=')));
const pos = args.filter(a => !a.startsWith('--'));
const dir = path.resolve(pos[0]); const only = pos.slice(1);
const W = +(opt.w || 320), H = +(opt.h || 180);
const { manifest, files } = readKitDir(dir);
const kg = new Function(kitGlSource())();
const v = kg.validateKit(manifest, files);
v.warnings.forEach(w => console.log('warn:', w));
if (!v.ok) { v.errors.forEach(e => console.log('ERROR:', e)); process.exit(1); }
const kit = v.kit; const styles = kit.styles.filter(s => !only.length || only.includes(s.localId));
const phases = (opt.phases || '0,0.25,0.5,0.75').split(',').map(Number);
const html = `<!doctype html><html><body style="margin:0;background:#111"><canvas id="c"></canvas><script>
const KG = (function(){ ${kitGlSource()} })();
window.KG = KG;
</script></body></html>`;
const browser = await chromium.launch({ headless: true, executablePath: '/opt/pw-browsers/chromium', args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--no-sandbox', '--ignore-gpu-blocklist'] });
const page = await browser.newPage({ viewport: { width: 800, height: 600 } });
page.on('pageerror', e => console.log('pageerror', e.message));
await page.setContent(html);
const res = await page.evaluate(async ({ kit, styles, W, H, phases, palId, param }) => {
  const rt = KG.createGlRuntime(); if (!rt.ok) return { fatal: rt.reason };
  const cols = phases.length, pad = 4, lab = 16;
  const sheet = document.getElementById('c'); sheet.width = cols * (W + pad) + pad; sheet.height = styles.length * (H + pad + lab) + pad;
  const sx = sheet.getContext('2d'); sx.fillStyle = '#1a1a1a'; sx.fillRect(0, 0, sheet.width, sheet.height);
  const out = [];
  styles.forEach((st, row) => {
    const pal = kit.palettes.find(p => p.id === (palId ? kit.id + '.' + palId : st.palette)) || kit.palettes[0];
    const params = {}; for (const [k, s] of Object.entries(st.params)) params[k] = s.def;
    if (param) for (const kv of param.split(';')) { const [k, v] = kv.split(':'); if (k in params) params[k] = isNaN(+v) ? (v === 'true' ? true : v === 'false' ? false : v) : +v; }
    const t0 = performance.now(); const c = rt.compile(st.id, { passes: st.passes, common: kit.common, params: st.params }); const compileMs = performance.now() - t0;
    const y = pad + row * (H + pad + lab);
    sx.fillStyle = '#ddd'; sx.font = '11px monospace'; sx.fillText(st.localId + (c.ok ? '' : '  ✖ COMPILE'), pad, y + 11);
    if (!c.ok) { out.push({ id: st.localId, error: c.error }); return; }
    const u = p => ({ p, L: 6, seed: 417, safe: false, pal, params, spec: st.params });
    const tmp = document.createElement('canvas'); tmp.width = W; tmp.height = H; const tx = tmp.getContext('2d');
    const grab = p => { rt.draw(st.id, W, H, u(p)); tx.clearRect(0, 0, W, H); rt.blit(tx, W, H); return tx.getImageData(0, 0, W, H).data; };
    let ms = [];
    phases.forEach((p, i) => {
      const t1 = performance.now(); rt.draw(st.id, W, H, u(p)); const gl = rt.canvas.getContext('webgl2'); const px = new Uint8Array(4); gl.readPixels(0, 0, 1, 1, gl.RGBA, gl.UNSIGNED_BYTE, px); ms.push(performance.now() - t1);
      const x = pad + i * (W + pad);
            sx.fillStyle = pal.bg; sx.fillRect(x, y + lab, W, H); sx.drawImage(rt.canvas, 0, rt.canvas.height - H, W, H, x, y + lab, W, H);
    });
    const dlt = 1 / 240; const fA = grab(1 - dlt), f0 = grab(0), fB = grab(dlt);
    const md = (x, y) => { let s = 0; for (let i = 0; i < x.length; i++) s += Math.abs(x[i] - y[i]); return s / x.length; };
    const jump = md(fA, f0), ref = (md(f0, fB) + md(grab(0.5 - dlt), grab(0.5))) / 2; const diff = +(jump / Math.max(ref, 0.05)).toFixed(2);
    // Coverage + mean luma to catch blank frames.
    const m = grab(0.37); let lum = 0, cov = 0; for (let i = 0; i < m.length; i += 4) { lum += (m[i] + m[i + 1] + m[i + 2]) / 765; cov += m[i + 3] > 8 ? 1 : 0; }
    out.push({ id: st.localId, compileMs: Math.round(compileMs), frameMs: +(ms.reduce((s, x) => s + x, 0) / ms.length).toFixed(1), loopDiff: diff, lum: +(lum / (W * H)).toFixed(3), coverage: +(cov / (W * H)).toFixed(2) });
  });
  return { out, png: sheet.toDataURL('image/png') };
}, { kit, styles, W, H, phases, palId: opt.pal || null, param: opt.param || null });
await browser.close();
if (res.fatal) { console.log('FATAL', res.fatal); process.exit(1); }
for (const r of res.out) console.log(r.error ? `✖ ${r.id}\n${r.error}` : `✓ ${r.id.padEnd(22)} compile ${String(r.compileMs).padStart(5)}ms  frame ${String(r.frameMs).padStart(6)}ms  seam×${r.loopDiff}  luma ${r.lum}  cov ${r.coverage}`);
const outFile = path.join(root, 'kits/out', `${kit.id}${only.length ? '-' + only.join('_').slice(0, 40) : ''}${opt.tag ? '-' + opt.tag : ''}.png`);
fs.writeFileSync(outFile, Buffer.from(res.png.split(',')[1], 'base64')); console.log('sheet:', outFile);

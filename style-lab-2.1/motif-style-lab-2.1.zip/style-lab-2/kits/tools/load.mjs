// Loads the kit-gl module (DOM-free parts) and a kit folder in Node.
import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
const here = path.dirname(fileURLToPath(import.meta.url));
export const root = path.join(here, '..', '..');
export function kitGlSource() {
  const dir = path.join(root, 'src/modules/kit-gl');
  const files = fs.readdirSync(dir).filter(f => f.endsWith('.js')).sort((a, b) => (a === 'index.js') - (b === 'index.js') || a.localeCompare(b));
  return files.map(f => fs.readFileSync(path.join(dir, f), 'utf8')).join('\n');
}
export function kitGl() { return new Function(kitGlSource())(); }
export function readKitDir(dir) {
  const files = {};
  const walk = d => { for (const f of fs.readdirSync(d)) { const p = path.join(d, f); if (fs.statSync(p).isDirectory()) walk(p); else if (!f.startsWith('.')) files[path.relative(dir, p).split(path.sep).join('/')] = fs.readFileSync(p, 'utf8'); } };
  walk(dir);
  const manifest = JSON.parse(files['manifest.json']); delete files['manifest.json'];
  return { manifest, files };
}

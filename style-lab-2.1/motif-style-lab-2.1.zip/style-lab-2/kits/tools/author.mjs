// Authoring helpers: write manifest.json from a compact JS description.
import fs from 'node:fs'; import path from 'node:path';
export const R = (label, min, max, def, step = 0.01, o = {}) => ({ type: 'range', label, min, max, def, step, ...o });
export const I = (label, min, max, def, o = {}) => ({ type: 'int', label, min, max, def, ...o });
export const T = (label, def, o = {}) => ({ type: 'toggle', label, def, ...o });
export const S = (label, options, def, o = {}) => ({ type: 'select', label, options, def, ...o });
export function writeManifest(dir, kit) {
  const m = { format: 'motif-kit@1', ...kit, styles: kit.styles.map(s => ({ ...s, passes: s.passes || [{ src: `styles/${s.id}.glsl` }] })) };
  fs.writeFileSync(path.join(dir, 'manifest.json'), JSON.stringify(m, null, 2) + '\n');
  return m;
}

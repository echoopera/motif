# Motif Kit SDK (`motif-kit@1`)

A kit is a set of shader styles packaged as a single `.motifkit` file. When you drop one on Motif Style Lab 2.1, its styles show up in the library alongside the 25 built-ins and work the same way: layers, blend modes and masks, keyframes on any parameter, Mutate, Evolve, Randomize, audio-band mapping, the finishing stack, and every export format.

The app is one build. A kit is data (a manifest plus GLSL) that is checked, test-compiled and registered when it is loaded.

```
motif-kit new my-kit --id my-kit       # copy the starter template (2 example styles)
motif-kit preview my-kit               # contact sheet + compile errors, loop seam, blank-frame check, timing
motif-kit validate my-kit              # schema and static checks
motif-kit pack my-kit --out dist       # writes dist/my-kit-0.1.0.motifkit
motif-kit prelude                      # prints the GLSL prelude every pass is compiled with
```

Setup: `npm i` in this folder. For `preview`, also run `npm i -D playwright && npx playwright install chromium`, or point `MOTIF_CHROMIUM` at an existing Chromium.

## Package layout

```
my-kit/
  manifest.json          required
  common.glsl            optional; shared helpers compiled into every pass of every style
  styles/*.glsl          one file per pass
  README.md              optional
```

A `.motifkit` file is a zip of this folder with `manifest.json` at the root. The app also accepts a zip with the folder inside it, or a JSON bundle shaped `{ "manifest": {…}, "files": { "path": "text" } }`.

## manifest.json

| Field | Rules |
| --- | --- |
| `format` | `"motif-kit@1"` |
| `id` | 2–32 characters: lowercase letters, digits and hyphens, starting with a letter. Unique per install. `core`, `motif`, `builtin` and `all` are reserved. Installing a kit with an id that is already installed updates it. |
| `name`, `version` | Display name (up to 32 characters) and a semver version such as `1.2.0` |
| `author`, `description`, `license`, `accent` | Optional. `accent` is a `#RRGGBB` colour used for the kit's chip and badges. |
| `common` | Optional path to shared GLSL |
| `palettes[]` | Up to 8 palettes: `{ id, name, bg, ink, a: [3 accents] }`, all `#RRGGBB`. They become `<kit>.<id>` in the palette picker. |
| `styles[]` | 1–40 styles (see below) |

### Styles

| Field | Rules |
| --- | --- |
| `id`, `name` | Same id rules as the kit. The app id is `<kit>/<style>`, so presets refer to `neuro/mitosis`. |
| `group`, `tags[]`, `blurb` | Shown in the library and matched by search |
| `palette` | Optional id of one of the kit's palettes. It is applied when a layer switches into this kit from another. |
| `flash` | Set this to `true` if the style can flash or strobe. It marks the style ⚡ in the library. |
| `passes[]` | 1–4 passes: `{ "src": "styles/x.glsl", "scale": 0.5 }`. `scale` (0.125–1) sets the render size of an intermediate pass; the last pass always renders at full size. Pass *n* can sample earlier passes as `u_buf0` … `u_buf3`. |
| `params` | Up to 16 parameters. Use 4 or more, or Mutate and Evolve have little to work with. |

### Parameters

The keys are camelCase (`glowAmount`). `palette`, `invert`, `tempo`, `phase`, `seed`, `zoom`, `rotate` and `loop` are reserved, because every layer already has them.

| type | JSON | Uniform in GLSL |
| --- | --- | --- |
| `range` | `{ "type": "range", "label": "Glow", "min": 0, "max": 2, "def": 1, "step": 0.01, "unit": "×", "mutate": 1 }` | `uniform float p_glow;` |
| `int` | `{ "type": "int", "label": "Rings", "min": 1, "max": 12, "def": 5 }` | `uniform int p_rings;` |
| `toggle` | `{ "type": "toggle", "label": "Trails", "def": true }` | `uniform bool p_trails;` |
| `select` | `{ "type": "select", "label": "Mode", "options": ["rings", "dots"], "def": "rings" }` | `uniform int p_mode;` plus `#define MODE_RINGS 0` and `#define MODE_DOTS 1` |

`mutate` (0–1) sets how strongly Mutate and Evolve move a parameter; `0` locks it. For a select option you can use `{ "v": "white-hot", "l": "White hot" }`, and its define becomes `MODE_WHITE_HOT`. A camelCase key becomes snake case in the define (`rungMode` → `RUNG_MODE_BASES`). Every parameter can be keyframed and mapped to audio bands in the app with no extra work.

## Writing a pass

Each pass defines exactly one entry point. The runtime supplies `main()`.

```glsl
vec4 motif(vec2 uv, vec2 fc) {
  // uv: centred coordinates, the short side of the frame spans -0.5..0.5
  // fc: pixel coordinates (gl_FragCoord.xy)
  return emit(aces(col));   // premultiplied linear RGBA
}
```

- **Output:** premultiplied, linear-light RGBA. The runtime converts it to sRGB, dithers it and keeps alpha consistent. Content with alpha 0 lets the palette background and lower layers show through, which is how kit styles blend with other layers. Use `emit(c)` for glowing content, `solid(c, a)` for opaque shapes, and return `vec4(col, 1.0)` for a full-frame scene.
- **Inputs:** `u_res`, `u_p` (loop phase 0–1, with tempo and phase already applied), `u_L` (effective loop length in seconds), `u_seed`, `u_safe`, palette `u_bg u_ink u_a0 u_a1 u_a2` (linear RGB), and `u_buf0..3` (earlier passes).

### The loop rule

Time enters only through `u_p`, and every periodic function of it needs an integer frequency. Follow that and frame 0 equals the frame at the loop length exactly, so every loop is seamless and every frame renders deterministically on its own (for exports, scrubbing and Evolve). Passes cannot keep state between frames. Build simulations as closed-form functions of `u_p`: travelling waves, orbits, noise that loops, or growth envelopes.

| Helper | What it gives you |
| --- | --- |
| `lc(k, ph)`, `lsin(k, ph)`, `lsaw(k, ph)` | Circle, sine and saw at *k* cycles per loop |
| `pulse(s, k, ph, w)` | A pulse train travelling along coordinate *s*, *k* pulses per loop |
| `growEnv(hold)` | An envelope that rises 0 → 1, holds, and falls back to 0 over the loop |
| `ln2(x, k, r)`, `ln3(x, k, r)` | Simplex noise that loops *k* times per loop (*r* sets how far it travels) |
| `lfbm`, `lfbm3`, `lridge` | Looping fBm and ridged fBm |
| `lvoro(x, jitter, k, amp)` | Voronoi whose sites orbit their cells; returns `(F1, F2, id)` |
| `snoise(vec3)`, `snoise(vec4)` | Raw simplex noise |
| `h11 h21 h22 h33` | Hashes, seeded by the layer seed |
| `rot sat remap smin smax luma` | Maths |
| `sdSeg sdBox sdBox3 sdTorus line aa glowd glow2 gauss1` | Shapes, anti-aliasing and glows |
| `ramp(t) accent(i) hot(t) bb(kelvin) aces(c)` | Palette ramps, blackbody colour and tone mapping |
| `emit solid over addc` | Premultiplied compositing |
| `tslot(n) tfrac(n) strobe(k, duty) safeCycles(k) flashAmt(x)` | Flicker and flashing that the limiter controls (see below) |
| `M_asp() buf(sampler, fc)` | Frame extent in uv units; sample an earlier pass by pixel |

## Photosensitive limiter

The **Photosensitive-safe limiter** in the Kits tab is on by default. With it on, `tslot`, `tfrac`, `strobe` and `safeCycles` cap the rate of change at 3 per second, based on the effective loop length. When even one change per loop would be too fast, the rate drops to 0 and the effect holds still. `flashAmt` also scales down full-frame flashes.

Route every glitch, flicker, strobe and flash through these helpers, and set `"flash": true` on styles that use them. The app's test suite renders every kit style at the worst case (a 1 s loop at 4× tempo) and counts flashes against WCAG 2.3.1 on a 4×4 grid of screen tiles. Every bundled style stays at 3 or fewer in any second.

## Validation

Before a kit installs, the app and `motif-kit validate` check the following:

- Format, ids, semver, colours
- Unique style ids and the limits: 40 styles, 16 params, 4 passes, 96 KB per GLSL file, 3 MB per kit
- Parameter types, ranges and defaults, and reserved names
- Each pass defines `vec4 motif(vec2, vec2)` and does not define `main()`

The app then compiles every pass. Any error rejects the kit and reports the style, the pass and the line number within that pass file. A kit that fails leaves any installed version untouched.

## Performance notes

- Keep loops bounded by constants (`for (int i = 0; i < 12; i++) { if (i >= p_n) break; … }`).
- Cull early: skip work when the pixel is far from an object (see `neuro/neural-arbor`).
- Put expensive scenes in a pass with `"scale": 0.5` and add a cheap full-resolution post pass for bloom and grain (see `quantum/event-horizon` and `neuro/organoid`).
- Raymarchers: expose a quality parameter that sets the step count.

## Examples

The three bundled kits in `kits/src/` (neuro, quantum, cyberpunk) are full-size references. Between them they cover 54 styles, including multi-pass post effects, raymarchers, analytical physics and limiter-aware glitch effects.

# colour v1.0.0

Owner: colour-scientist · Imports: tokens · Acceptance: AC-3

Brand palettes: resolution with key cross-fades (OKLab mix), OKLCH mutation honouring per-colour locks, harmonize, k-means extraction, contrast, output spaces (sRGB, Display P3, Rec.709) and the broadcast-safe reference limiter.

**Exports:** SPACES, spaceById, resolvePalette, customFrom, sanitizeCustom, mutatePalette, harmonize, extractPalette, contrast, legalize, isIllegal, gradientStops

**Rule:** The GPU limiter in finish mirrors legalize().

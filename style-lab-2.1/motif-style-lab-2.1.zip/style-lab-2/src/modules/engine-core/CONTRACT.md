# engine-core v1.1.0

Owner: systems-architect · Imports: none · Acceptance: —

Deterministic maths: seeded RNG and hash, looping simplex noise (permutation table exposed for the GPU), eases, parameter schema with log-scale counts, mutate/randomize.

**Exports:** TAU, clamp, lerp, fract, hash, mulberry32, createNoise → {n3, loop, perm}, ease, P, defaults, sanitize, mutate, randomize, memo, makeCanvas, fitFont, sampleText

**Rule:** No DOM except canvas factories.

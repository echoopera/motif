# tokens v2.0.0

Owner: design-systems-lead · Imports: none · Acceptance: AC-7, AC-8

Foundations and semantic UI tokens (light/dark, coarse-pointer 44 px targets), the ten built-in artwork palettes, fonts, aspect ratios and hex helpers.

**Exports:** uiCss, PALETTES, FONTS, FONT_LINK, ASPECTS, rgbOf, alpha, mix, mixRgb, luminance, resolvePalette

**Rule:** Only module (with colour) allowed raw colour values.

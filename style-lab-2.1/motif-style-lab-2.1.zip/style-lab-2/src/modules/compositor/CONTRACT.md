# compositor v1.0.0

Owner: graphics-engineer · Imports: engine-core, style-library, colour, timeline, gpu-engine · Acceptance: AC-2, AC-4

Draws an evaluated project: per-layer style (CPU or GPU), shape masks and track mattes, 11 native blend modes, opacity, visibility, base-layer background.

**Exports:** createCompositor({gpu}) → {renderLook, renderEvaluated, renderProject, scratch}

**Rule:** Pure in (evaluated project, t).

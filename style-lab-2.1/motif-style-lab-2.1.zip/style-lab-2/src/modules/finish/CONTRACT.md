# finish v1.0.0

Owner: graphics-engineer · Imports: none · Acceptance: AC-3, AC-4

WebGL2 finishing chain: half-float motion-blur accumulation, threshold glow, chromatic offset, depth blur, levels, gradient map, vignette, deterministic grain, broadcast limiter, illegal-colour zebra; P3 drawing buffer.

**Exports:** createFinisher() → {ok, halfFloat, canvas, setSpace, beginAccum, addAccum, loadInput, process}, needsGpu

**Rule:** Falls back to Canvas 2D grain/vignette when WebGL2 is missing.

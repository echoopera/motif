// kit-gl — WebGL2 runtime for Motif Kit shader styles (motif-kit@1).
// One shared GL canvas. Programs compile lazily per style, passes render into half-float
// targets, the final pass lands in the bottom-left w×h region of the shared canvas, and the
// caller copies it with drawImage. Stateless per frame: every frame is a pure function of
// (params, palette, seed, phase), so exports are deterministic and loops close exactly.

const MAX_PASSES = 4;
const RESERVED = /^(u_|M_|gl_)/;

function hexToLin(hex) {
  const n = parseInt(String(hex).replace('#', '').slice(0, 6), 16) || 0;
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255].map(v => { v /= 255; return v <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); });
}

// Uniform declarations for a style's params: range → float, int → int, toggle → bool, select → int (option index).
function paramUniforms(params) {
  let s = '';
  for (const [k, p] of Object.entries(params || {})) {
    if (p.type === 'text') continue;
    const t = p.type === 'range' ? 'float' : p.type === 'toggle' ? 'bool' : 'int';
    s += `uniform ${t} p_${k};\n`;
    if (p.type === 'select') p.options.forEach((o, i) => { s += `#define ${k.replace(/([a-z0-9])([A-Z])/g, '$1_$2').toUpperCase()}_${String(o.v).toUpperCase().replace(/[^A-Z0-9]/g, '_')} ${i}\n`; });
  }
  return s;
}

function buildSource(passSrc, common, params, final) {
  const head = PRELUDE + '\n// ---- params ----\n' + paramUniforms(params) + '\n// ---- kit common ----\n' + (common || '') + '\n// ---- pass ----\n#line 1 1\n';
  return { src: head + passSrc + (final ? MAIN_FINAL : MAIN_PASS), headLines: head.split('\n').length - 1 };
}

function createGlRuntime() {
  const canvas = typeof document !== 'undefined' ? document.createElement('canvas') : null;
  let gl = null, reason = '', halfFloat = false, lost = false;
  const programs = new Map(); // key -> { passes:[{prog, uniforms, scale}], error }
  const targets = new Map();  // `${key}|${i}|${w}x${h}` -> { tex, fbo, w, h }
  let vao = null, vbo = null;
  function init() {
    if (gl || !canvas) return !!gl;
    canvas.width = 2; canvas.height = 2;
    try { gl = canvas.getContext('webgl2', { premultipliedAlpha: true, preserveDrawingBuffer: true, antialias: false, alpha: true, depth: false, stencil: false, powerPreference: 'high-performance' }); } catch (e) { gl = null; }
    if (!gl) { reason = 'WebGL2 is not available in this browser.'; return false; }
    halfFloat = !!gl.getExtension('EXT_color_buffer_float') || !!gl.getExtension('EXT_color_buffer_half_float');
    gl.getExtension('OES_texture_float_linear');
    vao = gl.createVertexArray(); gl.bindVertexArray(vao);
    vbo = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    canvas.addEventListener('webglcontextlost', e => { e.preventDefault(); lost = true; });
    canvas.addEventListener('webglcontextrestored', () => { lost = false; gl = null; programs.clear(); targets.clear(); init(); });
    return true;
  }
  const VS = '#version 300 es\nin vec2 a_pos;\nvoid main(){ gl_Position = vec4(a_pos, 0.0, 1.0); }\n';
  function shader(type, src) { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); return s; }
  // Maps driver log lines back to pass-local line numbers (the pass source starts at #line 1 1).
  function cleanLog(log) {
    return String(log || '').split('\n').filter(Boolean).map(l => l.replace(/^(ERROR|WARNING): 1:(\d+):/, (m, k, n) => `${k === 'ERROR' ? 'Error' : 'Warning'} line ${n}:`).replace(/^(ERROR|WARNING): 0:(\d+):/, (m, k, n) => `${k === 'ERROR' ? 'Error' : 'Warning'} in prelude/common (line ${n}):`)).slice(0, 12).join('\n');
  }
  function linkPass(src, final, common, params) {
    const { src: fs } = buildSource(src, common, params, final);
    const v = shader(gl.VERTEX_SHADER, VS), f = shader(gl.FRAGMENT_SHADER, fs);
    const p = gl.createProgram(); gl.attachShader(p, v); gl.attachShader(p, f); gl.bindAttribLocation(p, 0, 'a_pos'); gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) {
      const log = cleanLog(gl.getShaderInfoLog(f)) || gl.getProgramInfoLog(p);
      gl.deleteProgram(p); gl.deleteShader(v); gl.deleteShader(f);
      return { error: log || 'Shader failed to compile.' };
    }
    gl.deleteShader(v); gl.deleteShader(f);
    const n = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS), uniforms = {};
    for (let i = 0; i < n; i++) { const u = gl.getActiveUniform(p, i); uniforms[u.name.replace(/\[0\]$/, '')] = gl.getUniformLocation(p, u.name); }
    return { prog: p, uniforms };
  }
  // def: { passes:[{src, scale}], common, params }. Returns { ok, error }.
  function compile(key, def) {
    if (!init()) return { ok: false, error: reason };
    if (programs.has(key)) { const e = programs.get(key); return { ok: !e.error, error: e.error }; }
    const passes = [];
    for (let i = 0; i < def.passes.length; i++) {
      const last = i === def.passes.length - 1;
      const r = linkPass(def.passes[i].src, last, def.common, def.params);
      if (r.error) { const e = { error: `Pass ${i + 1}: ${r.error}` }; programs.set(key, e); passes.forEach(x => gl.deleteProgram(x.prog)); return { ok: false, error: e.error }; }
      passes.push({ ...r, scale: Math.min(1, Math.max(0.125, def.passes[i].scale || 1)) });
    }
    programs.set(key, { passes }); return { ok: true };
  }
  function forget(prefix) {
    if (!gl) return;
    for (const [k, v] of programs) if (k.startsWith(prefix)) { (v.passes || []).forEach(x => gl.deleteProgram(x.prog)); programs.delete(k); }
    for (const [k, v] of targets) if (k.startsWith(prefix)) { gl.deleteTexture(v.tex); gl.deleteFramebuffer(v.fbo); targets.delete(k); }
  }
  function target(key, i, w, h) {
    const k = `${key}|${i}`; let t = targets.get(k);
    if (t && t.w === w && t.h === h) return t;
    if (!t) { t = { tex: gl.createTexture(), fbo: gl.createFramebuffer() }; targets.set(k, t); }
    t.w = w; t.h = h;
    gl.bindTexture(gl.TEXTURE_2D, t.tex);
    gl.texImage2D(gl.TEXTURE_2D, 0, halfFloat ? gl.RGBA16F : gl.RGBA8, w, h, 0, gl.RGBA, halfFloat ? gl.HALF_FLOAT : gl.UNSIGNED_BYTE, null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.bindFramebuffer(gl.FRAMEBUFFER, t.fbo); gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, t.tex, 0);
    // Evict: keep at most 24 render targets.
    if (targets.size > 24) { const [ok, ov] = targets.entries().next().value; if (ok !== k) { gl.deleteTexture(ov.tex); gl.deleteFramebuffer(ov.fbo); targets.delete(ok); } }
    return t;
  }
  // Render style `key` at w×h. u: { p, L, seed, safe, pal:{bg,ink,a}, params, spec }. Returns the canvas or null.
  function draw(key, w, h, u) {
    if (!init() || lost) return null;
    const entry = programs.get(key); if (!entry || entry.error) return null;
    w = Math.max(1, Math.round(w)); h = Math.max(1, Math.round(h));
    if (canvas.width < w || canvas.height < h) { canvas.width = Math.max(canvas.width, w); canvas.height = Math.max(canvas.height, h); }
    const pal = [hexToLin(u.pal.bg), hexToLin(u.pal.ink), ...u.pal.a.slice(0, 3).map(hexToLin)];
    gl.bindVertexArray(vao); gl.bindBuffer(gl.ARRAY_BUFFER, vbo); gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
    gl.disable(gl.BLEND); gl.disable(gl.DEPTH_TEST);
    const texs = [];
    entry.passes.forEach((ps, i) => {
      const last = i === entry.passes.length - 1;
      const pw = last ? w : Math.max(1, Math.round(w * ps.scale)), ph = last ? h : Math.max(1, Math.round(h * ps.scale));
      if (last) { gl.bindFramebuffer(gl.FRAMEBUFFER, null); gl.viewport(0, 0, pw, ph); gl.enable(gl.SCISSOR_TEST); gl.scissor(0, 0, pw, ph); }
      else { const t = target(key, i, pw, ph); gl.bindFramebuffer(gl.FRAMEBUFFER, t.fbo); gl.viewport(0, 0, pw, ph); gl.disable(gl.SCISSOR_TEST); texs.push(t.tex); }
      gl.useProgram(ps.prog); const U = ps.uniforms;
      if (U.u_res) gl.uniform2f(U.u_res, pw, ph);
      if (U.u_p) gl.uniform1f(U.u_p, u.p);
      if (U.u_L) gl.uniform1f(U.u_L, u.L);
      if (U.u_seed) gl.uniform1f(U.u_seed, u.seed);
      if (U.u_safe) gl.uniform1f(U.u_safe, u.safe ? 1 : 0);
      ['u_bg', 'u_ink', 'u_a0', 'u_a1', 'u_a2'].forEach((n, j) => { if (U[n]) gl.uniform3fv(U[n], pal[j]); });
      for (let b = 0; b < MAX_PASSES; b++) { const n = 'u_buf' + b; if (U[n]) { gl.activeTexture(gl.TEXTURE0 + b); gl.bindTexture(gl.TEXTURE_2D, texs[b] || null); gl.uniform1i(U[n], b); } }
      for (const [k, sp] of Object.entries(u.spec)) {
        const loc = U['p_' + k]; if (!loc) continue; const v = u.params[k];
        if (sp.type === 'range') gl.uniform1f(loc, +v);
        else if (sp.type === 'int') gl.uniform1i(loc, Math.round(v));
        else if (sp.type === 'toggle') gl.uniform1i(loc, v ? 1 : 0);
        else if (sp.type === 'select') gl.uniform1i(loc, Math.max(0, sp.options.findIndex(o => o.v === v)));
      }
      if (last) { gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT); }
      gl.drawArrays(gl.TRIANGLES, 0, 3);
    });
    gl.disable(gl.SCISSOR_TEST);
    return canvas;
  }
  // Copy the last draw (w×h, bottom-left of the GL canvas) into a 2D context at 0,0.
  function blit(ctx, w, h) { ctx.drawImage(canvas, 0, canvas.height - Math.round(h), Math.round(w), Math.round(h), 0, 0, w, h); }
  return { init, compile, forget, draw, blit, get ok() { return init(); }, get reason() { return reason; }, get halfFloat() { return halfFloat; }, canvas, hexToLin, programs };
}

return { KIT_FORMAT, KIT_LIMITS, validateKit, createGlRuntime, PRELUDE, MAIN_FINAL, MAIN_PASS, buildSource, paramUniforms, RESERVED, MAX_PASSES, hexToLin };

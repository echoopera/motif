# kit-gl v1.0.0

Owner: graphics-engineer · Imports: none · Acceptance: AC-9

The motif-kit@1 format. It covers manifest and file validation (`validateKit`, which does no DOM work), the GLSL ES 3.0 prelude (seeded hashes, looping simplex/fBm/ridged/Voronoi noise, shapes, palette ramps, premultiplied compositing, and the photosensitive-limiter helpers), and a shared WebGL2 runtime. The runtime compiles programs lazily for each style, renders up to 4 passes into half-float targets, and blits the result from the bottom-left of one shared canvas.

**Exports:** KIT_FORMAT, KIT_LIMITS, validateKit, createGlRuntime → {compile, draw, blit, forget, ok, reason}, PRELUDE, MAIN_FINAL, MAIN_PASS, buildSource, paramUniforms, hexToLin

**Rule:** A frame is a pure function of (params, palette, seed, phase). Time reaches a shader only through u_p.

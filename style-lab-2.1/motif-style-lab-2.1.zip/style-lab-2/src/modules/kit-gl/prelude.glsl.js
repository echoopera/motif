// kit-gl/prelude — the Motif Kit GLSL prelude (API motif-kit@1). Every kit pass is compiled as:
//   PRELUDE + generated param uniforms + kit common.glsl + pass source + MAIN.
// Contract for authors: time enters ONLY through u_p (loop phase 0..1). Any periodic function
// of u_p with integer frequencies loops exactly. Use the M_ helpers; never read the clock.
const PRELUDE = `#version 300 es
precision highp float;
precision highp int;
precision highp sampler2D;
uniform vec2 u_res;      // pass resolution in pixels
uniform float u_p;       // loop phase 0..1 (tempo and phase already applied)
uniform float u_L;       // effective loop duration in seconds (loop / tempo)
uniform float u_seed;    // 1..9999
uniform float u_safe;    // 1 = photosensitive-safe limiter on
uniform vec3 u_bg, u_ink, u_a0, u_a1, u_a2; // palette, linear RGB
uniform sampler2D u_buf0, u_buf1, u_buf2, u_buf3; // earlier passes of this frame
out vec4 M_out;
#define TAU 6.283185307179586
#define PI 3.141592653589793
#define M_PH (u_p * TAU)

// ---- hashing (PCG, seeded) ----
uint M_pcg(uint v) { uint s = v * 747796405u + 2891336453u; uint w = ((s >> ((s >> 28u) + 4u)) ^ s) * 277803737u; return (w >> 22u) ^ w; }
uint M_seedU() { return M_pcg(uint(u_seed) * 2654435761u); }
float M_u2f(uint x) { return float(x >> 8u) * (1.0 / 16777216.0); }
float h11(float x) { return M_u2f(M_pcg(floatBitsToUint(x + 0.0) ^ M_seedU())); }
float h21(vec2 p) { return M_u2f(M_pcg(M_pcg(floatBitsToUint(p.x + 0.0) ^ M_seedU()) ^ floatBitsToUint(p.y + 0.0))); }
vec2 h22(vec2 p) { uint a = M_pcg(M_pcg(floatBitsToUint(p.x + 0.0) ^ M_seedU()) ^ floatBitsToUint(p.y + 0.0)); return vec2(M_u2f(a), M_u2f(M_pcg(a))); }
vec3 h33(vec3 p) { uint a = M_pcg(M_pcg(M_pcg(floatBitsToUint(p.x + 0.0) ^ M_seedU()) ^ floatBitsToUint(p.y + 0.0)) ^ floatBitsToUint(p.z + 0.0)); uint b = M_pcg(a); return vec3(M_u2f(a), M_u2f(b), M_u2f(M_pcg(b))); }
vec2 M_seedOff() { return vec2(M_u2f(M_seedU()), M_u2f(M_pcg(M_seedU()))) * 173.0 - 86.0; }

// ---- small maths ----
mat2 rot(float a) { float c = cos(a), s = sin(a); return mat2(c, s, -s, c); }
float sat(float x) { return clamp(x, 0.0, 1.0); }
vec3 sat(vec3 x) { return clamp(x, 0.0, 1.0); }
float remap(float x, float a, float b) { return sat((x - a) / (b - a)); }
float smin(float a, float b, float k) { float h = sat(0.5 + 0.5 * (b - a) / k); return mix(b, a, h) - k * h * (1.0 - h); }
float smax(float a, float b, float k) { return -smin(-a, -b, k); }
float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
// Loop circle: frequency k (integer to loop), phase offset ph (0..1).
vec2 lc(float k, float ph) { float a = TAU * (k * u_p + ph); return vec2(cos(a), sin(a)); }
float lsin(float k, float ph) { return sin(TAU * (k * u_p + ph)); }
float lsaw(float k, float ph) { return fract(k * u_p + ph); }

// ---- simplex noise 3D / 4D (Ashima Arts, MIT) ----
vec4 M_mod289(vec4 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
vec3 M_mod289(vec3 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
float M_mod289(float x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
vec4 M_perm(vec4 x) { return M_mod289(((x * 34.0) + 1.0) * x); }
float M_perm(float x) { return M_mod289(((x * 34.0) + 1.0) * x); }
vec4 M_tis(vec4 r) { return 1.79284291400159 - 0.85373472095314 * r; }
float M_tis(float r) { return 1.79284291400159 - 0.85373472095314 * r; }
float snoise(vec3 v) {
  const vec2 C = vec2(1.0 / 6.0, 1.0 / 3.0); const vec4 D = vec4(0.0, 0.5, 1.0, 2.0);
  vec3 i = floor(v + dot(v, C.yyy)); vec3 x0 = v - i + dot(i, C.xxx);
  vec3 g = step(x0.yzx, x0.xyz); vec3 l = 1.0 - g; vec3 i1 = min(g.xyz, l.zxy); vec3 i2 = max(g.xyz, l.zxy);
  vec3 x1 = x0 - i1 + C.xxx; vec3 x2 = x0 - i2 + C.yyy; vec3 x3 = x0 - D.yyy;
  i = M_mod289(i);
  vec4 p = M_perm(M_perm(M_perm(i.z + vec4(0.0, i1.z, i2.z, 1.0)) + i.y + vec4(0.0, i1.y, i2.y, 1.0)) + i.x + vec4(0.0, i1.x, i2.x, 1.0));
  float n_ = 0.142857142857; vec3 ns = n_ * D.wyz - D.xzx;
  vec4 j = p - 49.0 * floor(p * ns.z * ns.z); vec4 x_ = floor(j * ns.z); vec4 y_ = floor(j - 7.0 * x_);
  vec4 x = x_ * ns.x + ns.yyyy; vec4 y = y_ * ns.x + ns.yyyy; vec4 h = 1.0 - abs(x) - abs(y);
  vec4 b0 = vec4(x.xy, y.xy); vec4 b1 = vec4(x.zw, y.zw);
  vec4 s0 = floor(b0) * 2.0 + 1.0; vec4 s1 = floor(b1) * 2.0 + 1.0; vec4 sh = -step(h, vec4(0.0));
  vec4 a0 = b0.xzyw + s0.xzyw * sh.xxyy; vec4 a1 = b1.xzyw + s1.xzyw * sh.zzww;
  vec3 p0 = vec3(a0.xy, h.x); vec3 p1 = vec3(a0.zw, h.y); vec3 p2 = vec3(a1.xy, h.z); vec3 p3 = vec3(a1.zw, h.w);
  vec4 norm = M_tis(vec4(dot(p0, p0), dot(p1, p1), dot(p2, p2), dot(p3, p3)));
  p0 *= norm.x; p1 *= norm.y; p2 *= norm.z; p3 *= norm.w;
  vec4 m = max(0.6 - vec4(dot(x0, x0), dot(x1, x1), dot(x2, x2), dot(x3, x3)), 0.0); m = m * m;
  return 42.0 * dot(m * m, vec4(dot(p0, x0), dot(p1, x1), dot(p2, x2), dot(p3, x3)));
}
vec4 M_grad4(float j, vec4 ip) {
  const vec4 ones = vec4(1.0, 1.0, 1.0, -1.0); vec4 p, s;
  p.xyz = floor(fract(vec3(j) * ip.xyz) * 7.0) * ip.z - 1.0; p.w = 1.5 - dot(abs(p.xyz), ones.xyz);
  s = vec4(lessThan(p, vec4(0.0))); p.xyz = p.xyz + (s.xyz * 2.0 - 1.0) * s.www; return p;
}
float snoise(vec4 v) {
  const vec4 C = vec4(0.138196601125011, 0.276393202250021, 0.414589803375032, -0.447213595499958);
  vec4 i = floor(v + dot(v, vec4(0.309016994374947451))); vec4 x0 = v - i + dot(i, C.xxxx);
  vec4 i0; vec3 isX = step(x0.yzw, x0.xxx); vec3 isYZ = step(x0.zww, x0.yyz);
  i0.x = isX.x + isX.y + isX.z; i0.yzw = 1.0 - isX; i0.y += isYZ.x + isYZ.y; i0.zw += 1.0 - isYZ.xy; i0.z += isYZ.z; i0.w += 1.0 - isYZ.z;
  vec4 i3 = clamp(i0, 0.0, 1.0); vec4 i2 = clamp(i0 - 1.0, 0.0, 1.0); vec4 i1 = clamp(i0 - 2.0, 0.0, 1.0);
  vec4 x1 = x0 - i1 + C.xxxx; vec4 x2 = x0 - i2 + C.yyyy; vec4 x3 = x0 - i3 + C.zzzz; vec4 x4 = x0 + C.wwww;
  i = M_mod289(i);
  float j0 = M_perm(M_perm(M_perm(M_perm(i.w) + i.z) + i.y) + i.x);
  vec4 j1 = M_perm(M_perm(M_perm(M_perm(i.w + vec4(i1.w, i2.w, i3.w, 1.0)) + i.z + vec4(i1.z, i2.z, i3.z, 1.0)) + i.y + vec4(i1.y, i2.y, i3.y, 1.0)) + i.x + vec4(i1.x, i2.x, i3.x, 1.0));
  vec4 ip = vec4(1.0 / 294.0, 1.0 / 49.0, 1.0 / 7.0, 0.0);
  vec4 p0 = M_grad4(j0, ip); vec4 p1 = M_grad4(j1.x, ip); vec4 p2 = M_grad4(j1.y, ip); vec4 p3 = M_grad4(j1.z, ip); vec4 p4 = M_grad4(j1.w, ip);
  vec4 norm = M_tis(vec4(dot(p0, p0), dot(p1, p1), dot(p2, p2), dot(p3, p3)));
  p0 *= norm.x; p1 *= norm.y; p2 *= norm.z; p3 *= norm.w; p4 *= M_tis(dot(p4, p4));
  vec3 m0 = max(0.6 - vec3(dot(x0, x0), dot(x1, x1), dot(x2, x2)), 0.0); vec2 m1 = max(0.6 - vec2(dot(x3, x3), dot(x4, x4)), 0.0);
  m0 = m0 * m0; m1 = m1 * m1;
  return 49.0 * (dot(m0 * m0, vec3(dot(p0, x0), dot(p1, x1), dot(p2, x2))) + dot(m1 * m1, vec2(dot(p3, x3), dot(p4, x4))));
}
// Loop noise: space x, travels a circle of radius r in the 4th dimension k times per loop.
float ln2(vec2 x, float k, float r) { return snoise(vec4(x + M_seedOff(), r * lc(k, 0.0))); }
float ln3(vec3 x, float k, float r) { vec2 c = r * lc(k, 0.0); return snoise(vec4(x.xy + M_seedOff(), x.z + c.x, c.y)); }
float lfbm(vec2 x, int oct, float k, float r) {
  float s = 0.0, a = 0.5; mat2 m = mat2(1.6, 1.2, -1.2, 1.6);
  for (int i = 0; i < 8; i++) { if (i >= oct) break; s += a * ln2(x, k, r); x = m * x + 11.7; a *= 0.5; }
  return s;
}
float lfbm3(vec3 x, int oct, float k, float r) {
  float s = 0.0, a = 0.5;
  for (int i = 0; i < 8; i++) { if (i >= oct) break; s += a * ln3(x, k, r); x = x * 2.02 + vec3(7.1, 3.3, 1.9); a *= 0.5; }
  return s;
}
float lridge(vec2 x, int oct, float k, float r) {
  float s = 0.0, a = 0.5; mat2 m = mat2(1.6, 1.2, -1.2, 1.6);
  for (int i = 0; i < 8; i++) { if (i >= oct) break; float n = 1.0 - abs(ln2(x, k, r)); s += a * n * n; x = m * x + 5.3; a *= 0.5; }
  return s;
}
// Loop-animated Voronoi: sites orbit their cell centre (amp) k times per loop.
// Returns (F1, F2, cell id hash); .w of M_voroId gives the nearest site's cell coords.
vec3 lvoro(vec2 x, float jit, float k, float amp) {
  vec2 n = floor(x), f = fract(x); float d1 = 8.0, d2 = 8.0, id = 0.0;
  for (int j = -1; j <= 1; j++) for (int i = -1; i <= 1; i++) {
    vec2 g = vec2(float(i), float(j)); vec2 h = h22(n + g);
    vec2 o = 0.5 + jit * (h - 0.5) + amp * lc(k, h.x) * 0.5 * (0.5 + h.y);
    float d = length(g + o - f);
    if (d < d1) { d2 = d1; d1 = d; id = h.x; } else if (d < d2) d2 = d;
  }
  return vec3(d1, d2, id);
}

// ---- shapes ----
float sdSeg(vec2 p, vec2 a, vec2 b) { vec2 pa = p - a, ba = b - a; float h = sat(dot(pa, ba) / dot(ba, ba)); return length(pa - ba * h); }
float sdBox(vec2 p, vec2 b) { vec2 d = abs(p) - b; return length(max(d, 0.0)) + min(max(d.x, d.y), 0.0); }
float sdBox3(vec3 p, vec3 b) { vec3 q = abs(p) - b; return length(max(q, 0.0)) + min(max(q.x, max(q.y, q.z)), 0.0); }
float sdTorus(vec3 p, vec2 t) { vec2 q = vec2(length(p.xz) - t.x, p.y); return length(q) - t.y; }
float glowd(float d, float w) { return w / (abs(d) + w); }
float glow2(float d, float w) { float x = d / w; return 1.0 / (1.0 + x * x); }
float gauss1(float d, float w) { return exp(-d * d / (w * w)); }
float line(float d, float w) { return 1.0 - smoothstep(w * 0.5, w * 0.5 + 1.5 / min(u_res.x, u_res.y), d); }
float aa() { return 1.5 / min(u_res.x, u_res.y); }

// ---- colour ----
vec3 ramp(float t) { // bg -> a2 -> a0 -> a1 -> ink
  t = sat(t) * 4.0;
  if (t < 1.0) return mix(u_bg, u_a2, t);
  if (t < 2.0) return mix(u_a2, u_a0, t - 1.0);
  if (t < 3.0) return mix(u_a0, u_a1, t - 2.0);
  return mix(u_a1, u_ink, t - 3.0);
}
vec3 accent(float i) { float j = mod(floor(i), 3.0); return j < 0.5 ? u_a0 : j < 1.5 ? u_a1 : u_a2; }
vec3 hot(float t) { t = max(t, 0.0); return mix(u_a2, u_a0, sat(t * 1.4)) * sat(t * 3.0) + u_ink * max(t - 0.6, 0.0) * 1.2 + u_a1 * sat(t - 1.0) * 0.5; }
vec3 aces(vec3 x) { return sat((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14)); }
vec3 bb(float T) { // approx blackbody tint, T in 1000..12000 K
  T = clamp(T, 1000.0, 40000.0) / 100.0; vec3 c;
  c.r = T <= 66.0 ? 1.0 : sat(1.2929 * pow(T - 60.0, -0.1332));
  c.g = T <= 66.0 ? sat(0.3901 * log(T) - 0.6318) : sat(1.1298 * pow(T - 60.0, -0.0755));
  c.b = T >= 66.0 ? 1.0 : (T <= 19.0 ? 0.0 : sat(0.5432 * log(T - 10.0) - 1.1963));
  return c * c;
}
// Emissive content: premultiplied, alpha = brightness (reads well over any background).
vec4 emit(vec3 c) { c = max(c, 0.0); return vec4(c, max(c.r, max(c.g, c.b))); }
vec4 solid(vec3 c, float a) { return vec4(c * a, a); }
vec4 over(vec4 top, vec4 base) { return top + base * (1.0 - top.a); }
vec4 addc(vec4 a, vec4 b) { return vec4(a.rgb + b.rgb, max(a.a, b.a)); }

// ---- time slots with the photosensitive limiter ----
// n slots per loop; when u_safe is on, at most 3 changes per second (WCAG 2.3.1).
// Under the limiter a rate can drop to 0 (frozen) when even one change per loop would exceed 3 Hz.
float M_rate(float n) { n = max(0.0, floor(n + 0.5)); return u_safe > 0.5 ? min(n, floor(3.0 * u_L)) : n; }
float tslot(float n) { float r = M_rate(n); return r < 1.0 ? 0.0 : floor(fract(u_p) * r); }
float tfrac(float n) { float r = M_rate(n); return r < 1.0 ? 0.0 : fract(fract(u_p) * r); }
// Integer cycles-per-loop for anything that flashes (beams, merger flashes): capped under the limiter.
float safeCycles(float k) { return M_rate(k); }
// Periodic strobe 0..1 at k cycles per loop (capped under the limiter), duty 0..1, soft edges.
float strobe(float k, float duty) { float r = M_rate(k); if (r < 1.0) return duty; float f = fract(u_p * r); float soft = u_safe > 0.5 ? 0.18 : 0.02; return smoothstep(0.0, soft, f) * (1.0 - smoothstep(duty, duty + soft, f)); }
// Flash intensity limiter: scales large full-field luminance swings under the safe mode.
float flashAmt(float x) { return u_safe > 0.5 ? x * 0.35 : x; }

// ---- loop envelopes ----
// Travelling pulse train along a coordinate s: k pulses per loop, phase ph, width wd (in s units).
float pulse(float s, float k, float ph, float wd) { float x = fract(s - k * u_p - ph); return exp(-x * x / (wd * wd)) + exp(-(1.0 - x) * (1.0 - x) / (wd * wd)); }
// 0 -> 1 -> 0 envelope over the loop with a hold fraction h at full.
float growEnv(float h) { float x = fract(u_p); float a = (1.0 - h) * 0.5; return smoothstep(0.0, a, x) * (1.0 - smoothstep(1.0 - a * 0.6, 1.0, x)); }

// ---- coordinates ----
vec2 M_uv(vec2 fc) { return (fc - 0.5 * u_res) / min(u_res.x, u_res.y); }
vec2 M_asp() { return u_res / min(u_res.x, u_res.y); } // half-extent*2 of uv space
vec4 buf(sampler2D b, vec2 fc) { return texture(b, fc / u_res); }
`;

const MAIN_FINAL = `
float M_dither(vec2 fc) { return M_u2f(M_pcg(uint(fc.x) * 1973u ^ M_pcg(uint(fc.y) * 9277u))) - 0.5; }
vec3 M_srgb(vec3 c) { return mix(c * 12.92, 1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055, step(0.0031308, c)); }
void main() {
  vec2 fc = gl_FragCoord.xy;
  vec4 c = motif(M_uv(fc), fc);
  if (any(isnan(c))) c = vec4(0.0);
  c = max(c, vec4(0.0));
  float a = clamp(max(c.a, max(c.r, max(c.g, c.b))), 0.0, 1.0);
  vec3 s = a > 1e-5 ? clamp(c.rgb / a, 0.0, 1.0) : vec3(0.0);
  s = M_srgb(s) + M_dither(fc) / 255.0;
  M_out = vec4(clamp(s, 0.0, 1.0) * a, a);
}
`;
const MAIN_PASS = `
void main() { vec2 fc = gl_FragCoord.xy; vec4 c = motif(M_uv(fc), fc); if (any(isnan(c))) c = vec4(0.0); M_out = c; }
`;

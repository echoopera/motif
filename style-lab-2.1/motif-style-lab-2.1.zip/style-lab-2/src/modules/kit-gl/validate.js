// kit-gl/validate — manifest + file validation for .motifkit packages (motif-kit@1).
// Pure (no DOM). Shared by the app's Kit Manager and the SDK CLI.
const KIT_FORMAT = 'motif-kit@1';
const KIT_LIMITS = { styles: 40, params: 16, passes: 4, fileBytes: 96 * 1024, kitBytes: 3 * 1024 * 1024, palettes: 8 };
const ID_RE = /^[a-z][a-z0-9-]{1,31}$/;
const KEY_RE = /^[a-z][a-zA-Z0-9]{0,23}$/;
const HEX_RE = /^#[0-9a-fA-F]{6}$/;
const SEMVER_RE = /^\d+\.\d+\.\d+$/;
const RESERVED_KITS = new Set(['core', 'motif', 'builtin', 'all']);

function validateKit(manifest, files) {
  const errors = [], warnings = [];
  const err = m => errors.push(m), warn = m => warnings.push(m);
  if (!manifest || typeof manifest !== 'object') return { ok: false, errors: ['manifest.json is missing or not an object.'], warnings };
  const m = manifest;
  if (m.format !== KIT_FORMAT) err(`format must be "${KIT_FORMAT}" (got ${JSON.stringify(m.format)}).`);
  if (!ID_RE.test(m.id || '')) err('id must be 2–32 chars: lowercase letters, digits and hyphens, starting with a letter.');
  else if (RESERVED_KITS.has(m.id)) err(`id "${m.id}" is reserved.`);
  if (!m.name || String(m.name).length > 32) err('name is required (max 32 chars).');
  if (!SEMVER_RE.test(m.version || '')) err('version must be semver, e.g. "1.0.0".');
  if (m.accent && !HEX_RE.test(m.accent)) err('accent must be a #RRGGBB colour.');
  let total = 0; for (const [k, v] of Object.entries(files || {})) { const n = typeof v === 'string' ? v.length : (v && v.byteLength) || 0; total += n; if (/\.glsl$/.test(k) && n > KIT_LIMITS.fileBytes) err(`${k} is larger than ${KIT_LIMITS.fileBytes / 1024} KB.`); }
  if (total > KIT_LIMITS.kitBytes) err(`Kit is larger than ${KIT_LIMITS.kitBytes / 1048576} MB.`);
  const fileText = p => { const v = files && files[p]; return typeof v === 'string' ? v : null; };
  const common = m.common ? fileText(m.common) : '';
  if (m.common && common == null) err(`common file "${m.common}" is not in the package.`);
  if (common && /\bvoid\s+main\s*\(/.test(common)) err('common.glsl must not define main().');
  // Palettes
  const palettes = [];
  if (m.palettes != null && !Array.isArray(m.palettes)) err('palettes must be an array.');
  (m.palettes || []).slice(0, KIT_LIMITS.palettes).forEach((p, i) => {
    const where = `palettes[${i}]`;
    if (!p || !ID_RE.test(p.id || '')) return err(`${where}.id is invalid.`);
    const cols = [p.bg, p.ink, ...(Array.isArray(p.a) ? p.a : [])];
    if (!Array.isArray(p.a) || p.a.length !== 3 || !cols.every(c => HEX_RE.test(c || ''))) return err(`${where} needs bg, ink and exactly three accents as #RRGGBB.`);
    palettes.push({ id: `${m.id}.${p.id}`, name: String(p.name || p.id).slice(0, 24), bg: p.bg.toUpperCase(), ink: p.ink.toUpperCase(), a: p.a.map(c => c.toUpperCase()), kit: m.id });
  });
  if ((m.palettes || []).length > KIT_LIMITS.palettes) warn(`Only the first ${KIT_LIMITS.palettes} palettes are used.`);
  // Styles
  const styles = [], seen = new Set();
  if (!Array.isArray(m.styles) || !m.styles.length) err('styles must be a non-empty array.');
  else if (m.styles.length > KIT_LIMITS.styles) err(`A kit can hold at most ${KIT_LIMITS.styles} styles.`);
  (Array.isArray(m.styles) ? m.styles : []).slice(0, KIT_LIMITS.styles).forEach((s, i) => {
    const where = `styles[${i}]${s && s.id ? ` (${s.id})` : ''}`;
    if (!s || !ID_RE.test(s.id || '')) return err(`${where}: id is invalid.`);
    if (seen.has(s.id)) return err(`${where}: duplicate id.`); seen.add(s.id);
    if (!s.name || String(s.name).length > 32) err(`${where}: name is required (max 32 chars).`);
    const passes = [];
    if (!Array.isArray(s.passes) || !s.passes.length || s.passes.length > KIT_LIMITS.passes) err(`${where}: passes must list 1–${KIT_LIMITS.passes} shader files.`);
    else s.passes.forEach((ps, j) => {
      const src = fileText(ps && ps.src);
      if (src == null) return err(`${where}: pass ${j + 1} file "${ps && ps.src}" is not in the package.`);
      if (!/\bvec4\s+motif\s*\(\s*vec2\s+\w+\s*,\s*vec2\s+\w+\s*\)/.test(src)) err(`${where}: ${ps.src} must define vec4 motif(vec2 uv, vec2 fc).`);
      if (/\bvoid\s+main\s*\(/.test(src)) err(`${where}: ${ps.src} must not define main(); the runtime supplies it.`);
      if (/\buniform\b/.test(src)) warn(`${where}: ${ps.src} declares its own uniforms; only params and u_ inputs are set by the runtime.`);
      const scale = ps.scale == null ? 1 : Number(ps.scale);
      if (!(scale >= 0.125 && scale <= 1)) err(`${where}: pass ${j + 1} scale must be 0.125–1.`);
      passes.push({ file: ps.src, src, scale });
    });
    const params = {};
    const raw = s.params || {};
    if (typeof raw !== 'object' || Array.isArray(raw)) err(`${where}: params must be an object.`);
    const keys = Object.keys(raw);
    if (keys.length > KIT_LIMITS.params) err(`${where}: at most ${KIT_LIMITS.params} params.`);
    for (const k of keys.slice(0, KIT_LIMITS.params)) {
      const p = raw[k], pw = `${where}.params.${k}`;
      if (!KEY_RE.test(k)) { err(`${pw}: key must be camelCase letters/digits (max 24).`); continue; }
      if (['palette', 'invert', 'tempo', 'phase', 'seed', 'zoom', 'rotate', 'loop'].includes(k)) { err(`${pw}: "${k}" is a shared parameter name.`); continue; }
      if (!p || typeof p !== 'object') { err(`${pw}: must be an object.`); continue; }
      const label = String(p.label || k).slice(0, 24), o = { label };
      if (p.unit) o.unit = String(p.unit).slice(0, 4);
      if (p.mutate != null) o.mutate = Math.max(0, Math.min(1, Number(p.mutate) || 0));
      if (p.type === 'range' || p.type === 'int') {
        const min = Number(p.min), max = Number(p.max), def = Number(p.def);
        if (![min, max, def].every(Number.isFinite) || !(min < max)) { err(`${pw}: needs numeric min < max and def.`); continue; }
        if (def < min || def > max) { err(`${pw}: def ${def} is outside ${min}–${max}.`); continue; }
        if (p.type === 'int' && ![min, max, def].every(Number.isInteger)) { err(`${pw}: int min, max and def must be integers.`); continue; }
        Object.assign(o, { type: p.type, min, max, def, step: p.type === 'int' ? 1 : Number(p.step) > 0 ? Number(p.step) : 0.01 });
      } else if (p.type === 'toggle') Object.assign(o, { type: 'toggle', def: !!p.def });
      else if (p.type === 'select') {
        const opts = (Array.isArray(p.options) ? p.options : []).map(x => (typeof x === 'string' ? { v: x, l: x[0].toUpperCase() + x.slice(1) } : x && typeof x.v === 'string' ? { v: x.v, l: String(x.l || x.v) } : null)).filter(Boolean);
        if (opts.length < 2 || opts.length > 12) { err(`${pw}: select needs 2–12 options.`); continue; }
        if (!opts.every(x => /^[a-z][a-z0-9-]{0,23}$/.test(x.v))) { err(`${pw}: option values must be lowercase ids.`); continue; }
        Object.assign(o, { type: 'select', options: opts, def: opts.some(x => x.v === p.def) ? p.def : opts[0].v });
      } else { err(`${pw}: type must be range, int, toggle or select.`); continue; }
      params[k] = o;
    }
    if (keys.length < 4) warn(`${where}: fewer than 4 params gives Mutate and Evolve little to work with.`);
    const pal = s.palette ? `${m.id}.${s.palette}` : null;
    if (pal && !palettes.some(p => p.id === pal)) warn(`${where}: palette "${s.palette}" is not defined by the kit.`);
    styles.push({ id: `${m.id}/${s.id}`, localId: s.id, name: String(s.name || s.id).slice(0, 32), blurb: String(s.blurb || '').slice(0, 160), group: String(s.group || '').slice(0, 24), tags: (Array.isArray(s.tags) ? s.tags : []).map(String).slice(0, 8), palette: pal && palettes.some(p => p.id === pal) ? pal : null, flash: !!s.flash, passes, params });
  });
  const ok = errors.length === 0;
  return { ok, errors, warnings, kit: ok ? { format: KIT_FORMAT, id: m.id, name: String(m.name), version: m.version, author: String(m.author || '').slice(0, 48), description: String(m.description || '').slice(0, 280), accent: m.accent || null, license: String(m.license || '').slice(0, 32), palettes, styles, common: common || '' } : null };
}

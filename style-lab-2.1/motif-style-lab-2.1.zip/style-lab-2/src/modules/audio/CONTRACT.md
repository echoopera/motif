# audio v1.0.0

Owner: audio-engineer · Imports: none · Acceptance: AC-6

Offline analysis at 60 envelope frames/s (FFT 2048, 8 bands, onset flux), tempo by autocorrelation + comb refinement with downbeat phase, smoothed envelope lookup, looped-region playback on the transport clock, live input.

**Exports:** analyse, detectTempo, makeEnv, barsToSeconds, createPlayer, sliceBuffer

**Rule:** Live input never reaches exports.

// shell/css — workspace styles. Layout keeps the preview pinned: on desktop only the side
// panels scroll; under 1100 px the page is a fixed shell and only the active panel scrolls.
const shellCss = `
/* kits (Style Lab 2.1) */
.style-row .glsl{color:var(--accent)}
.chip .kd{display:inline-block;width:.55em;height:.55em;border-radius:50%;margin-right:.4em;vertical-align:.05em;background:var(--kd,var(--accent))}
.lib-cat .kd{display:inline-block;width:.6em;height:.6em;border-radius:2px;margin-right:.5em;background:var(--kd,var(--accent))}
.kits{padding:var(--space-3) var(--space-4) var(--space-5);display:flex;flex-direction:column;gap:var(--space-3)}
.kit-drop{border:var(--hairline) dashed var(--line-strong);border-radius:var(--radius-m);padding:var(--space-4);display:flex;flex-direction:column;gap:var(--space-2);align-items:flex-start;background:var(--surface-2)}
.kit-drop p{margin:0;font-size:var(--text-sm);color:var(--text-muted)}
.kit-card{border:var(--hairline) solid var(--line);border-radius:var(--radius-m);overflow:hidden;background:var(--surface-1)}
.kit-card[data-off="true"] .kit-strip,.kit-card[data-off="true"] .kit-body b{opacity:.45}
.kit-strip{display:grid;grid-template-columns:repeat(6,1fr);gap:1px;background:var(--line)}
.kit-strip canvas{width:100%;aspect-ratio:16/10;display:block;background:var(--stage)}
.kit-body{padding:var(--space-3);display:flex;flex-direction:column;gap:var(--space-2)}
.kit-top{display:flex;align-items:center;gap:var(--space-2)}
.kit-top b{font:700 var(--text-lg)/1.1 var(--font-display);font-variation-settings:"wdth" 92;margin-right:auto}
.kit-top .kd{width:.8em;height:.8em;border-radius:3px;background:var(--kd,var(--accent));flex:none}
.kit-meta{font:400 var(--text-xs)/1.4 var(--font-mono);color:var(--text-muted)}
.kit-pals{display:flex;gap:var(--space-1);flex-wrap:wrap}
.kit-pals i{display:flex;border-radius:3px;overflow:hidden;border:var(--hairline) solid var(--line)}
.kit-pals i s{display:block;width:10px;height:14px}
.kit-status{font-size:var(--text-sm);border-radius:var(--radius-m);padding:var(--space-2) var(--space-3);background:var(--surface-2);white-space:pre-wrap;font-family:var(--font-mono);max-height:14em;overflow:auto}
.kit-status[data-kind="error"]{color:var(--danger);border:var(--hairline) solid var(--danger)}
.kit-status[data-kind="ok"]{color:var(--ok);border:var(--hairline) solid var(--ok)}
.kit-row{display:flex;align-items:center;justify-content:space-between;gap:var(--space-3);font-size:var(--text-sm);min-height:var(--target)}
.dropzone{position:fixed;inset:0;z-index:50;display:grid;place-items:center;background:color-mix(in srgb,var(--surface-0) 70%,transparent);backdrop-filter:blur(3px)}
.dropzone div{border:2px dashed var(--accent);border-radius:var(--radius-l,12px);padding:var(--space-6,40px) var(--space-7,56px);display:flex;flex-direction:column;align-items:center;gap:var(--space-2);background:var(--surface-1)}
.dropzone b{font:700 var(--text-xl)/1 var(--font-display)}
.dropzone span{font:400 var(--text-sm)/1 var(--font-mono);color:var(--text-muted)}

*{box-sizing:border-box}
[hidden]{display:none!important}
html,body{height:100%}
body{margin:0;background:var(--surface-0);color:var(--text);font:var(--text-md)/1.45 var(--font-ui);-webkit-font-smoothing:antialiased;overflow:hidden;overscroll-behavior:none}
button,input,select{font:inherit;color:inherit}
:focus-visible{outline:var(--focus-w) solid var(--focus);outline-offset:var(--focus-w)}
.app{height:100vh;height:100dvh;display:grid;grid-template-columns:var(--lib-w) minmax(0,1fr) var(--insp-w);grid-template-rows:var(--bar-h) auto auto minmax(0,1fr);grid-template-areas:"bar bar bar" "lib stage actions" "lib stage tabs" "lib stage insp"}
.lbl{font:500 var(--text-xs)/1.2 var(--font-mono);letter-spacing:.08em;text-transform:uppercase;color:var(--text-muted)}
.readout{font:400 var(--text-sm)/1 var(--font-mono);font-variant-numeric:tabular-nums;color:var(--text-muted);white-space:nowrap}
/* bar */
.bar{grid-area:bar;display:flex;align-items:center;gap:var(--space-3);padding-inline:var(--space-4);border-bottom:var(--hairline) solid var(--line);background:var(--surface-1);min-width:0}
.brand{display:flex;align-items:baseline;gap:var(--space-2);margin-right:auto;white-space:nowrap}
.brand .mark{font:800 var(--text-lg)/1 var(--font-display);font-variation-settings:"wdth" 130;letter-spacing:.02em}
.brand .mark i{display:inline-block;width:.45em;height:.45em;background:var(--lock);transform:rotate(45deg);margin-left:.3em;vertical-align:.1em}
.brand .sub{font:500 var(--text-xs)/1 var(--font-mono);letter-spacing:.12em;text-transform:uppercase;color:var(--text-muted)}
.seg{display:flex;border:var(--hairline) solid var(--line);border-radius:var(--radius-m);overflow:hidden;background:var(--surface-2);flex:none}
.seg button{border:0;background:transparent;padding:var(--space-1) var(--space-2);min-height:var(--target);min-width:var(--target);font:500 var(--text-sm)/1 var(--font-mono);color:var(--text-muted);cursor:pointer}
.seg button+button{border-left:var(--hairline) solid var(--line)}
.seg button[aria-checked="true"],.seg button[aria-pressed="true"]{background:var(--accent);color:var(--accent-ink)}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:var(--space-2);min-height:var(--target);padding:0 var(--space-3);border-radius:var(--radius-m);border:var(--hairline) solid var(--line);background:var(--surface-2);cursor:pointer;font-weight:600;font-size:var(--text-sm);white-space:nowrap;transition:transform var(--dur-fast) var(--ease-out),border-color var(--dur-fast)}
.btn:hover{border-color:var(--line-strong)}
.btn:active{transform:scale(.97)}
.btn[disabled]{opacity:.45;cursor:not-allowed}
.btn.primary{background:var(--accent);border-color:var(--accent);color:var(--accent-ink)}
.btn[aria-pressed="true"]{border-color:var(--accent);color:var(--accent);background:var(--accent-soft)}
.rows .seg{width:100%}
.rows .seg button{flex:1}
.btn.icon{width:var(--target);padding:0;font:600 var(--text-md)/1 var(--font-mono)}
.btn.sm{min-height:calc(var(--target) - 6px);padding:0 var(--space-2);font-size:var(--text-xs)}
.btn kbd{font:500 var(--text-xs)/1 var(--font-mono);opacity:.6}
.actions .btn{padding:0 var(--space-2)}
.actions kbd{display:none}
.chipbtn{display:inline-flex;align-items:center;gap:var(--space-1);border:var(--hairline) solid var(--line);border-radius:999em;padding:0 var(--space-2);min-height:calc(var(--target) - 4px);font:600 var(--text-xs)/1 var(--font-mono);background:var(--surface-2);color:var(--text-muted);cursor:pointer;white-space:nowrap}
.chipbtn[data-state="gpu"]{color:var(--ok);border-color:var(--ok);background:var(--ok-soft)}
.chipbtn[data-state="bpm"]{color:var(--lock);border-color:var(--lock);background:var(--lock-soft)}
.mini{display:flex;align-items:center;gap:var(--space-2)}
.aspect-sel{display:none;min-height:var(--target);font:500 var(--text-sm)/1 var(--font-mono)}
select{background:var(--surface-2);border:var(--hairline) solid var(--line);border-radius:var(--radius-s);padding:var(--space-1) var(--space-2);min-height:calc(var(--target) - var(--space-1))}
.transport{display:flex;align-items:center;gap:var(--space-2)}
/* library */
.lib{grid-area:lib;display:flex;flex-direction:column;border-right:var(--hairline) solid var(--line);background:var(--surface-1);min-height:0}
.lib-head{padding:var(--space-3);display:flex;flex-direction:column;gap:var(--space-2);border-bottom:var(--hairline) solid var(--line)}
.lib-head input{width:100%;background:var(--surface-2);border:var(--hairline) solid var(--line);border-radius:var(--radius-m);padding:var(--space-2) var(--space-3)}
.chips{display:flex;flex-wrap:wrap;gap:var(--space-1)}
.chip{border:var(--hairline) solid var(--line);background:transparent;border-radius:999em;padding:var(--space-1) var(--space-2);font:500 var(--text-xs)/1.2 var(--font-mono);color:var(--text-muted);cursor:pointer;min-height:calc(var(--target) - 8px)}
.chip[aria-pressed="true"]{background:var(--text);border-color:var(--text);color:var(--surface-1)}
.lib-note{padding:var(--space-2) var(--space-3) 0;font-size:var(--text-xs);color:var(--text-muted)}
.lib-list{list-style:none;margin:0;padding:var(--space-2);overflow:auto;flex:1;min-height:0}
.lib-cat{font:500 var(--text-xs)/1 var(--font-mono);letter-spacing:.1em;text-transform:uppercase;color:var(--text-muted);padding:var(--space-3) var(--space-2) var(--space-2)}
.style-row{display:grid;grid-template-columns:var(--thumb-w) 1fr auto;align-items:center;gap:var(--space-3);padding:var(--space-1) var(--space-2);border-radius:var(--radius-m);cursor:pointer;border:var(--hairline) solid transparent}
.style-row:hover{background:var(--surface-2)}
.style-row[aria-selected="true"]{background:var(--accent-soft);border-color:var(--accent)}
.style-row canvas{width:var(--thumb-w);height:var(--thumb-h);border-radius:var(--radius-s);display:block;background:var(--stage)}
.style-row b{font-weight:600;font-size:var(--text-md);display:block;line-height:1.2}
.style-row .n{font:400 var(--text-xs)/1 var(--font-mono);color:var(--text-muted)}
.style-row .gpu{color:var(--ok)}
.lib-empty{padding:var(--space-4);color:var(--text-muted)}
/* stage */
.stage{grid-area:stage;display:flex;flex-direction:column;min-width:0;min-height:0;background:var(--stage)}
.stage-host{flex:1;min-height:0;position:relative;display:grid;place-items:center;margin:var(--space-5) var(--space-5) var(--space-2)}
.stage-box{position:relative;line-height:0;box-shadow:var(--shadow);touch-action:none}
.stage-box canvas{display:block}
.guides{position:absolute;inset:0;pointer-events:none}
.guides i{position:absolute;border:var(--hairline) dashed var(--accent)}
.guides .action{inset:3.5%;opacity:.55}
.guides .title{inset:5%;opacity:.9}
.guides .cross{left:50%;top:50%;width:4%;height:0;border-width:var(--hairline) 0 0;transform:translate(-50%,0)}
.scrub{display:flex;align-items:center;gap:var(--space-3);padding:0 var(--space-5) var(--space-2)}
.scrub input{flex:1}
input[type=range]{accent-color:var(--accent);min-width:0;min-height:calc(var(--target) - 8px)}
.rm-hint{margin:0 var(--space-5) var(--space-2);color:var(--text);font-size:var(--text-sm)}
/* key lane */
.lane{--ph:0;border-top:var(--hairline) solid var(--line);background:var(--surface-1);display:flex;flex-direction:column;max-height:34%;min-height:0}
.lane-head{display:flex;align-items:center;gap:var(--space-2);padding:var(--space-1) var(--space-3);min-height:calc(var(--target) + 4px);flex-wrap:wrap}
.lane-head .grow{flex:1}
.lane-head select,.lane-head input{min-height:calc(var(--target) - 6px)}
.lane-head input[type=number]{width:6.5em;background:var(--surface-2);border:var(--hairline) solid var(--line);border-radius:var(--radius-s);padding:0 var(--space-2);font:var(--text-sm)/1 var(--font-mono)}
.lane-rows{overflow:auto;min-height:0;padding:0 var(--space-3) var(--space-2)}
.lane[data-collapsed="true"] .lane-rows{display:none}
.lrow{display:grid;grid-template-columns:var(--lane-label) 1fr auto;align-items:center;gap:var(--space-2);height:var(--lane-row)}
.lrow .nm{font-size:var(--text-xs);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:var(--text)}
.lrow .nm small{color:var(--text-muted);font-family:var(--font-mono)}
.track{position:relative;height:100%;border-radius:var(--radius-s);background:var(--surface-2);border:var(--hairline) solid var(--line);cursor:crosshair;touch-action:none}
.track::after{content:"";position:absolute;top:0;bottom:0;left:calc(var(--ph) * 100%);width:var(--hairline);background:var(--danger);pointer-events:none}
.track .seg-line{position:absolute;top:50%;height:2px;background:var(--accent-soft);pointer-events:none}
.track canvas{position:absolute;inset:0;width:100%;height:100%;pointer-events:none;opacity:.8}
.kf{position:absolute;top:50%;width:var(--key);height:var(--key);margin:calc(var(--key) / -2) 0 0 calc(var(--key) / -2);transform:rotate(45deg);border:1.5px solid var(--accent);background:var(--surface-2);padding:0;cursor:grab;border-radius:2px}
.kf::before{content:"";position:absolute;inset:-8px}
.kf[data-ease="hold"]{border-radius:0;background:var(--surface-1)}
.kf[aria-pressed="true"]{background:var(--accent);box-shadow:0 0 0 3px var(--accent-soft)}
.lane-empty{font-size:var(--text-sm);color:var(--text-muted);padding:var(--space-1) 0 var(--space-2)}
/* evolve */
.evolve{position:absolute;inset:0;background:var(--scrim);display:flex;flex-direction:column;gap:var(--space-3);padding:var(--space-4);z-index:3;overflow:auto}
.evolve-head{display:flex;flex-wrap:wrap;align-items:center;gap:var(--space-3);color:var(--accent-ink)}
.evolve-head h2{margin:0 auto 0 0;font:700 var(--text-lg)/1 var(--font-display);color:var(--surface-2)}
.evolve-head .btn{color:var(--text)}
.evolve-head .hint{width:100%;font-size:var(--text-sm);color:var(--surface-2);opacity:.85;margin:0}
.evolve-head label{display:flex;align-items:center;gap:var(--space-2);color:var(--surface-2);font-size:var(--text-sm)}
.evolve-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:var(--space-3)}
.child{position:relative;border:0;padding:0;background:transparent;cursor:pointer;border-radius:var(--radius-m);overflow:hidden;outline-offset:var(--focus-w)}
.child canvas{width:100%;height:auto;display:block}
.child span{position:absolute;left:var(--space-2);top:var(--space-2);font:600 var(--text-xs)/1 var(--font-mono);background:var(--surface-2);color:var(--text);padding:var(--space-1) var(--space-2);border-radius:var(--radius-s)}
.child:hover,.child:focus-visible{outline:var(--focus-w) solid var(--accent)}
/* actions + tabs + inspector */
.actions{grid-area:actions;padding:var(--space-3) var(--space-4) var(--space-2);display:grid;grid-template-columns:repeat(4,minmax(0,1fr)) auto auto;gap:var(--space-2);background:var(--surface-1);border-left:var(--hairline) solid var(--line);align-items:center}
.actions .strength{grid-column:1/-1;display:grid;grid-template-columns:auto 1fr auto;gap:var(--space-2);align-items:center;font-size:var(--text-sm)}
.actions .strength .val{font:400 var(--text-sm)/1 var(--font-mono);color:var(--text-muted)}
.tabs{grid-area:tabs;display:flex;gap:0;background:var(--surface-1);border-left:var(--hairline) solid var(--line);border-bottom:var(--hairline) solid var(--line);padding:0 var(--space-2);overflow-x:auto;scrollbar-width:none}
.tabs button{border:0;background:transparent;padding:var(--space-2) var(--space-2);flex:1 0 auto;min-height:var(--target);font:600 var(--text-sm)/1 var(--font-ui);color:var(--text-muted);cursor:pointer;border-bottom:2px solid transparent;white-space:nowrap}
.tabs button[aria-selected="true"]{color:var(--text);border-bottom-color:var(--accent)}
.tabs .mobile{display:none}
.tabs .dot{display:inline-block;width:6px;height:6px;border-radius:50%;background:var(--lock);margin-left:4px;vertical-align:.15em}
.insp{grid-area:insp;border-left:var(--hairline) solid var(--line);background:var(--surface-1);overflow:auto;min-height:0;-webkit-overflow-scrolling:touch;overscroll-behavior:contain}
.panel-head{padding:var(--space-4) var(--space-4) var(--space-3);border-bottom:var(--hairline) solid var(--line)}
.panel-head h1{margin:var(--space-1) 0;font:700 var(--text-xl)/1.05 var(--font-display);font-variation-settings:"wdth" 88}
.panel-head p{margin:0;color:var(--text-muted);font-size:var(--text-sm)}
.group{border-bottom:var(--hairline) solid var(--line)}
.group summary{list-style:none;cursor:pointer;display:flex;justify-content:space-between;align-items:center;padding:var(--space-3) var(--space-4);min-height:var(--target)}
.group summary::-webkit-details-marker{display:none}
.group summary::after{content:"+";font:400 var(--text-md)/1 var(--font-mono);color:var(--text-muted)}
.group[open] summary::after{content:"–"}
.group summary .count{margin-left:var(--space-2);color:var(--accent);font:600 var(--text-xs)/1 var(--font-mono)}
.rows{padding:0 var(--space-4) var(--space-3);display:flex;flex-direction:column;gap:var(--space-2)}
.row{display:grid;grid-template-columns:1fr auto auto auto;align-items:center;gap:var(--space-1) var(--space-2);padding:var(--space-1) 0;border-radius:var(--radius-s);transition:background var(--dur-base)}
.row label,.row .rl{font-size:var(--text-sm);color:var(--text)}
.row .val{font:400 var(--text-sm)/1 var(--font-mono);font-variant-numeric:tabular-nums;color:var(--text-muted);min-width:4.5em;text-align:right}
.row .val.anim{color:var(--accent)}
.row input[type=range]{grid-column:1/-1;width:100%}
.row select,.row input[type=text]{grid-column:1/-1;width:100%}
.row input[type=text]{background:var(--surface-2);border:var(--hairline) solid var(--line);border-radius:var(--radius-s);padding:var(--space-2)}
.row .note{grid-column:1/-1;font-size:var(--text-xs);color:var(--text-muted);margin-top:-2px}
.row .note.warn{color:var(--lock)}
.ib{display:inline-grid;place-items:center;width:calc(var(--target) - var(--space-2));height:calc(var(--target) - var(--space-2));border:var(--hairline) solid transparent;background:transparent;border-radius:var(--radius-s);cursor:pointer;color:var(--text-muted);opacity:.5;padding:0}
.row:hover .ib,.ib:focus-visible,.ib[aria-pressed="true"],.ib[data-state="anim"],.ib[data-state="on"]{opacity:1}
@media (pointer:coarse){.ib{opacity:.8}.switch{font-size:19px}.kf::before{inset:-12px}}
.lock[aria-pressed="true"]{color:var(--lock);background:var(--lock-soft);border-color:var(--lock)}
.kb[data-state="anim"]{color:var(--accent)}
.kb[data-state="on"]{color:var(--accent-ink);background:var(--accent);border-color:var(--accent)}
.row.locked{background:var(--lock-soft)}
.row.flash{background:var(--lock-soft)}
.row.mapped .rl::after,.row.mapped label::after{content:" ∿";color:var(--lock);font-family:var(--font-mono)}
.switch{appearance:none;-webkit-appearance:none;width:2.4em;height:1.35em;border-radius:999em;background:var(--line-strong);position:relative;cursor:pointer;margin:0;flex:none}
.switch::after{content:"";position:absolute;top:.15em;left:.15em;width:1.05em;height:1.05em;border-radius:50%;background:var(--surface-2);transition:transform var(--dur-fast) var(--ease-out)}
.switch:checked{background:var(--accent)}
.switch:checked::after{transform:translateX(1.05em)}
.swatches{display:grid;grid-template-columns:repeat(4,1fr);gap:var(--space-2)}
.sw{border:var(--hairline) solid var(--line);border-radius:var(--radius-s);padding:0;height:2.4em;cursor:pointer;display:grid;grid-template-columns:2fr 1fr 1fr 1fr;overflow:hidden;position:relative}
.sw i{display:block}
.sw b{position:absolute;left:3px;bottom:2px;font:600 9px/1 var(--font-mono);color:var(--text);background:var(--surface-2);padding:1px 3px;border-radius:2px;opacity:.9}
.sw[aria-checked="true"]{outline:var(--focus-w) solid var(--accent);outline-offset:var(--focus-w)}
.subhead{display:flex;align-items:center;justify-content:space-between;gap:var(--space-2);font:500 var(--text-xs)/1.2 var(--font-mono);letter-spacing:.08em;text-transform:uppercase;color:var(--text-muted);margin-top:var(--space-2)}
.slots{display:flex;flex-direction:column;gap:var(--space-2)}
.slot{display:grid;grid-template-columns:auto 1fr 6.5em auto;align-items:center;gap:var(--space-2)}
.slot input[type=color]{width:calc(var(--target) + 4px);height:var(--target);border:var(--hairline) solid var(--line);border-radius:var(--radius-s);padding:2px;background:var(--surface-2);cursor:pointer}
.slot input[type=text]{width:100%;font:var(--text-sm)/1 var(--font-mono);background:var(--surface-2);border:var(--hairline) solid var(--line);border-radius:var(--radius-s);padding:var(--space-2);text-transform:uppercase}
.slot .nm{font-size:var(--text-sm)}
.slot.locked input[type=text]{border-color:var(--lock)}
.btnrow{display:flex;flex-wrap:wrap;gap:var(--space-2)}
.btnrow .btn{flex:1 1 auto}
.contrast{font:var(--text-xs)/1.3 var(--font-mono);color:var(--text-muted)}
.contrast b{color:var(--text)}
.layers{list-style:none;margin:0;padding:0 var(--space-4) var(--space-2);display:flex;flex-direction:column;gap:var(--space-1)}
.layer{display:grid;grid-template-columns:auto 44px 1fr auto;align-items:center;gap:var(--space-2);padding:var(--space-1) var(--space-2);border:var(--hairline) solid var(--line);border-radius:var(--radius-m);background:var(--surface-2);cursor:pointer;min-height:var(--target)}
.layer[aria-selected="true"]{border-color:var(--accent);background:var(--accent-soft)}
.layer canvas{width:44px;height:28px;border-radius:var(--radius-s);display:block;background:var(--stage)}
.layer .t b{display:block;font-size:var(--text-sm);line-height:1.2}
.layer .t small{font:var(--text-xs)/1.2 var(--font-mono);color:var(--text-muted)}
.layer .eye{opacity:.8}
.layer[data-hidden="true"] .t,.layer[data-hidden="true"] canvas{opacity:.4}
.layer-tools{display:flex;gap:var(--space-1);padding:0 var(--space-4) var(--space-3);flex-wrap:wrap}
.layer-tools .btn{flex:1}
.wave{width:100%;height:64px;display:block;border-radius:var(--radius-s);background:var(--surface-2);border:var(--hairline) solid var(--line);cursor:pointer;touch-action:none}
.meters{display:grid;grid-template-columns:repeat(8,1fr);gap:var(--space-1);align-items:end;height:var(--meter-h)}
.meters i{display:block;background:var(--accent);border-radius:2px 2px 0 0;height:calc(var(--v,0) * 100%);min-height:2px;transition:height 60ms linear}
.meter-l{display:grid;grid-template-columns:repeat(8,1fr);gap:var(--space-1);font:9px/1 var(--font-mono);color:var(--text-muted);text-align:center}
.maps{display:flex;flex-direction:column;gap:var(--space-2)}
.map{border:var(--hairline) solid var(--line);border-radius:var(--radius-m);padding:var(--space-2);display:grid;grid-template-columns:1fr 1fr auto;gap:var(--space-2);align-items:center;background:var(--surface-2)}
.map .full{grid-column:1/-1;display:grid;grid-template-columns:auto 1fr auto;gap:var(--space-2);align-items:center;font-size:var(--text-xs)}
.map select{width:100%;min-width:0}
.info{font-size:var(--text-sm);color:var(--text-muted);margin:0}
.info b{color:var(--text)}
.looks{padding:0 var(--space-4) var(--space-4)}
.looks-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:var(--space-2);margin-top:var(--space-2)}
.look{position:relative;border:var(--hairline) solid var(--line);border-radius:var(--radius-s);padding:0;overflow:hidden;cursor:pointer;background:var(--stage)}
.look img{display:block;width:100%;aspect-ratio:16/9;object-fit:cover}
.look .x{position:absolute;right:0;top:0;border:0;background:var(--surface-2);color:var(--text);font:var(--text-xs)/1 var(--font-mono);padding:var(--space-1) var(--space-2);cursor:pointer;min-width:24px;min-height:24px}
.look small{position:absolute;left:0;bottom:0;right:0;font:9px/1.4 var(--font-mono);background:var(--surface-2);color:var(--text);padding:1px 4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.empty{color:var(--text-muted);font-size:var(--text-sm);margin:var(--space-2) 0 0}
.file{position:fixed;left:0;top:0;width:var(--hairline);height:var(--hairline);opacity:0;pointer-events:none}
/* dialogs */
dialog{border:var(--hairline) solid var(--line);border-radius:var(--radius-l);background:var(--surface-1);color:var(--text);padding:0;width:min(94vw,38em);max-height:92dvh;box-shadow:var(--shadow)}
dialog::backdrop{background:var(--scrim)}
.dlg-head{display:flex;justify-content:space-between;align-items:center;padding:var(--space-4);border-bottom:var(--hairline) solid var(--line)}
.dlg-head h2{margin:0;font:700 var(--text-lg)/1 var(--font-display)}
.dlg-body{padding:var(--space-4);display:flex;flex-direction:column;gap:var(--space-4)}
.formats{display:grid;grid-template-columns:repeat(auto-fill,minmax(9em,1fr));gap:var(--space-2)}
.fmt{display:flex;flex-direction:column;gap:var(--space-1);border:var(--hairline) solid var(--line);border-radius:var(--radius-m);padding:var(--space-3);cursor:pointer;text-align:left;background:var(--surface-2)}
.fmt b{font-size:var(--text-md)}
.fmt small{font-size:var(--text-xs);color:var(--text-muted)}
.fmt[aria-checked="true"]{border-color:var(--accent);box-shadow:inset 0 0 0 var(--hairline) var(--accent)}
.fmt[disabled]{opacity:.45;cursor:not-allowed}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:var(--space-3)}
.field{display:flex;flex-direction:column;gap:var(--space-1)}
.toggles{display:flex;flex-direction:column;gap:var(--space-2)}
.toggles label{display:flex;justify-content:space-between;align-items:center;gap:var(--space-3);font-size:var(--text-sm);min-height:var(--target)}
.summary{font:400 var(--text-sm)/1.5 var(--font-mono);color:var(--text-muted)}
progress{width:100%;accent-color:var(--accent)}
.dlg-foot{display:flex;justify-content:flex-end;gap:var(--space-2);padding:var(--space-4);border-top:var(--hairline) solid var(--line)}
.status{font-size:var(--text-sm)}
.status.err{color:var(--danger)}
.keys-list{display:grid;grid-template-columns:auto 1fr;gap:var(--space-2) var(--space-4);margin:0}
.keys-list dt{font:500 var(--text-sm)/1.4 var(--font-mono)}
.keys-list dd{margin:0;color:var(--text-muted);font-size:var(--text-sm)}
.toast{position:fixed;left:50%;bottom:calc(var(--space-6) + env(safe-area-inset-bottom,0px));transform:translate(-50%,var(--space-2));background:var(--text);color:var(--surface-1);padding:var(--space-2) var(--space-4);border-radius:var(--radius-m);font-size:var(--text-sm);opacity:0;pointer-events:none;transition:opacity var(--dur-base),transform var(--dur-base) var(--ease-out);z-index:10;max-width:90vw;text-align:center}
.toast.on{opacity:1;transform:translate(-50%,0)}
.sr{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}
/* ---- pinned shell under 1100 px: only the panel scrolls ---- */
@media (max-width:68.75em){
  .app{grid-template-columns:minmax(0,1fr);grid-template-rows:auto auto auto auto minmax(0,1fr);grid-template-areas:"bar" "stage" "actions" "tabs" "insp"}
  .bar{flex-wrap:wrap;padding-block:var(--space-2);row-gap:var(--space-2)}
  .stage{border-bottom:var(--hairline) solid var(--line)}
  .stage-host{flex:none;height:min(var(--stage-max),calc((100vw - 2 * var(--space-4)) / var(--ar,1.7778)));margin:var(--space-3) var(--space-4) var(--space-2)}
  .scrub{padding:0 var(--space-4) var(--space-1)}
  .lane{max-height:30dvh}
  .actions{border-left:0;grid-template-columns:repeat(4,1fr) auto auto;padding:var(--space-2) var(--space-3);border-bottom:var(--hairline) solid var(--line)}
  .actions .strength{display:none}
  .actions kbd{display:none}
  .tabs{border-left:0}
  .tabs .mobile{display:inline-block}
  .lib,.insp{grid-area:insp;border:0}
  .app:not([data-tab="library"]) .lib{display:none}
  .app[data-tab="library"] .insp{display:none}
  .lib-list{display:grid;grid-template-columns:repeat(auto-fill,minmax(14em,1fr));gap:var(--space-1)}
  .lib-cat{grid-column:1/-1}
  .evolve-grid{grid-template-columns:repeat(3,minmax(0,1fr))}
}
@media (max-width:68.75em) and (min-width:45em) and (orientation:landscape){
  .app{grid-template-columns:minmax(0,1fr) minmax(20em,38%);grid-template-rows:auto auto auto minmax(0,1fr);grid-template-areas:"bar bar" "stage actions" "stage tabs" "stage insp"}
  .stage{border-bottom:0}
  .stage-host{flex:1;height:auto}
  .lane{max-height:38%}
  .actions,.tabs,.insp,.lib{border-left:var(--hairline) solid var(--line)}
}
@media (max-width:40em){
  :root{--stage-max:36dvh}
  .brand .sub,.mini,#guidesBtn,#keysBtn,#aspects,#bpmChip{display:none!important}
  .bar{flex-wrap:nowrap;gap:var(--space-2);padding-inline:var(--space-3)}
  .brand{margin-right:auto}
  .aspect-sel{display:block}
  .readout#time{display:none}
  #resetBtn{display:none}
  .actions{grid-template-columns:repeat(3,minmax(0,1fr)) auto auto}
  .tabs button{padding:var(--space-2) var(--space-2)}
  .chipbtn{padding:0 var(--space-1)}
  .panel-head{padding:var(--space-3) var(--space-4) var(--space-2)}
  .panel-head h1{font-size:var(--text-lg)}
  .stage-host{margin:var(--space-2) var(--space-3) var(--space-1)}
  .evolve-grid{grid-template-columns:repeat(2,minmax(0,1fr))}
  .readout#perf{display:none}
  .actions .btn{padding:0 var(--space-2)}
  .lane-head .lane-extra{display:none}
  .lrow{grid-template-columns:96px 1fr auto}
}
@media (prefers-reduced-motion:reduce){*{transition:none!important}}
`;

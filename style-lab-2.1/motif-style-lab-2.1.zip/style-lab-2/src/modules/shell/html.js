// shell/html — static structure. Panels are filled by the shell at runtime.
const LOCK_SVG = '<svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true"><rect x="3" y="7" width="10" height="7" rx="1.5" fill="currentColor"/><path d="M5.5 7V5a2.5 2.5 0 0 1 5 0v2" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>';
const KEY_SVG = '<svg viewBox="0 0 16 16" width="13" height="13" aria-hidden="true"><path d="M8 1.8 14.2 8 8 14.2 1.8 8Z" fill="currentColor" fill-opacity=".18" stroke="currentColor" stroke-width="1.5"/></svg>';
const EYE_SVG = '<svg viewBox="0 0 16 16" width="15" height="15" aria-hidden="true"><path d="M1 8s2.6-4.5 7-4.5S15 8 15 8s-2.6 4.5-7 4.5S1 8 1 8Z" fill="none" stroke="currentColor" stroke-width="1.4"/><circle cx="8" cy="8" r="2.1" fill="currentColor"/></svg>';
const EYE_OFF_SVG = '<svg viewBox="0 0 16 16" width="15" height="15" aria-hidden="true"><path d="M1 8s2.6-4.5 7-4.5S15 8 15 8s-2.6 4.5-7 4.5S1 8 1 8Z" fill="none" stroke="currentColor" stroke-width="1.4" opacity=".45"/><path d="M2.5 13.5 13.5 2.5" stroke="currentColor" stroke-width="1.5"/></svg>';

const shellHtml = `
<div class="app" id="app" data-tab="layer">
  <header class="bar">
    <div class="brand"><span class="mark">MOTIF<i aria-hidden="true"></i></span><span class="sub">Style Lab 2.1</span></div>
    <div class="seg" role="radiogroup" aria-label="Aspect ratio" id="aspects"></div>
    <select id="aspectSel" class="aspect-sel" aria-label="Aspect ratio"></select>
    <div class="transport">
      <button class="btn icon" id="play" aria-label="Pause" title="Play / pause (Space)">❚❚</button>
      <span class="readout" id="time">0.00 / 6.00 s</span>
      <button class="chipbtn" id="bpmChip" hidden title="Audio tempo — open the Audio panel"></button>
    </div>
    <button class="chipbtn" id="engineChip" title="Render engine">CPU</button>
    <label class="mini"><span class="lbl">Quality</span><select id="quality" aria-label="Preview quality"><option value="auto">Auto</option><option value="high">High</option><option value="draft">Draft</option></select></label>
    <button class="btn icon" id="guidesBtn" aria-pressed="false" aria-label="Safe-area guides" title="Guides (G)">⌗</button>
    <button class="btn icon" id="keysBtn" aria-label="Keyboard shortcuts" title="Shortcuts (?)">?</button>
    <button class="btn primary" id="exportBtn" title="Export (X)">Export</button>
  </header>
  <aside class="lib" id="panel-library" aria-label="Style library">
    <div class="lib-head">
      <input type="search" id="search" placeholder="Search styles" aria-label="Search styles" autocomplete="off">
      <div class="chips" id="cats" role="group" aria-label="Filter by category"></div>
    </div>
    <p class="lib-note">Picking a style changes the selected layer.</p>
    <ul class="lib-list" id="libList" role="listbox" aria-label="Styles"></ul>
  </aside>
  <main class="stage" id="stageCol">
    <div class="stage-host" id="stageHost">
      <div class="stage-box" id="stageBox">
        <div class="guides" id="guides" hidden><i class="action"></i><i class="title"></i><i class="cross"></i></div>
      </div>
      <div class="evolve" id="evolve" hidden role="dialog" aria-modal="false" aria-labelledby="evolveTitle">
        <div class="evolve-head">
          <h2 id="evolveTitle">Evolve</h2>
          <label>Strength <input type="range" id="evoStrength" min="0.05" max="1" step="0.05" value="0.35" aria-label="Evolve strength"></label>
          <label><input type="checkbox" class="switch" id="evoColour" role="switch"> Include colour</label>
          <button class="btn" id="evoAgain">Breed again</button>
          <button class="btn" id="evoClose" aria-label="Close Evolve">Close</button>
          <p class="hint" id="evoHint">Variations of the selected layer. Pick one to keep it. Press 1–6, or Esc to close.</p>
        </div>
        <div class="evolve-grid" id="evoGrid"></div>
      </div>
    </div>
    <p class="rm-hint" id="rmHint" hidden>Paused because your system prefers reduced motion. Press Space to play.</p>
    <div class="scrub">
      <input type="range" id="scrub" min="0" max="1000" value="0" aria-label="Loop position">
      <span class="readout" id="frameRead">f 000</span>
      <span class="readout" id="perf" title="Render time per frame"></span>
    </div>
    <section class="lane" id="lane" aria-label="Keyframes" data-collapsed="false">
      <div class="lane-head" id="laneHead"></div>
      <div class="lane-rows" id="laneRows"></div>
    </section>
  </main>
  <div class="actions" id="actions">
    <button class="btn primary" id="mutateBtn" title="Mutate the selected layer (M)">Mutate <kbd>M</kbd></button>
    <button class="btn" id="evolveBtn" title="Evolve (E)">Evolve <kbd>E</kbd></button>
    <button class="btn" id="randomBtn" title="Randomize (R)">Random <kbd>R</kbd></button>
    <button class="btn" id="resetBtn" title="Reset the selected layer's style parameters">Reset</button>
    <button class="btn icon" id="undoBtn" title="Undo (⌘Z)" aria-label="Undo">↺</button>
    <button class="btn icon" id="redoBtn" title="Redo (⇧⌘Z)" aria-label="Redo">↻</button>
    <div class="strength"><label for="strength">Mutation strength</label><input type="range" id="strength" min="0.05" max="1" step="0.05" value="0.35"><output class="val" id="strengthVal">0.35</output></div>
  </div>
  <nav class="tabs" role="tablist" aria-label="Panels" id="tabs">
    <button role="tab" class="mobile" data-tab="library" aria-selected="false" aria-controls="panel-library">Library</button>
    <button role="tab" data-tab="layer" aria-selected="true" aria-controls="panel-layer">Layers</button>
    <button role="tab" data-tab="colour" aria-selected="false" aria-controls="panel-colour">Colour</button>
    <button role="tab" data-tab="finish" aria-selected="false" aria-controls="panel-finish">Finish</button>
    <button role="tab" data-tab="audio" aria-selected="false" aria-controls="panel-audio">Audio</button>
    <button role="tab" data-tab="looks" aria-selected="false" aria-controls="panel-looks">Looks</button>
    <button role="tab" data-tab="kits" aria-selected="false" aria-controls="panel-kits">Kits</button>
  </nav>
  <aside class="insp" id="insp" aria-label="Inspector">
    <section role="tabpanel" id="panel-layer" data-panel="layer"></section>
    <section role="tabpanel" id="panel-colour" data-panel="colour" hidden></section>
    <section role="tabpanel" id="panel-finish" data-panel="finish" hidden></section>
    <section role="tabpanel" id="panel-audio" data-panel="audio" hidden></section>
    <section role="tabpanel" id="panel-kits" data-panel="kits" hidden></section>
    <section role="tabpanel" id="panel-looks" data-panel="looks" hidden>
      <div class="panel-head"><div class="lbl">Library</div><h1>Saved looks</h1><p>Whole projects: layers, keys, colour, finish and audio maps.</p></div>
      <div class="looks">
        <div class="btnrow">
          <button class="btn" id="saveLook" title="Save look (S)">Save look</button>
          <button class="btn" id="importBtn">Import preset</button>
          <button class="btn" id="exportPresetBtn">Preset JSON</button>
          <input type="file" id="importFile" class="file" accept="application/json,.json" tabindex="-1" aria-hidden="true">
        </div>
        <div class="looks-grid" id="looks"></div>
        <p class="empty" id="looksEmpty">Saved looks appear here. Press S to save the current look.</p>
      </div>
    </section>
  </aside>
</div>
<input type="file" id="kitFile" class="file" accept=".motifkit,.zip,application/zip,application/json,.json" multiple tabindex="-1" aria-hidden="true">
<div class="dropzone" id="dropzone" hidden><div><b>Drop to install</b><span>.motifkit packages or kit JSON bundles</span></div></div>
<input type="file" id="imgFile" class="file" accept="image/*" tabindex="-1" aria-hidden="true">
<input type="file" id="audioFile" class="file" accept="audio/*,.mp3,.wav,.m4a,.aac,.ogg,.flac" tabindex="-1" aria-hidden="true">
<dialog id="exportDlg" aria-labelledby="exportTitle">
  <div class="dlg-head"><h2 id="exportTitle">Export</h2><button class="btn icon" id="exportClose" aria-label="Close">✕</button></div>
  <div class="dlg-body">
    <div class="field"><span class="lbl">Format</span><div class="formats" id="formats" role="radiogroup" aria-label="Format"></div></div>
    <div class="grid2">
      <label class="field"><span class="lbl">Aspect</span><select id="exAspect"></select></label>
      <label class="field"><span class="lbl">Size</span><select id="exTier"></select></label>
      <label class="field"><span class="lbl">Frame rate</span><select id="exFps"></select></label>
      <label class="field"><span class="lbl">Loops</span><select id="exLoops"><option>1</option><option>2</option><option>3</option><option>4</option><option>8</option></select></label>
      <label class="field"><span class="lbl">Colour space</span><select id="exSpace"></select></label>
      <div class="field"><span class="lbl">Motion blur</span><span class="summary" id="exBlur"></span></div>
    </div>
    <div class="toggles">
      <label><span>Transparent background</span><input type="checkbox" class="switch" id="exAlpha" role="switch"></label>
      <label><span>Broadcast-safe limiter</span><input type="checkbox" class="switch" id="exLegal" role="switch"></label>
      <label id="exAudioRow"><span>Include audio</span><input type="checkbox" class="switch" id="exAudio" role="switch"></label>
    </div>
    <div class="summary" id="exSummary"></div>
    <progress id="exProgress" max="1" value="0" hidden></progress>
    <div class="status" id="exStatus" role="status" aria-live="polite"></div>
  </div>
  <div class="dlg-foot"><button class="btn" id="exCancel">Cancel</button><button class="btn" id="exSave" hidden>Save file</button><button class="btn primary" id="exRender">Render</button></div>
</dialog>
<dialog id="keysDlg" aria-labelledby="keysTitle">
  <div class="dlg-head"><h2 id="keysTitle">Keyboard shortcuts</h2><button class="btn icon" id="keysClose" aria-label="Close">✕</button></div>
  <div class="dlg-body"><dl class="keys-list">
    <dt>Space</dt><dd>Play / pause (with audio when a track is loaded)</dd><dt>← →</dt><dd>Step one frame (Shift: ten)</dd><dt>[ ]</dt><dd>Previous / next style for the selected layer</dd>
    <dt>1–6</dt><dd>Aspect ratio (in Evolve: keep variation)</dd><dt>M · E · R</dt><dd>Mutate · Evolve · Randomize the selected layer</dd>
    <dt>K</dt><dd>Show or hide the key lane</dd><dt>Delete</dt><dd>Remove the selected key</dd><dt>Alt + ← →</dt><dd>Nudge the selected key one frame</dd>
    <dt>⌘Z / ⇧⌘Z</dt><dd>Undo / redo</dd><dt>S</dt><dd>Save look</dd><dt>G</dt><dd>Safe-area guides</dd><dt>X</dt><dd>Export</dd><dt>?</dt><dd>This list</dd>
    <dt>◇ on a row</dt><dd>Key that value at the playhead; edit a keyed value to add a key</dd><dt>Double-click slider</dt><dd>Reset that value</dd>
  </dl></div>
</dialog>
<div class="toast" id="toast" role="status" aria-live="polite"></div>
`;

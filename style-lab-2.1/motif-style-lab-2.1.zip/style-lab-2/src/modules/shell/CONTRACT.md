# shell v2.0.0

Owner: creative-tools-designer · Imports: tokens, engine-core, style-library, colour, timeline, audio, gpu-engine, compositor, finish, renderer, exporter · Acceptance: AC-1, AC-2, AC-3, AC-4, AC-5, AC-6, AC-7, AC-8

Workspace UI: library, pinned stage, key lane, Layers/Colour/Finish/Audio/Looks panels, Evolve, export dialog, keyboard, and window.__lab test hooks.

**Exports:** boot()

**Rule:** Pinned preview: only side panels (desktop) or the active panel (under 1100 px) scroll.

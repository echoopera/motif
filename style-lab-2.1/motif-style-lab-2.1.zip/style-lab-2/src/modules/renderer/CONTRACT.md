# renderer v2.0.0

Owner: web-engineer · Imports: tokens, engine-core, style-library, timeline, compositor, finish, colour · Acceptance: AC-1, AC-7

Frame pipeline (evaluate → layers → motion blur → finish), stage loop with optional audio clock and colour-space canvas swap, thumbnails, export sizing and exact-loop frame timing.

**Exports:** createPipeline, createStage, renderThumb, renderProjectThumb, exportSize, aspectRatio, frameCount, frameTime, framesPerLoop



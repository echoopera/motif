// renderer — the frame pipeline (evaluate → layers → motion blur → finishing), the stage loop
// with an optional audio clock, library thumbnails and export sizing.
const { ASPECTS } = __m_tokens;
const { mulberry32, hash, memo, makeCanvas, fract } = __m_engine_core;
const { evaluate } = __m_timeline;
const { createCompositor } = __m_compositor;
const { createFinisher, needsGpu } = __m_finish;
const { resolvePalette, gradientStops, hexToRgb01 } = __m_colour;

function grainTile(light, dark) {
  return memo(`grain|${light}|${dark}`, () => {
    const c = makeCanvas(256, 256), x = c.getContext('2d'), rng = mulberry32(99);
    for (let i = 0; i < 9000; i++) { x.globalAlpha = 0.25 + rng() * 0.75; x.fillStyle = rng() < 0.5 ? light : dark; x.fillRect(Math.floor(rng() * 256), Math.floor(rng() * 256), 1, 1); }
    return c;
  });
}
// Canvas 2D finish (grain + vignette) for when no GPU pass is needed or WebGL2 is missing.
function cpuFinish(ctx, w, h, f, pal, t, transparent) {
  ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = 1;
  if (f.vignette > 0 && !transparent) {
    const D = Math.hypot(w, h) / 2, g = ctx.createRadialGradient(w / 2, h / 2, D * 0.35, w / 2, h / 2, D);
    g.addColorStop(0, pal.alpha(pal.shade, 0)); g.addColorStop(1, pal.alpha(pal.shade, f.vignette * 0.7));
    ctx.globalCompositeOperation = 'source-atop'; ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
  }
  if (f.grain > 0) {
    const tile = grainTile(pal.grainLight, pal.grainDark), sc = Math.max(1, Math.min(w, h) / 720);
    const fi = Math.floor(fract(t / f.loop) * f.loop * 24), ox = hash(fi, 1) * 256, oy = hash(fi, 2) * 256;
    ctx.globalCompositeOperation = 'source-atop'; ctx.globalAlpha = f.grain * 0.55; ctx.scale(sc, sc);
    for (let y = -oy; y < h / sc; y += 256) for (let x = -ox; x < w / sc; x += 256) ctx.drawImage(tile, x, y);
  }
  ctx.restore();
}

// WebGPU → Canvas 2D → WebGL hand-offs are not always ordered; a 1-pixel read makes the 2D canvas
// finish its pending draws before WebGL samples it.
function syncCanvas(c) { try { c._ctx.getImageData(0, 0, 1, 1); } catch (e) { /* tainted or unavailable */ } }

// One pipeline per page: shares the GPU engine, the WebGL2 finisher and scratch canvases.
function createPipeline({ gpu }) {
  const compositor = createCompositor({ gpu });
  const finisher = createFinisher();
  // Render project at time t into ctx (w×h). opts: { transparent, env, preview, previewSamples, space, zebra, cpu, onError }
  function renderFrame(ctx, w, h, project, t, opts = {}) {
    const out = project.output, space = opts.space || out.space;
    const ev0 = evaluate(project, t, opts.env), f = ev0.finish;
    let samples = f.shutter > 0 ? f.samples : 1;
    if (opts.preview && samples > 1) samples = Math.max(2, Math.min(samples, opts.previewSamples || 4));
    const zebra = !!opts.zebra, legal = !!out.broadcastSafe;
    const gpuPost = finisher.ok && (needsGpu(f, { broadcastSafe: legal, zebra }) || samples > 1);
    const common = { transparent: opts.transparent, space, customs: project.palettes, cpu: opts.cpu, onError: opts.onError };
    let pal, engines = [];
    if (!gpuPost && samples === 1) {
      const r = compositor.renderEvaluated(ctx, w, h, ev0, t, common); pal = r.pal; engines = r.engines;
      cpuFinish(ctx, w, h, f, pal, t, opts.transparent);
      return { u: ev0.u, engines, samples, post: 'cpu' };
    }
    const comp = compositor.scratch('comp', w, h, space);
    const fps = out.fps || 30;
    if (samples > 1) {
      const acc = finisher.ok ? null : compositor.scratch('acc', w, h, space);
      if (finisher.ok) { finisher.setSpace(space); finisher.beginAccum(w, h); }
      else acc._ctx.clearRect(0, 0, w, h);
      for (let k = 0; k < samples; k++) {
        const tk = t + ((k + 0.5) / samples - 0.5) * (f.shutter / 360) / fps;
        const r = compositor.renderEvaluated(comp._ctx, w, h, k === Math.floor(samples / 2) && samples % 2 ? ev0 : evaluate(project, tk, opts.env), tk, common);
        if (k === 0) { pal = r.pal; engines = r.engines; }
        if (finisher.ok) { if (r.engines.includes('gpu')) syncCanvas(comp); finisher.addAccum(comp, 1 / samples); }
        else { acc._ctx.globalAlpha = 1 / (k + 1); acc._ctx.drawImage(comp, 0, 0); acc._ctx.globalAlpha = 1; }
      }
      if (!finisher.ok) { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, w, h); ctx.drawImage(acc, 0, 0); ctx.restore(); cpuFinish(ctx, w, h, f, pal, t, opts.transparent); return { u: ev0.u, engines, samples, post: 'cpu' }; }
    } else {
      const r = compositor.renderEvaluated(comp._ctx, w, h, ev0, t, common); pal = r.pal; engines = r.engines;
      if (engines.includes('gpu')) syncCanvas(comp);
      finisher.setSpace(space); finisher.loadInput(comp, w, h);
    }
    const stops = gradientStops(pal, f.gmapMode).map(hexToRgb01);
    const glc = finisher.process(f, { stops, shade: hexToRgb01(pal.shade), frame: Math.floor(fract(t / f.loop) * f.loop * 24), legal, zebra });
    ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalCompositeOperation = 'copy'; ctx.drawImage(glc, 0, 0, w, h); ctx.restore();
    return { u: ev0.u, engines, samples, post: 'gpu' };
  }
  return { renderFrame, compositor, finisher };
}

function exportSize(aspectId, tier) {
  const a = ASPECTS.find(x => x.id === aspectId) || ASPECTS[0];
  const short = tier; const even = v => Math.round(v / 2) * 2;
  return a.w >= a.h ? { w: even((short * a.w) / a.h), h: short } : { w: short, h: even((short * a.h) / a.w) };
}
function aspectRatio(aspectId) { const a = ASPECTS.find(x => x.id === aspectId) || ASPECTS[0]; return a.w / a.h; }
// Frames per loop are rounded to whole frames; frame times are spread across the exact loop so every
// loop closes seamlessly even when a bar-snapped length is not frame-aligned (rate error < 0.5 frame per loop).
function framesPerLoop(project, fps) { return Math.max(1, Math.round(project.finish.loop * fps)); }
function frameCount(project, fps, loops) { return framesPerLoop(project, fps) * loops; }
function frameTime(project, fps, i) { return (i / framesPerLoop(project, fps)) * project.finish.loop; }

// Library / Evolve thumbnail of one look (no finish, Canvas 2D so the GPU stays free for the stage).
function renderThumb(pipeline, canvas, look, p, customs) {
  const ctx = canvas.getContext('2d'); const L = look.shared.loop || 6;
  const t = fract(((p - (look.shared.phase || 0)) / (look.shared.tempo || 1))) * L;
  const pal = resolvePalette(look.shared.palette, look.shared.invert, customs || []);
  pipeline.compositor.renderLook(ctx, canvas.width, canvas.height, look, t, pal, { bg: true, cpu: true });
}
function renderProjectThumb(pipeline, canvas, project, t) {
  pipeline.renderFrame(canvas.getContext('2d'), canvas.width, canvas.height, { ...project, finish: { ...project.finish, shutter: 0 } }, t, { cpu: true });
}

// Stage: owns the preview canvas and the loop. clock() may return transport time from audio.
function createStage({ host, box, pipeline, getProject, onTick, onError, clock, env, extras }) {
  let canvas = null, ctx = null, space = 'srgb';
  let aspect = '16x9', quality = 'auto', playing = true, t = 0, last = 0, raf = 0, cssW = 0, cssH = 0, dirty = true;
  const timings = []; let lastInfo = null;
  function makeCanvasEl() {
    const c = document.createElement('canvas'); c.id = 'stage'; c.setAttribute('role', 'img'); c.setAttribute('aria-label', 'Animation preview');
    if (canvas) { c.setAttribute('aria-label', canvas.getAttribute('aria-label')); canvas.replaceWith(c); } else box.prepend(c);
    canvas = c; ctx = c.getContext('2d', { colorSpace: space === 'p3' ? 'display-p3' : 'srgb' }); layout();
  }
  const dprFor = () => { const d = window.devicePixelRatio || 1; return quality === 'draft' ? 0.6 : quality === 'high' ? Math.min(d, 2) : Math.min(d, 1.5); };
  function layout() {
    const r = host.getBoundingClientRect(); const ar = aspectRatio(aspect);
    let w = r.width, h = w / ar; if (h > r.height) { h = r.height; w = h * ar; }
    cssW = Math.max(1, Math.floor(w)); cssH = Math.max(1, Math.floor(h));
    canvas.style.width = cssW + 'px'; canvas.style.height = cssH + 'px';
    box.style.width = cssW + 'px'; box.style.height = cssH + 'px';
    const d = dprFor(); canvas.width = Math.max(2, Math.round(cssW * d)); canvas.height = Math.max(2, Math.round(cssH * d));
    dirty = true;
  }
  const ro = new ResizeObserver(() => layout());
  function draw() {
    const pr = getProject(); const t0 = performance.now();
    try { lastInfo = pipeline.renderFrame(ctx, canvas.width, canvas.height, pr, t, { preview: playing, previewSamples: quality === 'high' ? 8 : 4, env: env && env(), zebra: extras && extras.zebra, onError }); }
    catch (e) { if (onError) onError(e); }
    timings.push(performance.now() - t0); if (timings.length > 60) timings.shift();
    dirty = false; if (onTick) onTick(t, lastInfo);
  }
  function frame(now) {
    raf = requestAnimationFrame(frame);
    const L = getProject().finish.loop;
    const dt = last ? Math.min(0.1, (now - last) / 1000) : 0; last = now;
    if (playing) { const ct = clock ? clock() : null; t = ct != null ? ct % L : (t + dt) % L; dirty = true; }
    else if (extras && extras.live && extras.live()) dirty = true;
    if (dirty) draw();
  }
  makeCanvasEl(); ro.observe(host); raf = requestAnimationFrame(frame);
  const loopLen = () => getProject().finish.loop;
  return {
    setAspect(a) { aspect = a; layout(); }, get aspect() { return aspect; },
    setQuality(q) { quality = q; layout(); },
    setSpace(s) { if (s === space) return; space = s; makeCanvasEl(); },
    get canvas() { return canvas; },
    play() { playing = true; last = 0; }, pause() { playing = false; dirty = true; },
    toggle() { playing = !playing; last = 0; dirty = true; return playing; },
    get playing() { return playing; }, get time() { return t; }, get info() { return lastInfo; },
    seek(frac) { t = Math.min(0.999999, Math.max(0, frac)) * loopLen(); dirty = true; },
    seekTime(s) { const L = loopLen(); t = ((s % L) + L) % L; dirty = true; },
    step(frames, fps = 30) { const L = loopLen(); t = (((t + frames / fps) % L) + L) % L; dirty = true; },
    invalidate() { dirty = true; },
    frameMs() { return timings.length ? timings.reduce((a, b) => a + b, 0) / timings.length : 0; },
    size() { return { w: canvas.width, h: canvas.height, cssW, cssH }; },
    destroy() { cancelAnimationFrame(raf); ro.disconnect(); },
  };
}

return { createPipeline, exportSize, aspectRatio, frameCount, frameTime, framesPerLoop, renderThumb, renderProjectThumb, createStage };

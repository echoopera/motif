// exporter — frame-accurate renders of a v2 project to MP4 / WebM (WebCodecs + muxers) with
// colour-space tags and optional audio, PNG sequence ZIP, single PNG and preset@2 JSON.
// Imports preset@1 (v1 looks) and preset@2. Uses globals Mp4Muxer, WebMMuxer and fflate.
const { exportSize, frameCount, frameTime } = __m_renderer;
const { getStyle } = __m_style_library;
const { makeCanvas } = __m_engine_core;
const { FORMAT, sanitizeProject, fromV1, clone } = __m_timeline;
const { spaceById, sanitizeCustom } = __m_colour;
const { sliceBuffer } = __m_audio;
const V1_FORMAT = 'motif-style-lab/preset@1';
const TIERS = [720, 1080, 1440, 2160];
const FPS = [24, 25, 30, 50, 60];

const g = typeof globalThis !== 'undefined' ? globalThis : window;
let capsPromise = null;
async function supported(cfg) { try { const r = await g.VideoEncoder.isConfigSupported(cfg); return !!r.supported; } catch (e) { return false; } }
async function audioSupported(cfg) { try { const r = await g.AudioEncoder.isConfigSupported(cfg); return !!r.supported; } catch (e) { return false; } }

function probeCapabilities() {
  if (capsPromise) return capsPromise;
  capsPromise = (async () => {
    const caps = { webcodecs: typeof g.VideoEncoder === 'function' && typeof g.VideoFrame === 'function', mp4: null, webm: null, webmAlpha: false, recorder: typeof g.MediaRecorder === 'function', zip: !!g.fflate, muxers: !!g.Mp4Muxer && !!g.WebMMuxer, aac: false, opus: false, p3: false };
    if (caps.webcodecs && caps.muxers) {
      const base = { width: 1920, height: 1080, bitrate: 12e6, framerate: 30 };
      for (const c of ['avc1.640033', 'avc1.4d0033', 'avc1.42e033']) if (await supported({ ...base, codec: c })) { caps.mp4 = c; break; }
      for (const c of ['vp09.00.41.08', 'vp8']) if (await supported({ ...base, codec: c })) { caps.webm = c; break; }
      if (caps.webm) caps.webmAlpha = await supported({ ...base, codec: caps.webm, alpha: 'keep' });
    }
    if (typeof g.AudioEncoder === 'function') {
      caps.aac = await audioSupported({ codec: 'mp4a.40.2', sampleRate: 48000, numberOfChannels: 2, bitrate: 192000 });
      caps.opus = await audioSupported({ codec: 'opus', sampleRate: 48000, numberOfChannels: 2, bitrate: 160000 });
    }
    try { caps.p3 = document.createElement('canvas').getContext('2d', { colorSpace: 'display-p3' }).getContextAttributes().colorSpace === 'display-p3'; } catch (e) { caps.p3 = false; }
    return caps;
  })();
  return capsPromise;
}

function slug(project) { return project.layers.map(l => l.styleId).join('+').slice(0, 60); }
function fileName(project, s, ext) {
  const { w, h } = exportSize(s.aspect, s.tier);
  const sp = project.output.space === 'srgb' ? '' : `-${project.output.space}`;
  return `motif-${slug(project)}-${s.aspect}-${w}x${h}${ext === 'png' || ext === 'json' ? '' : `-${s.fps}fps`}${ext === 'json' ? '' : sp}.${ext}`;
}
function presetJSON(project, aspect) {
  const p = clone(project); delete p.active;
  return JSON.stringify({ format: FORMAT, styles: project.layers.map(l => getStyle(l.styleId).name), aspect, project: p }, null, 2);
}
function parsePreset(text) {
  let data; try { data = JSON.parse(text); } catch (e) { throw new Error('it isn’t valid JSON'); }
  if (data && data.format === V1_FORMAT && data.look && data.look.styleId) return fromV1(data.look, data.aspect);
  if (data && data.format === FORMAT && data.project) return { project: sanitizeProject(data.project, sanitizeCustom), aspect: data.aspect || '16x9' };
  throw new Error('the format tag is missing or unknown');
}

const tick = () => new Promise(r => setTimeout(r, 0));
// RGBA (straight alpha) → I420 / I420A planes with BT.709 coefficients, limited or full range.
function toI420(rgba, w, h, fullRange, withAlpha) {
  const Kr = 0.2126, Kb = 0.0722, Kg = 1 - Kr - Kb;
  const yS = fullRange ? 255 : 219, yO = fullRange ? 0 : 16, cS = fullRange ? 255 : 224;
  const cw = w >> 1, ch = h >> 1, ySize = w * h, cSize = cw * ch;
  const out = new Uint8Array(ySize + 2 * cSize + (withAlpha ? ySize : 0));
  const U = ySize, V = ySize + cSize, A = ySize + 2 * cSize;
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const i = (y * w + x) * 4; out[y * w + x] = yO + yS * (Kr * rgba[i] + Kg * rgba[i + 1] + Kb * rgba[i + 2]) / 255 + 0.5; if (withAlpha) out[A + y * w + x] = rgba[i + 3]; }
  for (let y = 0; y < ch; y++) for (let x = 0; x < cw; x++) {
    let r = 0, g = 0, b = 0;
    for (let dy = 0; dy < 2; dy++) for (let dx = 0; dx < 2; dx++) { const i = ((2 * y + dy) * w + 2 * x + dx) * 4; r += rgba[i]; g += rgba[i + 1]; b += rgba[i + 2]; }
    r /= 1020; g /= 1020; b /= 1020; const Y = Kr * r + Kg * g + Kb * b;
    out[U + y * cw + x] = Math.max(0, Math.min(255, 128 + cS * (b - Y) / (2 * (1 - Kb)) + 0.5));
    out[V + y * cw + x] = Math.max(0, Math.min(255, 128 + cS * (r - Y) / (2 * (1 - Kr)) + 0.5));
  }
  return out;
}
const abortErr = () => { const e = new Error('Export cancelled'); e.name = 'AbortError'; return e; };
function makeExportCanvas(w, h, space) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const ctx = c.getContext('2d', { colorSpace: spaceById(space).canvas, willReadFrequently: true, alpha: true });
  return { c, ctx };
}

// Resample to 48 kHz stereo for the encoders.
async function audioFor(buffer, start, dur) {
  const sl = sliceBuffer(buffer, start, dur);
  const OAC = g.OfflineAudioContext || g.webkitOfflineAudioContext;
  const frames = Math.ceil(dur * 48000);
  const oac = new OAC(2, frames, 48000); const b = oac.createBuffer(sl.channels.length, sl.frames, sl.sampleRate);
  sl.channels.forEach((d, i) => b.copyToChannel(d, i));
  const src = oac.createBufferSource(); src.buffer = b; src.connect(oac.destination); src.start();
  const out = await oac.startRendering();
  return [out.getChannelData(0), out.getChannelData(out.numberOfChannels > 1 ? 1 : 0)];
}

async function encodeVideo(pipeline, project, s, caps, env, audio, onProgress, signal) {
  const { w, h } = exportSize(s.aspect, s.tier); const N = frameCount(project, s.fps, s.loops);
  const isMp4 = s.format === 'mp4', alpha = !isMp4 && s.transparent && caps.webmAlpha;
  const space = spaceById(project.output.space);
  const { c: canvas, ctx } = makeExportCanvas(w, h, space.id);
  const M = isMp4 ? g.Mp4Muxer : g.WebMMuxer;
  const acodec = audio ? (isMp4 ? (caps.aac ? 'aac' : caps.opus ? 'opus' : null) : (caps.opus ? 'opus' : null)) : null;
  const muxOpts = isMp4
    ? { target: new M.ArrayBufferTarget(), video: { codec: 'avc', width: w, height: h, frameRate: s.fps }, fastStart: 'in-memory', ...(acodec ? { audio: { codec: acodec, sampleRate: 48000, numberOfChannels: 2 } } : {}) }
    : { target: new M.ArrayBufferTarget(), video: { codec: caps.webm === 'vp8' ? 'V_VP8' : 'V_VP9', width: w, height: h, frameRate: s.fps, alpha }, ...(acodec ? { audio: { codec: 'A_OPUS', sampleRate: 48000, numberOfChannels: 2 } } : {}) };
  const muxer = new M.Muxer(muxOpts);
  let failure = null, reportedSpace = null;
  const enc = new g.VideoEncoder({ output: (chunk, meta) => { if (meta && meta.decoderConfig) { reportedSpace = meta.decoderConfig.colorSpace || null; meta = { ...meta, decoderConfig: { ...meta.decoderConfig, colorSpace: { ...space.video } } }; } muxer.addVideoChunk(chunk, meta); }, error: e => { failure = e; } });
  enc.configure({ codec: isMp4 ? caps.mp4 : caps.webm, width: w, height: h, bitrate: Math.round(w * h * s.fps * 0.16), framerate: s.fps, latencyMode: 'quality', ...(alpha ? { alpha: 'keep' } : {}), ...(isMp4 ? { avc: { format: 'avc' } } : {}) });
  const ropts = { transparent: !isMp4 && s.transparent, env, space: space.id };
  pipeline.renderFrame(ctx, w, h, project, 0, ropts); // warm-up: scratch canvases settle before frame 0
  for (let i = 0; i < N; i++) {
    if (signal && signal.aborted) { try { enc.close(); } catch (e) { /* closed */ } throw abortErr(); }
    if (failure) throw failure;
    pipeline.renderFrame(ctx, w, h, project, frameTime(project, s.fps, i), ropts);
    const img = ctx.getImageData(0, 0, w, h);
    const yuv = toI420(img.data, w, h, space.video.fullRange, alpha);
    const frame = new g.VideoFrame(yuv, { format: alpha ? 'I420A' : 'I420', codedWidth: w, codedHeight: h, timestamp: Math.round((i * 1e6) / s.fps), duration: Math.round(1e6 / s.fps), colorSpace: space.video });
    enc.encode(frame, { keyFrame: i % (s.fps * 2) === 0 }); frame.close();
    while (enc.encodeQueueSize > 4) await tick();
    onProgress && onProgress((i + 1) / N * (acodec ? 0.95 : 1), `Rendering frame ${i + 1} of ${N}`);
    if (i % 3 === 0) await tick();
  }
  onProgress && onProgress(acodec ? 0.95 : 1, 'Finishing video');
  await enc.flush(); enc.close(); if (failure) throw failure;
  let audioNote = '';
  if (audio && acodec) {
    onProgress && onProgress(0.96, 'Encoding audio');
    const [L, R] = await audioFor(audio.buffer, audio.offset, N / s.fps);
    let aerr = null;
    const aenc = new g.AudioEncoder({ output: (chunk, meta) => muxer.addAudioChunk(chunk, meta), error: e => { aerr = e; } });
    aenc.configure({ codec: acodec === 'aac' ? 'mp4a.40.2' : 'opus', sampleRate: 48000, numberOfChannels: 2, bitrate: acodec === 'aac' ? 192000 : 160000 });
    const block = 4800;
    for (let off = 0; off < L.length; off += block) {
      const n = Math.min(block, L.length - off), data = new Float32Array(n * 2); data.set(L.subarray(off, off + n), 0); data.set(R.subarray(off, off + n), n);
      const ad = new g.AudioData({ format: 'f32-planar', sampleRate: 48000, numberOfFrames: n, numberOfChannels: 2, timestamp: Math.round((off / 48000) * 1e6), data });
      aenc.encode(ad); ad.close(); if (aerr) throw aerr;
    }
    await aenc.flush(); aenc.close();
  } else if (audio && !acodec) audioNote = ' This browser has no audio encoder, so the file is silent.';
  muxer.finalize();
  const v = space.video, tag = `${v.primaries}/${v.transfer}/${v.matrix}/${v.fullRange ? 'full' : 'limited'}`;
  const encTag = reportedSpace ? `${reportedSpace.primaries}/${reportedSpace.transfer}/${reportedSpace.matrix}/${reportedSpace.fullRange ? 'full' : 'limited'}` : 'none';
  return { blob: new Blob([muxer.target.buffer], { type: isMp4 ? 'video/mp4' : 'video/webm' }), note: audioNote.trim(), colorTag: tag, encoderTag: encTag, audio: !!acodec };
}

async function canvasPng(canvas) { return new Promise(r => canvas.toBlob(r, 'image/png')); }
async function pngSequence(pipeline, project, s, env, onProgress, signal) {
  const { w, h } = exportSize(s.aspect, s.tier); const N = frameCount(project, s.fps, s.loops);
  const { c: canvas, ctx } = makeExportCanvas(w, h, project.output.space); const files = {};
  const pad = Math.max(4, String(N).length); const base = slug(project).replace(/\+/g, '_');
  pipeline.renderFrame(ctx, w, h, project, 0, { transparent: s.transparent, env });
  for (let i = 0; i < N; i++) {
    if (signal && signal.aborted) throw abortErr();
    pipeline.renderFrame(ctx, w, h, project, frameTime(project, s.fps, i), { transparent: s.transparent, env });
    files[`${base}_${String(i).padStart(pad, '0')}.png`] = [new Uint8Array(await (await canvasPng(canvas)).arrayBuffer()), { level: 0 }];
    onProgress && onProgress((i + 1) / N, `Rendering frame ${i + 1} of ${N}`);
  }
  onProgress && onProgress(1, 'Packing ZIP'); await tick();
  return new Blob([g.fflate.zipSync(files)], { type: 'application/zip' });
}

// Run one export. s: { format, aspect, tier, fps, loops, transparent, time, withAudio }.
// ctx: { pipeline, env, audio: { buffer, offset } | null, onProgress, signal }. Returns { blob, filename, note, colorTag }.
async function runExport(project, s, { pipeline, env, audio, onProgress, signal } = {}) {
  const caps = await probeCapabilities();
  project = { ...project, output: { ...project.output, fps: s.fps || project.output.fps } };
  if (s.format === 'json') return { blob: new Blob([presetJSON(project, s.aspect)], { type: 'application/json' }), filename: `motif-${slug(project)}-preset.json` };
  if (s.format === 'png') {
    const { w, h } = exportSize(s.aspect, s.tier); const { c, ctx } = makeExportCanvas(w, h, project.output.space);
    pipeline.renderFrame(ctx, w, h, project, s.time || 0, { transparent: s.transparent, env });
    return { blob: await canvasPng(c), filename: fileName(project, s, 'png') };
  }
  if (s.format === 'png-seq') {
    if (!caps.zip) throw new Error('The ZIP library did not load. Check your connection and reload.');
    return { blob: await pngSequence(pipeline, project, s, env, onProgress, signal), filename: fileName(project, s, 'zip') };
  }
  const want = s.format === 'mp4' ? caps.mp4 : caps.webm;
  if (caps.webcodecs && caps.muxers && want) {
    const r = await encodeVideo(pipeline, project, s, caps, env, s.withAudio ? audio : null, onProgress, signal);
    const alphaNote = s.format === 'webm' && s.transparent && !caps.webmAlpha ? 'This browser can’t encode alpha, so the background was kept.' : '';
    return { blob: r.blob, filename: fileName(project, s, s.format), note: [alphaNote, r.note].filter(Boolean).join(' '), colorTag: r.colorTag, encoderTag: r.encoderTag, audio: r.audio };
  }
  throw new Error(`This browser can’t encode ${s.format === 'mp4' ? 'H.264' : 'VP9'}. Try ${s.format === 'mp4' ? 'WebM' : 'PNG sequence'}.`);
}

return { FORMAT, TIERS, FPS, probeCapabilities, fileName, presetJSON, parsePreset, runExport };

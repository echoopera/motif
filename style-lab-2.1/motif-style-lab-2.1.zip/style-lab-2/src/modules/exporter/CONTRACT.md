# exporter v2.0.0

Owner: web-engineer · Imports: renderer, style-library, engine-core, timeline, colour, audio · Acceptance: AC-3, AC-6

MP4/WebM via WebCodecs with RGBA→I420/I420A (BT.709 matrix, correct range) and container colour tags, muxed AAC/Opus audio, PNG sequence ZIP, PNG, preset@2 JSON; imports preset@1.

**Exports:** runExport, probeCapabilities, presetJSON, parsePreset, fileName, TIERS, FPS

**Rule:** Warm-up frame before frame 0 so scratch canvases settle.

# style-library v2.0.0

Owner: motion-designer · Imports: engine-core, tokens · Acceptance: AC-1

25 styles as pure functions render(ctx, S). Four carry gpu:true and a CPU cap (cpuMax) for their counts. Layer-shared schema: palette (dynamic ids), invert, tempo, phase, seed, zoom, rotate.

**Exports:** STYLES, CATEGORIES, SHARED_SCHEMA, getStyle, defaultLook, sanitizeLook, frameState, fontCss

**Rule:** Loop length comes from the project (S.L).

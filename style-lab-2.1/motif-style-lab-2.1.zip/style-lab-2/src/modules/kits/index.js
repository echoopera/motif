// kits — Motif Kit registry: install, validate, compile, persist and register imported style kits
// (motif-kit@1) so their styles behave exactly like built-ins (layers, keys, Mutate/Evolve, audio
// maps, export). The app itself stays one build; kits are data (manifest + GLSL) loaded at runtime.
const { STYLES, CATEGORIES } = __m_style_library;
const { PALETTES } = __m_tokens;
const { P } = __m_engine_core;
const KG = __m_kit_gl;

const STORE_KEY = 'motif-kits-v1';
const APP_KIT_API = 1;
const rt = KG.createGlRuntime();
const listeners = new Set();
let safe = true;                  // photosensitive limiter (WCAG 2.3.1), on by default
const installed = new Map();      // id -> { kit (normalized), raw: {manifest, files}, enabled, source }
const errorsByStyle = new Map();
const LOWPASS_BELOW = 1.0, LOWPASS_TAPS = 8, FULL_TAPS = 12, LOWPASS_SECONDS = 2 / 3; // triangle filter over 2/3 s: ≥ 3 Hz content drops below ~5%
let acc = null;
function accCanvas(w, h) { if (!acc) acc = document.createElement('canvas'); if (acc.width < w || acc.height < h) { acc.width = Math.max(acc.width, Math.ceil(w)); acc.height = Math.max(acc.height, Math.ceil(h)); } return acc; }

const store = {
  get() { try { return JSON.parse(localStorage.getItem(STORE_KEY)); } catch (e) { return null; } },
  set(v) { try { localStorage.setItem(STORE_KEY, JSON.stringify(v)); return true; } catch (e) { return false; } },
};
const removedCatalog = new Set();
function persist() {
  const kits = [...installed.values()].map(k => ({ id: k.kit.id, version: k.kit.version, enabled: k.enabled, source: k.source, raw: k.source === 'catalog' ? null : k.raw }));
  for (const id of removedCatalog) if (!installed.has(id)) kits.push({ id, source: 'catalog', removed: true });
  return store.set({ v: 1, safe, kits });
}
function emit(ev) { listeners.forEach(fn => { try { fn(ev); } catch (e) { console.error(e); } }); }

// Draw a clear placeholder when a kit style cannot render (no WebGL2, compile error).
function drawProblem(ctx, S, msg) {
  const { w, h, pal } = S;
  ctx.save(); ctx.fillStyle = pal.bg; ctx.fillRect(0, 0, w, h);
  ctx.strokeStyle = pal.accent(0); ctx.lineWidth = Math.max(1, S.u * 0.004); ctx.setLineDash([S.u * 0.02, S.u * 0.02]);
  ctx.strokeRect(S.u * 0.04, S.u * 0.04, w - S.u * 0.08, h - S.u * 0.08); ctx.setLineDash([]);
  ctx.fillStyle = pal.ink; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.font = `600 ${Math.max(9, S.u * 0.04)}px ui-monospace, monospace`;
  ctx.fillText(msg.split('\n')[0].slice(0, 80), w / 2, h / 2);
  ctx.restore();
}

function toStyle(kit, st) {
  const params = {};
  for (const [k, p] of Object.entries(st.params)) {
    const o = { mutate: p.mutate, unit: p.unit };
    if (p.type === 'range') params[k] = P.range(p.label, p.min, p.max, p.def, p.step, o);
    else if (p.type === 'int') params[k] = P.int(p.label, p.min, p.max, p.def, o);
    else if (p.type === 'toggle') params[k] = P.toggle(p.label, p.def, o);
    else params[k] = P.select(p.label, p.options, p.def, o);
    for (const x of ['mutate', 'unit']) if (params[k][x] === undefined) delete params[k][x];
  }
  const def = { passes: st.passes.map(x => ({ src: x.src, scale: x.scale })), common: kit.common, params };
  return {
    id: st.id, name: st.name, category: 'kit:' + kit.id, blurb: st.blurb, tags: st.tags, group: st.group,
    kit: kit.id, kitName: kit.name, palette: st.palette, flash: st.flash, engine: 'glsl', passes: st.passes.length, params,
    render(ctx, S) {
      const c = rt.compile(st.id, def);
      if (!c.ok) { errorsByStyle.set(st.id, c.error); drawProblem(ctx, S, rt.ok ? `${st.name}: shader error` : 'WebGL2 unavailable'); return; }
      const tempo = S.tempo || 1, Leff = (S.L || 6) / tempo;
      const u = { p: S.p, L: Leff, seed: S.seed, safe, pal: S.pal, params: S.P, spec: params };
      // Photosensitive low-pass: when the effective loop is shorter than LOWPASS_BELOW seconds, even ordinary
      // motion repeats faster than 3 Hz, so blend LOWPASS_TAPS sub-frames with triangle weights across
      // LOWPASS_SECONDS (first zero at 3 Hz, strong roll-off above). Stateless, so exports and scrubbing agree.
      if (safe && Leff < LOWPASS_BELOW) {
        const acc = accCanvas(S.w, S.h), ax = acc.getContext('2d');
        ax.setTransform(1, 0, 0, 1, 0, 0); ax.globalCompositeOperation = 'source-over'; ax.globalAlpha = 1; ax.clearRect(0, 0, acc.width, acc.height);
        ax.globalCompositeOperation = 'lighter';
        // Window in loop units. At or beyond one whole loop the ideal low-pass is the loop's mean, taken
        // with evenly spaced taps (cancels harmonics 1..FULL_TAPS-1 exactly; a triangle window there would alias).
        const w = LOWPASS_SECONDS / Leff, full = w >= 1, n = full ? FULL_TAPS : LOWPASS_TAPS;
        const wt = i => (full ? 1 : 1 - Math.abs((i + 0.5) / n * 2 - 1)), wsum = Array.from({ length: n }, (_, i) => wt(i)).reduce((a, b) => a + b, 0);
        for (let i = 0; i < n; i++) {
          ax.globalAlpha = wt(i) / wsum;
          const pp = full ? S.p + i / n : S.p + ((i + 0.5) / n - 0.5) * w;
          if (!rt.draw(st.id, S.w, S.h, { ...u, p: pp - Math.floor(pp) })) { drawProblem(ctx, S, 'WebGL2 context lost'); return; }
          rt.blit(ax, S.w, S.h);
        }
        ctx.drawImage(acc, 0, 0, S.w, S.h, 0, 0, S.w, S.h);
        return;
      }
      const canvas = rt.draw(st.id, S.w, S.h, u);
      if (!canvas) { drawProblem(ctx, S, 'WebGL2 context lost'); return; }
      rt.blit(ctx, S.w, S.h);
    },
  };
}

function register(entry) {
  const kit = entry.kit;
  unregister(kit.id);
  if (!entry.enabled) return;
  CATEGORIES.push({ id: 'kit:' + kit.id, name: kit.name, kit: kit.id, accent: kit.accent });
  for (const p of kit.palettes) if (!PALETTES.some(x => x.id === p.id)) PALETTES.push({ ...p });
  for (const st of kit.styles) STYLES.push(toStyle(kit, st));
}
function unregister(kitId) {
  for (let i = STYLES.length - 1; i >= 0; i--) if (STYLES[i].kit === kitId) STYLES.splice(i, 1);
  for (let i = CATEGORIES.length - 1; i >= 0; i--) if (CATEGORIES[i].kit === kitId) CATEGORIES.splice(i, 1);
  for (let i = PALETTES.length - 1; i >= 0; i--) if (PALETTES[i].kit === kitId) PALETTES.splice(i, 1);
  rt.forget(kitId + '/');
  for (const k of [...errorsByStyle.keys()]) if (k.startsWith(kitId + '/')) errorsByStyle.delete(k);
}

// Compile every style of a kit (used at import time so broken kits are rejected with line numbers).
function compileAll(kit) {
  const errs = [];
  if (!rt.ok) return { ok: true, errs, skipped: true };
  for (const st of kit.styles) {
    const def = { passes: st.passes.map(x => ({ src: x.src, scale: x.scale })), common: kit.common, params: toStyle(kit, st).params };
    rt.forget(st.id);
    const r = rt.compile(st.id, def);
    if (!r.ok) errs.push(`${st.localId}: ${r.error}`);
  }
  return { ok: !errs.length, errs };
}


// Install from raw { manifest, files }. opts: { source: 'file' | 'url' | 'catalog', enabled, silent }
function install(raw, opts = {}) {
  const v = KG.validateKit(raw && raw.manifest, raw && raw.files);
  if (!v.ok) return { ok: false, errors: v.errors, warnings: v.warnings };
  const kit = v.kit;
  const prev = installed.get(kit.id);
  const c = compileAll(kit);
  if (!c.ok) { if (prev) register(prev); return { ok: false, errors: c.errs.map(e => `Shader: ${e}`), warnings: v.warnings }; }
  const entry = { kit, raw, enabled: opts.enabled !== false, source: opts.source || 'file' };
  installed.set(kit.id, entry); removedCatalog.delete(kit.id);
  register(entry);
  if (!opts.silent) { persist(); emit({ type: 'install', id: kit.id, replaced: prev ? prev.kit.version : null }); }
  return { ok: true, kit, warnings: v.warnings, replaced: prev ? prev.kit.version : null, skippedCompile: !!c.skipped };
}
function remove(id) {
  if (!installed.has(id)) return false;
  const e = installed.get(id); unregister(id); installed.delete(id); if (e.source === 'catalog' || (typeof KIT_CATALOG !== 'undefined' && KIT_CATALOG.some(r => r.manifest.id === id))) removedCatalog.add(id); persist(); emit({ type: 'remove', id }); return true;
}
function setEnabled(id, on) {
  const e = installed.get(id); if (!e) return false;
  e.enabled = !!on; register(e); persist(); emit({ type: on ? 'enable' : 'disable', id }); return true;
}
function setSafe(on) { safe = !!on; persist(); emit({ type: 'safe', safe }); }

// Parse a dropped/opened file: .motifkit / .zip (needs the fflate global) or a .json bundle.
async function readFile(file) {
  const name = (file && file.name) || '';
  const buf = new Uint8Array(await file.arrayBuffer());
  return parseBytes(buf, name);
}
function parseBytes(buf, name = '') {
  const isZip = buf[0] === 0x50 && buf[1] === 0x4B;
  if (isZip) {
    if (typeof fflate === 'undefined') throw new Error('The ZIP library did not load, so .motifkit files cannot be opened right now.');
    const un = fflate.unzipSync(buf);
    let prefix = '';
    const names = Object.keys(un);
    if (!un['manifest.json']) { const m = names.find(n => /(^|\/)manifest\.json$/.test(n)); if (!m) throw new Error('No manifest.json in the package.'); prefix = m.slice(0, -'manifest.json'.length); }
    const files = {}; let manifest = null;
    for (const n of names) {
      if (!n.startsWith(prefix) || n.endsWith('/')) continue;
      const rel = n.slice(prefix.length);
      if (rel === 'manifest.json') manifest = JSON.parse(fflate.strFromU8(un[n]));
      else if (/\.(glsl|json|md|txt)$/i.test(rel)) files[rel] = fflate.strFromU8(un[n]);
    }
    return { manifest, files };
  }
  const text = new TextDecoder().decode(buf);
  const j = JSON.parse(text);
  if (j && j.manifest && j.files) return { manifest: j.manifest, files: j.files };
  throw new Error(`${name || 'File'} is not a .motifkit package or kit bundle.`);
}
function exportBytes(id) {
  const e = installed.get(id); if (!e || typeof fflate === 'undefined') return null;
  const zin = { 'manifest.json': fflate.strToU8(JSON.stringify(e.raw.manifest, null, 2)) };
  for (const [k, t] of Object.entries(e.raw.files)) zin[k] = fflate.strToU8(t);
  return fflate.zipSync(zin, { level: 9 });
}

// Starter kit for authors (the SDK template), as raw { manifest, files }.
function starterKit() { return JSON.parse(JSON.stringify(STARTER_KIT)); }

// Boot: bundled catalog + anything the viewer installed before.
const saved = store.get();
if (saved && typeof saved.safe === 'boolean') safe = saved.safe;
const savedById = new Map((saved && Array.isArray(saved.kits) ? saved.kits : []).map(k => [k.id, k]));
for (const raw of (typeof KIT_CATALOG !== 'undefined' ? KIT_CATALOG : [])) {
  const s = savedById.get(raw.manifest.id);
  if (s && s.source !== 'catalog' && s.raw) continue;          // the viewer's own copy of this kit wins
  if (s && s.removed) { removedCatalog.add(raw.manifest.id); continue; }
  const v = KG.validateKit(raw.manifest, raw.files);
  if (!v.ok) { console.warn('catalog kit invalid', raw.manifest.id, v.errors); continue; }
  const entry = { kit: v.kit, raw, enabled: s ? s.enabled !== false : true, source: 'catalog' };
  installed.set(v.kit.id, entry); register(entry);
}
for (const s of savedById.values()) {
  if (s.source === 'catalog' || !s.raw) continue;
  const v = KG.validateKit(s.raw.manifest, s.raw.files);
  if (!v.ok) continue;
  const entry = { kit: v.kit, raw: s.raw, enabled: s.enabled !== false, source: s.source || 'file' };
  installed.set(v.kit.id, entry); register(entry);
}

function list() { return [...installed.values()].map(e => ({ id: e.kit.id, name: e.kit.name, version: e.kit.version, author: e.kit.author, description: e.kit.description, accent: e.kit.accent, license: e.kit.license, styles: e.kit.styles.map(s => ({ id: s.id, name: s.name, group: s.group, flash: s.flash, passes: s.passes.length, params: Object.keys(s.params).length })), palettes: e.kit.palettes, enabled: e.enabled, source: e.source, bytes: JSON.stringify(e.raw).length })); }
function catalog() { return (typeof KIT_CATALOG !== 'undefined' ? KIT_CATALOG : []).map(r => ({ id: r.manifest.id, name: r.manifest.name, version: r.manifest.version, description: r.manifest.description, accent: r.manifest.accent, styles: r.manifest.styles.length, installed: installed.has(r.manifest.id) })); }
function installCatalog(id) { const raw = (typeof KIT_CATALOG !== 'undefined' ? KIT_CATALOG : []).find(r => r.manifest.id === id); return raw ? install(raw, { source: 'catalog' }) : { ok: false, errors: ['Not in the bundled catalog.'] }; }
function kitOfStyle(styleId) { const i = styleId.indexOf('/'); return i > 0 ? styleId.slice(0, i) : null; }
function missingKits(project) { const ids = new Set(); for (const l of (project && project.layers) || []) { const k = kitOfStyle(String(l.styleId || '')); if (k && !STYLES.some(s => s.id === l.styleId)) ids.add(k); } return [...ids]; }
function on(fn) { listeners.add(fn); return () => listeners.delete(fn); }

return {
  KIT_FORMAT: KG.KIT_FORMAT, APP_KIT_API, LOWPASS_BELOW, runtime: rt, install, remove, setEnabled, setSafe, get safe() { return safe; }, list, catalog, installCatalog,
  readFile, parseBytes, exportBytes, starterKit, validate: KG.validateKit, kitOfStyle, missingKits, on, errors: errorsByStyle, persist,
};

# kits v1.0.0

Owner: systems-architect · Imports: engine-core, tokens, style-library, kit-gl · Acceptance: AC-9, AC-10

The kit registry. It installs, updates, removes and enables or disables kits; parses .motifkit zips and JSON bundles; and test-compiles every pass before a kit installs. It registers kit styles, categories and palettes into the style library's live arrays, so the timeline, compositor, Mutate/Evolve, audio maps and exporter need no changes. It also persists the viewer's kits, ships the bundled catalog (catalog.gen.js) and the SDK starter (starter.gen.js), and runs the photosensitive limiter: shader rate caps, plus a temporal low-pass when the effective loop is under 1 s.

**Exports:** install, remove, setEnabled, setSafe, safe, list, catalog, installCatalog, readFile, parseBytes, exportBytes, starterKit, validate, kitOfStyle, missingKits, on, errors, runtime

**Rule:** A kit that fails validation or compilation changes nothing. The previously installed version stays live.

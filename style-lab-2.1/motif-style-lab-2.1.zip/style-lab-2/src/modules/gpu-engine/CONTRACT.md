# gpu-engine v1.0.0

Owner: graphics-engineer · Imports: engine-core, style-library · Acceptance: AC-5

WebGPU renderers for Particle Form, Flow Field (compute + instanced segments), Orbital Swarm and Metaballs (per-pixel field). Same hash and noise permutation as the CPU path. Each render returns an ImageBitmap snapshot.

**Exports:** createGpuEngine() → {init, render(styleId, S, w, h), pre, supports, ready, state, reason, setForceCpu}

**Rule:** render() returns null to request the Canvas 2D fallback.

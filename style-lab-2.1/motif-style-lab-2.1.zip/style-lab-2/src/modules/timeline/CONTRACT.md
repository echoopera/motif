# timeline v1.0.0

Owner: motion-designer · Imports: engine-core, style-library · Acceptance: AC-1, AC-6

Project model v2 and the path grammar L:<id>:p|s|c:<key> and F:<key>. Cyclic keyframes (linear, smooth, in, out, hold), palette cross-fade, audio modulation, evaluate(project, t, env), project-level mutate/randomize (keyed paths behave as locked).

**Exports:** FORMAT, BLENDS, COMP_SCHEMA, FINISH_SCHEMA, BANDS, EASES, newProject, newLayer, sanitizeProject, fromV1, schemaAt, getBase, setBase, setKey, removeKey, moveKey, clearKeys, valueAt, evaluate, allPaths, mutateProject, randomizeProject

**Rule:** Pure; no DOM.

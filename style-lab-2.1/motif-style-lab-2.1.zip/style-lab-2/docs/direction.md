# Direction — Style Lab 2 (creative director)

**Instrument Bench, extended.** v1's quiet graphite workbench stays; the canvas is still the loudest thing on screen. Everything new is a panel in the same chrome: mono labels, hairlines, one blue accent for "live/selected", amber for "locked/audio".

- **Pinned stage.** The preview never scrolls away. Desktop: three columns, only the side panels scroll. Under 1100 px: a fixed shell (bar → stage → key lane → actions → tabs) with one scrolling panel; the library becomes a tab. Tablet landscape: stage left, panel right.
- **Key lane** sits under the scrubber, collapsed on phones. Diamonds are the only keyframe glyph (square = hold). ◇ on any row keys it; a keyed row's value turns blue.
- **Layers** read top-first like every compositor; the base layer is labelled.
- **Colour** is a working surface: swatches → editor with locks and contrast grade → swatch library → output space.
- **Audio** shows the loop region on the waveform and a beat grid; amber ∿ marks mapped rows everywhere.
- Demo on load answers the brief literally: Plexus behind Particle Form over Halftone, burst keyed 0 → 1, palette shift at 3.5 s, glow.

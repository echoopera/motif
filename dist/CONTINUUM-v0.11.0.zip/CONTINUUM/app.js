'use strict';
const $=id=>document.getElementById(id), canvas=$('map'), ctx=canvas.getContext('2d'), stage=$('stage');
// Stage size is observed, never measured per frame; the pointer rect is read once per gesture.
const uiSize={w:stage.clientWidth,h:stage.clientHeight};let uiRectCache=null;
if(window.ResizeObserver)new ResizeObserver(es=>{const r=es[0].contentRect;uiSize.w=r.width;uiSize.h=r.height}).observe(stage);
const palettes=['#a2e1dd','#88c8e8','#b4bce8','#ddd4a0'];
try{const c=JSON.parse(localStorage.getItem('continuum-colors-v1')||'null');if(Array.isArray(c)&&c.length===4&&c.every(h=>/^#[0-9a-f]{6}$/i.test(h)))c.forEach((h,i)=>{palettes[i]=h})}catch{}
const worlds=[{name:'VERDANT',key:0,mode:'Lydian',scale:[0,2,4,6,7,9,11],bpm:72,desc:'Glass / open air'},{name:'TIDELINE',key:9,mode:'Dorian',scale:[0,2,3,5,7,9,10],bpm:84,desc:'Tides / soft echoes'},{name:'UMBRA',key:2,mode:'Minor',scale:[0,2,3,5,7,8,10],bpm:60,desc:'Low light / deep drones'},{name:'EMBER',key:7,mode:'Mixolydian',scale:[0,2,4,5,7,9,10],bpm:96,desc:'Warm pulse / motion'}];
let seed=crypto.getRandomValues(new Uint32Array(1))[0], nodes=[], path=[], drawing=false, pointerId=null, point={x:.5,y:.5}, weights=[.25,.25,.25,.25], playing=false, progress=0, duration=60, curvature=0, enabled=false, muted=false, audio=null, snapshots=[], lastFrame=0;
let audioSlots=[null,null,null,null];
const defaultProjection=.34;let projectionPreferences=[defaultProjection,defaultProjection,defaultProjection,defaultProjection];try{const saved=JSON.parse(localStorage.getItem('continuum-projection-v1')||'null');if(Array.isArray(saved)&&saved.length===4&&saved.every(v=>Number.isFinite(v)&&v>=.16&&v<=.85))projectionPreferences=saved}catch{}
const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;

// ── CONTINUUM shell helpers (ui*-prefixed so the audio modules never collide) ──
const uiPad=(n,l=2)=>String(n).padStart(l,'0');
// Big readouts: one fixed-width cell per character, so values change in place and never shift the layout.
function uiNum(id,str){const el=document.getElementById(id);if(!el||el.dataset.v===str)return;el.dataset.v=str;el.replaceChildren(...[...str].map(ch=>{const d=document.createElement('span');d.className='d';d.textContent=ch;return d}))}
const uiNotes=['C','C♯','D','E♭','E','F','F♯','G','A♭','A','B♭','B'];
const uiBuzz=ms=>{try{navigator.vibrate&&navigator.vibrate(ms)}catch{}};
const uiMono='"IBM Plex Mono",ui-monospace,Menlo,monospace';
let uiWakeLock=null,uiWakeBusy=false;
async function uiWake(on){if(uiWakeBusy)return;uiWakeBusy=true;try{if(on&&!uiWakeLock&&navigator.wakeLock){uiWakeLock=await navigator.wakeLock.request('screen');uiWakeLock.addEventListener('release',()=>{uiWakeLock=null})}else if(!on&&uiWakeLock){await uiWakeLock.release();uiWakeLock=null}}catch{uiWakeLock=null}uiWakeBusy=false}
const loopOn=true; // journeys always loop; the end flows back to the start
let silenced=false,uiMove=-1,silenceTok=0,uiFadeSources=false;const srcOn=[true,true,true,true];try{const o=JSON.parse(localStorage.getItem('continuum-src-on-v1')||'null');if(Array.isArray(o)&&o.length===4)o.forEach((v,i)=>{srcOn[i]=v!==false})}catch{}
let holdRegion=null,uiGrab=-1,uiPlayStart=0;
let uiMsgTimer=0;{const el=$('message');new MutationObserver(()=>{if(!el.textContent)return;el.classList.add('show');clearTimeout(uiMsgTimer);uiMsgTimer=setTimeout(()=>el.classList.remove('show'),4400)}).observe(el,{childList:true,characterData:true,subtree:true})}

function rng(s){return()=>{s|=0;s=s+0x6D2B79F5|0;let t=Math.imul(s^s>>>15,1|s);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
function message(t){$('message').textContent=t}
function positions(s){const r=rng(s);return[{x:.24,y:.31},{x:.76,y:.32},{x:.28,y:.7},{x:.72,y:.69}].map((p,i)=>({...p,x:p.x+(r()-.5)*.1,y:p.y+(r()-.5)*.05,id:i,radius:projectionPreferences[i]}))}
function toggleSource(i){if(!nodes[i])return;srcOn[i]=!srcOn[i];try{localStorage.setItem('continuum-src-on-v1',JSON.stringify(srcOn))}catch{}uiBuzz(srcOn[i]?10:16);message(worlds[i].name+(srcOn[i]?' on':' off'))}
async function wake(){if(!audio)return;silenceTok++;if(silenced||audio.a.state!=='running'){silenced=false;try{await audio.a.resume()}catch{}const t=audio.a.currentTime;audio.out.gain.cancelScheduledValues(t);audio.out.gain.setTargetAtTime(1,t,.04);audio.volume()}}
// How long the active effects keep ringing after their input stops.
function uiTailSeconds(){let t=.5;if(!audio?.rack)return t;const bpm=audio.bpm||72,on=k=>effectState[k].mix>.02;
 const rv=fxPresets.reverb[effectState.reverb.preset];if(rv&&on('reverb'))t=Math.max(t,rv.decay+rv.pre);
 const d=fxPresets.delay[effectState.delay.preset];if(d&&on('delay')){const step=60/bpm*d.division*Math.max(1,d.spread),reps=Math.log(.001)/Math.log(Math.max(.05,Math.min(.92,d.feedback)));t=Math.max(t,Math.min(6,step*reps))}
 if(fxPresets.granular[effectState.granular.preset]&&on('granular'))t=Math.max(t,.7);
 if(fxPresets.slow[effectState.slow.preset]&&on('slow'))t=Math.max(t,.8);
 return Math.min(6.5,t)}
// Graceful stop: the sources fade first (~1 s) while reverb/delay/tape tails ring out, then the output fades to
// true silence and only then is the context suspended, so nothing is ever cut mid-signal.
async function silence(){if(!audio||!enabled||silenced)return;silenced=true;const tok=++silenceTok,t=audio.a.currentTime,tail=uiTailSeconds(),outStart=Math.max(.9,tail-1);
 audio.master.gain.cancelScheduledValues(t);audio.master.gain.setTargetAtTime(0,t,.22);
 audio.out.gain.cancelScheduledValues(t);audio.out.gain.setValueAtTime(audio.out.gain.value,t);audio.out.gain.setTargetAtTime(0,t+outStart,.3);
 await new Promise(r=>setTimeout(r,(outStart+2.1)*1000));if(silenced&&tok===silenceTok){try{await audio.a.suspend()}catch{}}}
function nodeSub(i){return audioSlots[i]?uiNotes[worlds[i].key]+' '+worlds[i].mode.slice(0,3).toUpperCase()+' · '+Math.round(worlds[i].bpm):['C LYD · 72','A DOR · 84','D MIN · 60','G MIX · 96'][i]}
function renderNodes(){
 $('nodeLayer').replaceChildren();$('identStrip').replaceChildren();
 nodes.forEach((n,i)=>{
  const b=document.createElement('button');b.type='button';b.className='node'+(n.y>.5?' lower':'');b.dataset.i=i;
  b.style.left=n.x*100+'%';b.style.top=n.y*100+'%';b.style.setProperty('--color',palettes[i]);
  b.setAttribute('aria-label',worlds[i].name+'. Tap to play or stop. Hold to move. Drag to draw a route.');b.setAttribute('aria-pressed','false');
  const label=document.createElement('span');label.className='node-label';
    const title=document.createElement('b');title.textContent=worlds[i].name;
  const sub=document.createElement('small');sub.textContent=nodeSub(i);
  const meter=document.createElement('span');meter.id='level-'+i;meter.className='node-meter';meter.setAttribute('aria-hidden','true');
  label.append(title,sub,meter);b.append(label);
  b.onclick=e=>{if(e.detail===0)toggleSource(i)};
  $('nodeLayer').append(b);
  const t=document.createElement('button');t.type='button';t.className='ident';t.dataset.i=i;t.style.setProperty('--color',palettes[i]);t.setAttribute('aria-pressed','false');
  t.setAttribute('aria-label','Play or stop '+worlds[i].name);
  t.innerHTML='<b>'+(i+1)+'</b><span class="id-bar"><u></u></span>';
  t.onclick=()=>{if(!enabled){enter();return}if(silenced||audio.a.state!=='running'){wake();return}toggleSource(i)};
  $('identStrip').append(t);
 });
 renderProjectionControls();if(typeof renderTrackMixer==='function')renderTrackMixer();
 $('sessionLabel').textContent='FIELD / '+seed.toString(16).slice(0,6).toUpperCase();
}
function projectionRadius(n){return Number.isFinite(n.radius)?n.radius:defaultProjection}
function setProjection(i,value){if(!nodes[i])return;nodes[i].radius=Math.max(.16,Math.min(.85,Number(value)||defaultProjection));projectionPreferences=nodes.map(projectionRadius);try{localStorage.setItem('continuum-projection-v1',JSON.stringify(projectionPreferences))}catch{} }
function renderProjectionControls(){$('projectionControls').replaceChildren();nodes.forEach((n,i)=>{const row=document.createElement('div');row.className='projection-control';row.style.setProperty('--color',palettes[i]);const label=document.createElement('label');label.htmlFor='projection-'+i;const name=document.createElement('span');name.className='name';name.textContent=worlds[i].name;name.title=worlds[i].name;const value=document.createElement('output');value.textContent=Math.round(projectionRadius(n)*100)+'%';value.setAttribute('for','projection-'+i);label.append(name,value);const slider=document.createElement('input');slider.id='projection-'+i;slider.type='range';slider.min='16';slider.max='85';slider.step='1';slider.value=Math.round(projectionRadius(n)*100);slider.setAttribute('aria-label',worlds[i].name+' influence radius');slider.setAttribute('aria-valuetext',slider.value+' percent of the map’s shorter side');slider.oninput=()=>{setProjection(i,+slider.value/100);value.textContent=slider.value+'%';slider.setAttribute('aria-valuetext',slider.value+' percent of the map’s shorter side')};row.append(label,slider);$('projectionControls').append(row)})}
function blend(p){const rect={width:uiSize.w||stage.clientWidth||1,height:uiSize.h||stage.clientHeight||1},unit=Math.max(1,Math.min(rect.width,rect.height));const scores=nodes.map(n=>{const distance=Math.hypot((p.x-n.x)*rect.width,(p.y-n.y)*rect.height)/unit;return -3*Math.pow(distance/projectionRadius(n),2)});const peak=Math.max(...scores);let raw=scores.map(v=>Math.exp(v-peak));
 if(srcOn.some(Boolean))raw=raw.map((v,i)=>srcOn[i]?v:0);
 // collision: spheres that overlap pull each other into the mix, so the listener hears them merge
 const base=raw.slice();for(let i=0;i<4;i++)for(let j=i+1;j<4;j++){if(!srcOn[i]||!srcOn[j])continue;const d=Math.hypot((nodes[i].x-nodes[j].x)*rect.width,(nodes[i].y-nodes[j].y)*rect.height)/unit,o=Math.max(0,1-d/.2);if(o>0){raw[i]=Math.max(raw[i],base[j]*o);raw[j]=Math.max(raw[j],base[i]*o)}}
 const sum=raw.reduce((a,b)=>a+b,0);return raw.map(v=>v/sum)}
function controls(){try{if('mediaSession' in navigator)navigator.mediaSession.playbackState=playing?'playing':'paused'}catch{}const p=$('play');p.disabled=path.length<2;$('save').disabled=path.length<2;$('clear').disabled=path.length===0;$('stop').disabled=!enabled;const xb=$('exportAudio');if(xb)xb.disabled=path.length<2;const st=playing?'playing':'ready';p.dataset.state=st;$('playLabel').textContent=playing?'PAUSE':'PLAY';p.setAttribute('aria-label',playing?'Pause':'Play');if(path.length<2)holdRegion=null;if(playing&&!controls.was)uiPlayStart=performance.now();controls.was=playing;stage.classList.toggle('has-path',path.length>1);uiWake(playing)}
function uiResample(step=.008){if(path.length<4)return;const out=[path[0]];let acc=0;for(let i=1;i<path.length;i++){acc+=Math.hypot(path[i].x-path[i-1].x,path[i].y-path[i-1].y);if(acc>=step){out.push(path[i]);acc=0}}const last=path[path.length-1],tail=out[out.length-1];if(tail!==last){if(out.length>1&&Math.hypot(last.x-tail.x,last.y-tail.y)<step*.5)out[out.length-1]=last;else out.push(last)}path=out}
function finishDraw(){drawing=false;pointerId=null;controls();if(path.length>1){uiResample();indexPath();}if(path.length>1)message('Route set');else path=[]}
function startDraw(p){stopJourney();drawing=true;path=[p];point=p;curvature=0;progress=0;message('Drawing');controls()}
function addPoint(p){const last=path[path.length-1];if(!last||Math.hypot(last.x-p.x,last.y-p.y)>.002){if(path.length<4000)path.push(p);point=p}}
function pointer(e){const r=uiRectCache||stage.getBoundingClientRect();return{x:Math.max(.02,Math.min(.98,(e.clientX-r.left)/r.width)),y:Math.max(.04,Math.min(.96,(e.clientY-r.top)/r.height))}}
function setHold(i){
 if(path.length<2||!enabled)return;
 if(!playing){if(silenced)wake();playJourney()}
 if(!playing||!journeyBeats)return;
 const c=totalLength?lengths[i]/totalLength:0;
 let span=Math.max(4,Math.round(.12*journeyBeats/4)*4)/journeyBeats;if(span>=1)span=1;
 const a=Math.max(0,Math.min(1-span,c-span/2));
 holdRegion={a,b:a+span,c};
 if(progress<a||progress>=a+span){journeyStartBeat=audio.beatPosition();journeyStartProgress=a;progress=a}
 message('Looping '+Math.round(span*journeyBeats)+' beats');
}
function releaseHold(){if(!holdRegion)return;holdRegion=null;message('Released')}
function uiPathHit(e){if(path.length<2)return null;const r=uiRectCache||stage.getBoundingClientRect(),px=e.clientX-r.left,py=e.clientY-r.top;let bi=-1,bd=1e9;for(let i=0;i<path.length;i++){const d=Math.hypot(path[i].x*r.width-px,path[i].y*r.height-py);if(d<bd){bd=d;bi=i}}return bd<=34?{i:bi,d:bd}:null}
function uiHoldDotHit(e){if(!holdRegion||path.length<2)return false;const r=uiRectCache||stage.getBoundingClientRect(),c=samplePath(holdRegion.c);return Math.hypot(c.x*r.width-(e.clientX-r.left),c.y*r.height-(e.clientY-r.top))<=32}
function uiReshape(cur){const o=press.orig,L=press.lens,k=press.hit.i,dx=cur.x-press.grab.x,dy=cur.y-press.grab.y,sigma=Math.max(.06,L[L.length-1]*.14);
 for(let i=0;i<o.length;i++){const w=Math.exp(-Math.pow((L[i]-L[k])/sigma,2));path[i]={x:Math.max(.02,Math.min(.98,o[i].x+dx*w)),y:Math.max(.04,Math.min(.96,o[i].y+dy*w))}}
 indexPath();uiGrab=k}
function uiRescale(oldTotal,oldProg){indexPath();const r=oldTotal/totalLength;journeyBeats*=totalLength/oldTotal;progress=Math.min(1,oldProg*r);journeyStartProgress=progress;if(audio)journeyStartBeat=audio.beatPosition();if(holdRegion)holdRegion={a:holdRegion.a*r,b:holdRegion.b*r,c:holdRegion.c*r};point=samplePath(progress)}
let press=null,uiRing=null,uiRingPick=null;const uiRingF=[.62,.81,1];
// Influence rings (mouse/pen): hover near one to light it up, then drag or scroll to change its radius. Touch uses the Mix sliders so drawing is never hijacked.
function uiRingHit(e,tol){const r=uiRectCache||stage.getBoundingClientRect(),U=Math.min(r.width,r.height),px=e.clientX-r.left,py=e.clientY-r.top;let best=null,bd=tol;nodes.forEach((n,i)=>{const d=Math.hypot(px-n.x*r.width,py-n.y*r.height),R=projectionRadius(n)*U;uiRingF.forEach((f,k)=>{const g=Math.abs(d-R*f);if(g<bd){bd=g;best={i,k}}})});return best}
function uiRingSet(i,k,e){const r=uiRectCache||stage.getBoundingClientRect(),U=Math.min(r.width,r.height),n=nodes[i],d=Math.hypot(e.clientX-r.left-n.x*r.width,e.clientY-r.top-n.y*r.height);setProjection(i,d/(U*uiRingF[k]));const v=Math.round(projectionRadius(n)*100),sl=document.getElementById('projection-'+i);if(sl){sl.value=v;const o=sl.parentElement.querySelector('output');if(o)o.textContent=v+'%'}}
stage.addEventListener('click',()=>{if(!enabled&&$('gate').hidden)enter()});
stage.addEventListener('contextmenu',e=>e.preventDefault());
stage.addEventListener('pointerleave',e=>{if(!press&&uiRing){uiRing=null;stage.style.cursor=''}});
stage.addEventListener('wheel',e=>{if(!enabled||press||!uiRing)return;e.preventDefault();const n=nodes[uiRing.i];setProjection(uiRing.i,projectionRadius(n)-e.deltaY*.0004);const v=Math.round(projectionRadius(n)*100),sl=document.getElementById('projection-'+uiRing.i);if(sl){sl.value=v;const o=sl.parentElement.querySelector('output');if(o)o.textContent=v+'%'}},{passive:false});
stage.addEventListener('pointerdown',e=>{if(!enabled||e.button!==0)return;
 const nb=e.target.closest('button.node'),r=stage.getBoundingClientRect();uiRectCache=r;
 const nn=nb&&nodes[+nb.dataset.i];
 const nodeWins=!!nn&&Math.hypot(e.clientX-r.left-nn.x*r.width,e.clientY-r.top-nn.y*r.height)<=42;
 press={id:e.pointerId,x:e.clientX,y:e.clientY,node:nodeWins?+nb.dataset.i:-1,started:false,kind:'draw',wasSilent:silenced||audio.a.state!=='running'};
 try{stage.setPointerCapture(e.pointerId)}catch{}
 const hit=!drawing&&!nodeWins?uiPathHit(e):null,lastP=path[path.length-1];
 const endHit=hit&&path.length>1&&Math.hypot(lastP.x*r.width-(e.clientX-r.left),lastP.y*r.height-(e.clientY-r.top))<=30;
 if(uiHoldDotHit(e)){press.kind='release'}
 else if(endHit){Object.assign(press,{kind:'extend',oldTotal:totalLength,oldProg:progress})}
 else if(hit){const lens=[0];for(let i=1;i<path.length;i++)lens.push(lens[i-1]+Math.hypot(path[i].x-path[i-1].x,path[i].y-path[i-1].y));
  Object.assign(press,{kind:'path',hit,grab:pointer(e),orig:path.map(p=>({...p})),lens,held:false});
  press.timer=setTimeout(()=>{if(press&&press.kind==='path'&&!press.started){press.held=true;setHold(hit.i);uiBuzz(24)}},430)}
 else if(!nodeWins&&!hit&&e.pointerType!=='touch'&&(uiRingPick=uiRingHit(e,9))){Object.assign(press,{kind:'ring',ring:uiRingPick,started:true});uiRing={...uiRingPick,drag:true};uiBuzz(6)}
 else if(nodeWins){press.timer=setTimeout(()=>{if(press&&press.kind==='draw'&&!press.started){press.kind='move';press.started=true;uiMove=press.node;uiBuzz(22);if(press.wasSilent)wake()}},420)}
 else if(playing){press.kind='away'}
 else{press.started=true;pointerId=e.pointerId;startDraw(pointer(e));stage.focus({preventScroll:true})}
 e.preventDefault()});
stage.addEventListener('pointermove',e=>{if(!enabled)return;
 if(!press&&e.pointerType==='mouse'){const rh=e.target.closest('button.node')?null:uiRingHit(e,9);if((rh&&rh.i)!==(uiRing&&uiRing.i)||(rh&&uiRing&&rh.k!==uiRing.k)||!rh!==!uiRing){uiRing=rh?{...rh,drag:false}:null;stage.style.cursor=rh?'ew-resize':''}}
 if(press&&e.pointerId===press.id){const moved=Math.hypot(e.clientX-press.x,e.clientY-press.y);
  if(press.kind==='move'){const p=pointer(e),n=nodes[press.node];n.x=Math.max(.07,Math.min(.93,p.x));n.y=Math.max(.1,Math.min(.9,p.y));const b=$('nodeLayer').querySelector('button.node[data-i="'+press.node+'"]');if(b){b.style.left=n.x*100+'%';b.style.top=n.y*100+'%';b.classList.toggle('lower',n.y>.5)}}
  else if(press.kind==='ring'){uiRingSet(press.ring.i,press.ring.k,e)}
  else if(press.kind==='extend'){if(press.started||moved>6){if(!press.started){press.started=true;uiGrab=path.length-1;uiBuzz(8)}const evs=e.getCoalescedEvents?e.getCoalescedEvents():[e];for(const ce of(evs.length?evs:[e]))addPoint(pointer(ce))}}
  else if(press.kind==='path'){if(!press.held&&(press.started||moved>8)){clearTimeout(press.timer);if(!press.started){press.started=true;uiBuzz(6)}uiReshape(pointer(e))}}
  else if(press.kind==='away'){if(!press.started&&moved>14){press.started=true;pointerId=e.pointerId;startDraw(pointer({clientX:press.x,clientY:press.y}));addPoint(pointer(e))}else if(press.started&&drawing)addPoint(pointer(e))}
  else if(press.kind==='draw'&&press.node>=0&&!press.started){if(moved>9){clearTimeout(press.timer);press.started=true;pointerId=e.pointerId;const n=nodes[press.node];startDraw({x:n.x,y:n.y});addPoint(pointer(e));uiBuzz(6)}}
  else if(drawing&&e.pointerId===pointerId){const evs=e.getCoalescedEvents?e.getCoalescedEvents():[e];for(const ce of(evs.length?evs:[e]))addPoint(pointer(ce))}}
 else if(!playing&&e.pointerType==='mouse'&&!e.target.closest('button'))point=pointer(e)});
const uiPressEnd=e=>{if(!press||e.pointerId!==press.id)return;const p=press;press=null;uiRectCache=null;clearTimeout(p.timer);uiGrab=-1;uiMove=-1;
 if(p.kind==='release'){if(e.type==='pointerup'){releaseHold();uiBuzz(12)}}
 else if(p.kind==='ring'){uiRing=null}
 else if(p.kind==='move'){uiBuzz(8)}
 else if(p.kind==='extend'){if(p.started&&path.length>1){uiResample();uiRescale(p.oldTotal,p.oldProg);message('Extended');uiBuzz(10)}}
 else if(p.kind==='path'){if(p.started&&!p.held){message('Reshaped');uiBuzz(8)}}
 else if(drawing){finishDraw();if(path.length>1)uiBuzz(14)}
 else if(p.node>=0&&!p.started&&e.type==='pointerup'){if(p.wasSilent)wake();else toggleSource(p.node)}};
stage.addEventListener('pointerup',uiPressEnd);stage.addEventListener('pointercancel',uiPressEnd);
stage.addEventListener('keydown',e=>{if(e.target!==stage||!enabled)return;if(e.code==='Space'){e.preventDefault();if(drawing)finishDraw();else startDraw({...point})}if(e.key.startsWith('Arrow')){e.preventDefault();stopJourney();const d=.025;point={x:Math.max(.03,Math.min(.97,point.x+(e.key==='ArrowRight'?d:e.key==='ArrowLeft'?-d:0))),y:Math.max(.05,Math.min(.95,point.y+(e.key==='ArrowDown'?d:e.key==='ArrowUp'?-d:0)))};if(drawing)addPoint({...point})}if(e.key==='Escape'){finishDraw();stopJourney()}});
let lengths=[],totalLength=0, journeyBeats=0, journeyStartBeat=0, journeyStartProgress=0;
let sp=[],slens=[0];
// With Loop on, the playable route is closed: the end flows back to the start along a connector.
function indexPath(){lengths=[0];let t=0;for(let i=1;i<path.length;i++){t+=Math.hypot(path[i].x-path[i-1].x,path[i].y-path[i-1].y);lengths.push(t)}sp=path;slens=lengths;totalLength=t;if(loopOn&&path.length>1){const a=path[path.length-1],b=path[0];totalLength=t+Math.hypot(a.x-b.x,a.y-b.y);sp=path.concat([b]);slens=lengths.concat([totalLength])}}
function samplePath(f){const target=f*totalLength;let lo=1,hi=slens.length-1;while(lo<hi){let m=(lo+hi)>>1;if(slens[m]<target)lo=m+1;else hi=m}const i=lo,a=sp[i-1],b=sp[i],t=(target-slens[i-1])/Math.max(.000001,slens[i]-slens[i-1]);return{x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t}}
function geometry(f){const a=samplePath(Math.max(0,f-.007)),b=samplePath(f),c=samplePath(Math.min(1,f+.007));const ux=b.x-a.x,uy=b.y-a.y,vx=c.x-b.x,vy=c.y-b.y;return Math.min(1,Math.abs(Math.atan2(ux*vy-uy*vx,ux*vx+uy*vy))/Math.PI)}
function stopJourney(){playing=false;holdRegion=null;controls()}
function playJourney(restart=false){if(!enabled||path.length<2)return;if(playing&&!restart){stopJourney();return}indexPath();duration=+$('duration').value;if(progress>=1||restart)progress=0;if(progress===0){point={...path[0]};weights=typeof musicalMix==='function'?musicalMix(point):blend(point);audio.reset(seed^pathHash());}if(progress===0||!journeyBeats)journeyBeats=duration*audio.bpm/60;journeyStartBeat=audio.beatPosition();journeyStartProgress=progress;playing=true;controls()}
function pathHash(){let h=2166136261;path.forEach(p=>{h=Math.imul(h^Math.round(p.x*10000),16777619);h=Math.imul(h^Math.round(p.y*10000),16777619)});return h>>>0}
class SoundField{
 constructor(){const AC=window.AudioContext||window.webkitAudioContext;if(!AC)throw Error('This browser does not support Web Audio.');try{this.a=new AC({latencyHint:'playback'})}catch{this.a=new AC()}this.master=this.a.createGain();this.master.gain.value=.65;const compressor=this.a.createDynamicsCompressor();compressor.threshold.value=-20;compressor.ratio.value=5;this.rack=typeof createEffectsRack==='function'?createEffectsRack(this.a,compressor):null;this.master.connect(this.rack?.input||compressor);this.out=this.a.createGain();const lim=this.a.createDynamicsCompressor();lim.threshold.value=-2;lim.knee.value=0;lim.ratio.value=20;lim.attack.value=.001;lim.release.value=.08;compressor.connect(lim);lim.connect(this.out);this.out.connect(this.a.destination);this.delay=this.a.createDelay(2);this.delay.delayTime.value=.42;this.feedback=this.a.createGain();this.feedback.gain.value=.28;const low=this.a.createBiquadFilter();low.frequency.value=2300;this.delay.connect(low);low.connect(this.feedback);this.feedback.connect(this.delay);const wet=this.a.createGain();wet.gain.value=.28;low.connect(wet);wet.connect(this.master);this.routes=[];this.buses=worlds.map((_,i)=>{const g=this.a.createGain();g.gain.value=.1;if(typeof createTrackRoute==='function'){this.routes[i]=createTrackRoute(this.a,this.master,i);g.connect(this.routes[i].input)}else g.connect(this.master);return g});this.noise=this.a.createBuffer(1,this.a.sampleRate*2,this.a.sampleRate);const data=this.noise.getChannelData(0),r=rng(seed);for(let i=0;i<data.length;i++)data[i]=r()*2-1;this.voices=new Set();this.bpm=72;this.targetBpm=72;this.frame=0;this.tick=0;this.beatMarkers=[];this.next=this.a.currentTime+.1;this.random=rng(seed);this.fieldIndex=0;this.field=worlds[0];this.timer=setInterval(()=>this.schedule(),25)}
 reset(s){if(typeof resetImportedAudio==='function')resetImportedAudio();this.random=rng(s);this.tick=0;this.beatMarkers=[];this.frame=0;this.fieldIndex=weights.indexOf(Math.max(...weights));this.field=worlds[this.fieldIndex];this.bpm=weights.reduce((v,w,i)=>v+w*worlds[i].bpm,0);this.targetBpm=worlds[this.fieldIndex].bpm;this.next=this.a.currentTime+.12;for(const o of this.voices){try{o.stop(this.a.currentTime+.03)}catch{}}this.voices.clear();this.feedback.gain.setTargetAtTime(0,this.a.currentTime,.02);this.feedback.gain.setTargetAtTime(.28,this.a.currentTime+.8,.1)}
 note(midi,t,len,bus,kind,amp,pan=0){if(audioSlots[bus]?.ready)return;const a=this.a,osc=a.createOscillator(),g=a.createGain(),filter=a.createBiquadFilter(),p=a.createStereoPanner();osc.type=kind;osc.frequency.value=440*Math.pow(2,(midi-69)/12);filter.type='lowpass';filter.frequency.value=kind==='sine'?5000:900+point.y*1700;g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(amp,t+.06);g.gain.exponentialRampToValueAtTime(.0001,t+len);p.pan.value=pan;osc.connect(filter);filter.connect(g);g.connect(p);p.connect(this.buses[bus]);osc.start(t);osc.stop(t+len+.1);osc.voiceGain=g;this.voices.add(osc);osc.onended=()=>{this.voices.delete(osc);osc.disconnect();filter.disconnect();g.disconnect();p.disconnect()}}
 pitch(degree,oct){const s=this.field.scale;return 12*oct+this.field.key+s[((degree%7)+7)%7]}
 beatPosition(){const now=this.a.currentTime,marks=this.beatMarkers;if(!marks.length||now<marks[0].time)return 0;let i=marks.length-1;while(i>0&&marks[i].time>now)i--;const a=marks[i],b=marks[i+1];return b?a.beat+(now-a.time)/(b.time-a.time)*(b.beat-a.beat):a.beat+Math.max(0,now-a.time)*this.bpm/60}
 schedule(){if(!enabled||this.a.state!=='running')return;const now=this.a.currentTime;if(this.next<now-.1)this.next=now+.08;let safety=0;while(this.next<now+.24&&safety++<16){const t=this.next,step=this.tick%16;this.beatMarkers.push({time:t,beat:this.tick/4});if(this.beatMarkers.length>128)this.beatMarkers.shift();if(step===0){const idx=weights.indexOf(Math.max(...weights));if(idx!==this.fieldIndex&&weights[idx]>.88){this.fieldIndex=idx;this.targetBpm=worlds[idx].bpm;for(const o of this.voices){const g=o.voiceGain;if(g?.gain.cancelAndHoldAtTime)g.gain.cancelAndHoldAtTime(t);else g?.gain.cancelScheduledValues?.(t);g?.gain.setTargetAtTime(.0001,t,.04);try{o.stop(t+.32)}catch{}}}this.field=worlds[this.fieldIndex];if(typeof syncImportedBeat==='function')syncImportedBeat(this.tick/4,t);this.frame++}const chord=[0,3,5,4][Math.floor((this.frame-1)/2)%4];if(step===0){[0,1,2,3].forEach(i=>{[0,2,4].forEach((d,j)=>this.note(this.pitch(chord+d,3+(i===0?1:0)),t+j*.045,6.8,i,i===2?'sine':i===3?'triangle':'sine',.048,(j-1)*.35));this.note(this.pitch(chord,2),t,5,i,'sine',.08)})}for(let i=0;i<4;i++){const r=this.random(),density=[.28,.42,.12,.68][i]+curvature*.25;if(r<density){const degree=chord+[0,2,4,6,7,9][Math.floor(this.random()*6)];this.note(this.pitch(degree,4+(i===0?1:0)),t,1.1+this.random()*2.5,i,i===3?'triangle':'sine',.04+this.random()*.018,(this.random()-.5)*1.4)}}if(step%4===0)this.note(this.pitch(chord,2),t,.45,3,'sine',.11);this.tick++;this.next+=60/this.bpm/4}}
 update(dt){const a=this.a,t=a.currentTime;const target=typeof transitionSettings==='undefined'?weights.reduce((v,w,i)=>v+w*worlds[i].bpm,0):this.targetBpm;this.bpm+=(target-this.bpm)*(1-Math.exp(-dt/3));this.buses.forEach((g,i)=>g.gain.setTargetAtTime(Math.sqrt(weights[i])*.48*(typeof guardedGain==='function'?guardedGain(i):1),t,.35));this.routes.forEach((r,i)=>r.input.gain.setTargetAtTime(srcOn[i]&&!uiFadeSources?1:0,t,.12));this.delay.delayTime.setTargetAtTime(60/this.bpm*.65+curvature*.08,t,.5);if(typeof updateImportedAudio==='function')updateImportedAudio(dt);if(typeof updateSpatialScene==='function')updateSpatialScene(dt)}
 volume(){this.master.gain.setTargetAtTime(muted?0:+$('volume').value/100,this.a.currentTime,.1)}
}
let uiAnalyser=null,uiFFT=null;
function uiTap(){if(uiAnalyser||!audio)return;try{uiAnalyser=audio.a.createAnalyser();uiAnalyser.fftSize=256;uiAnalyser.smoothingTimeConstant=.78;uiFFT=new Uint8Array(uiAnalyser.frequencyBinCount);audio.out.connect(uiAnalyser)}catch{uiAnalyser=null}}
let uiEnterP=null;
function enter(){return uiEnterP||(uiEnterP=uiEnter().finally(()=>{uiEnterP=null}))}
async function uiEnter(){const gate=$('gate');try{try{if(navigator.audioSession)navigator.audioSession.type='playback'}catch{}gate.classList.add('booting');uiBuzz(18);const hold=new Promise(r=>setTimeout(r,gate.hidden?0:1050));if(!audio){audio=new SoundField();audio.a.onstatechange=()=>{if(enabled&&audio.a.state!=='running'&&!silenced){silenced=true;stopJourney();if(typeof saveWorkingSession==='function')saveWorkingSession()}}}await audio.a.resume();if(typeof audioReady!=='undefined')await audioReady;if(typeof hydrateAudioSlots==='function')await hydrateAudioSlots();if(typeof initializeEffects==='function')await initializeEffects();enabled=true;try{localStorage.setItem('continuum-audio-activated-v1','true')}catch{}uiTap();uiMediaSession();await hold;gate.classList.add('out');setTimeout(()=>{gate.hidden=true;gate.classList.remove('out','booting')},520);silenced=false;audio.volume();controls()}catch(e){gate.classList.remove('booting');message(e.message);$('enterLabel').textContent='Retry'}}
$('enter').onclick=enter;$('volume').oninput=()=>audio?.volume();
$('play').onclick=async()=>{if(path.length<2)return;if(!enabled){await enter();if(!enabled)return}if(playing){stopJourney();silence();message('Paused');return}await wake();playJourney()};
$('stop').onclick=()=>{if(!enabled)return;stopJourney();progress=0;if(path.length>1)point={...path[0]};controls();silence();message('Stopped')};
$('clear').onclick=()=>{stopJourney();path=[];progress=0;indexPath();controls();message('Cleared')};$('new').onclick=()=>{stopJourney();seed=crypto.getRandomValues(new Uint32Array(1))[0];nodes=positions(seed);path=[];progress=0;renderNodes();controls();audio?.reset(seed);message('New layout')};
function snapshotData(){return{version:1,seed,...(typeof performanceData==='function'?performanceData():{}),scene:typeof transitionSettings==='undefined'?undefined:{...transitionSettings},audio:audioSlots.map(t=>t?{id:t.id,name:t.name,bpm:t.bpm,key:t.key,mode:t.mode,beatOffset:t.beatOffset}:null),audioMode:typeof audioMode==='undefined'?'match':audioMode,nodes:nodes.map(n=>({...n})),path:path.map(p=>({...p})),duration:+$('duration').value,created:new Date().toISOString(),id:crypto.randomUUID()}}
function storeSnapshots(){try{localStorage.setItem('continuum-journeys-v1',JSON.stringify(snapshots));return true}catch{return false}}
// Restores a saved journey (audio refs, scene, effects, layout, route). Returns false if it could not be restored.
async function loadSnapshot(s){if(!enabled)await enter();if(!enabled)return false;stopJourney();try{if(typeof restoreSnapshotAudio==='function')await restoreSnapshotAudio(s)}catch(e){message(e.message);return false}if(typeof restoreSceneSettings==='function')restoreSceneSettings(s);if(typeof restorePerformance==='function')restorePerformance(s);seed=s.seed;nodes=s.nodes.map(n=>({...n}));path=s.path.map(p=>({...p}));$('duration').value=s.duration;progress=0;renderNodes();indexPath();controls();return true}
function renderSnapshots(){$('snapshots').replaceChildren();$('empty').hidden=snapshots.length>0;$('savedCount').textContent=snapshots.length+(snapshots.length===1?' SNAPSHOT':' SNAPSHOTS');snapshots.forEach((s,i)=>{const card=document.createElement('article');card.className='snapshot';const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox','0 0 200 80');const line=document.createElementNS(svg.namespaceURI,'polyline');line.setAttribute('points',s.path.map(p=>p.x*200+','+p.y*80).join(' '));line.setAttribute('fill','none');line.setAttribute('stroke','#a8ecf0');line.setAttribute('stroke-width','1');svg.append(line);s.nodes.forEach((n,j)=>{const c=document.createElementNS(svg.namespaceURI,'circle');c.setAttribute('cx',n.x*200);c.setAttribute('cy',n.y*80);c.setAttribute('r','3.2');c.setAttribute('fill',palettes[j]);svg.append(c)});const h=document.createElement('h3');h.textContent='Journey '+String(snapshots.length-i).padStart(2,'0');const p=document.createElement('p');p.textContent=s.duration+' SEC / '+new Date(s.created).toLocaleDateString();p.className='micro';const actions=document.createElement('div');actions.className='actions';[['Replay',async()=>{if(await loadSnapshot(s))playJourney(true)}],['Audio',()=>{if(typeof openExportSheet==='function')openExportSheet(s)}],['Data',()=>{const blob=new Blob([JSON.stringify(s,null,2)],{type:'application/json'}),u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download='continuum-journey-'+s.id.slice(0,8)+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);message('Exported')}],['Delete',()=>{snapshots=snapshots.filter(x=>x.id!==s.id);storeSnapshots();renderSnapshots();message('Deleted')}]].forEach(([text,fn])=>{const b=document.createElement('button');b.type='button';b.className=text==='Replay'?'primary':text==='Delete'?'danger':'';b.textContent=text;b.onclick=fn;actions.append(b)});card.append(svg,h,p,actions);$('snapshots').append(card)})}
$('save').onclick=()=>{if(path.length<2)return;if(snapshots.length>=24){message('Journey limit reached');return}snapshots.unshift(snapshotData());const ok=storeSnapshots();renderSnapshots();message(ok?'Saved':'Storage unavailable · export instead');};
function validSnapshot(s){return s&&s.version===1&&(typeof validPerformance!=='function'||validPerformance(s))&&(!s.scene||(typeof s.scene.focus==='boolean'&&typeof s.scene.guard==='boolean'&&Number.isFinite(s.scene.spatial)&&s.scene.spatial>=0&&s.scene.spatial<=.7))&&(!s.audioMode||['match','tempo','original'].includes(s.audioMode))&&(!s.audio||(Array.isArray(s.audio)&&s.audio.length===4&&s.audio.every(t=>!t||(typeof t.id==='string'&&typeof t.name==='string'&&Number.isFinite(t.bpm)&&t.bpm>=40&&t.bpm<=240&&Number.isInteger(t.key)&&t.key>=0&&t.key<12&&['Major','Minor'].includes(t.mode)&&Number.isFinite(t.beatOffset)&&t.beatOffset>=0&&t.beatOffset<2))))&&Number.isInteger(s.seed)&&typeof s.id==='string'&&typeof s.created==='string'&&[30,60,120,300].includes(s.duration)&&Array.isArray(s.nodes)&&s.nodes.length===4&&s.nodes.every(n=>n.radius===undefined||(Number.isFinite(n.radius)&&n.radius>=.16&&n.radius<=.85))&&Array.isArray(s.path)&&s.path.length>=2&&s.path.length<=4000&&[...s.path,...s.nodes].every(p=>Number.isFinite(p.x)&&Number.isFinite(p.y)&&p.x>=0&&p.x<=1&&p.y>=0&&p.y<=1)}
try{const raw=JSON.parse(localStorage.getItem('continuum-journeys-v1')||'[]');snapshots=Array.isArray(raw)?raw.filter(validSnapshot).slice(0,24):[]}catch{}
$('import').onclick=()=>$('importFile').click();$('importFile').onchange=async e=>{const file=e.target.files[0];if(!file)return;try{if(file.size>700000)throw Error('This journey file is too large.');const s=JSON.parse(await file.text());if(!validSnapshot(s))throw Error('Choose a valid CONTINUUM journey JSON file.');if(snapshots.some(x=>x.id===s.id)){message('Already saved');return}if(snapshots.length>=24)throw Error('Delete a snapshot to make room before importing.');snapshots.unshift(s);const ok=storeSnapshots();renderSnapshots();message(ok?'Imported':'Imported · storage unavailable')}catch(err){message(err.message)}finally{e.target.value=''}};
const mixSpans=worlds.map((w,i)=>{const s=document.createElement('span');s.style.setProperty('--color',palettes[i]);$('mix').append(s);return s});
const uiGrid=document.createElement('canvas');let uiGW=0,uiGH=0,uiGD=0;
function uiBuildGrid(w,h,dpr){uiGrid.width=Math.round(w*dpr);uiGrid.height=Math.round(h*dpr);const g=uiGrid.getContext('2d');g.setTransform(dpr,0,0,dpr,0,0);g.strokeStyle='rgba(120,200,212,.34)';g.lineWidth=.7;g.beginPath();const st=w<520?30:38;for(let x=st/2;x<w;x+=st)for(let y=st/2;y<h;y+=st){g.moveTo(x-2,y);g.lineTo(x+2,y);g.moveTo(x,y-2);g.lineTo(x,y+2)}g.stroke();
 g.strokeStyle='rgba(150,215,225,.5)';g.fillStyle='rgba(150,205,215,.55)';g.font='8px '+uiMono;g.textBaseline='middle';g.beginPath();
 for(let i=0;i<=20;i++){const maj=i%5===0,y=i/20*h;g.moveTo(w-1,y);g.lineTo(w-(maj?9:5),y);const x=i/20*w;g.moveTo(x,h-1);g.lineTo(x,h-(maj?9:5))}g.stroke();
 g.textAlign='right';for(let i=1;i<4;i++){g.fillText((i/4).toFixed(2),w-13,i/4*h)}g.textAlign='center';for(let i=1;i<4;i++){g.fillText((i/4).toFixed(2),i/4*w,h-14)}
 uiGW=w;uiGH=h;uiGD=dpr}
function uiGlobe(x,y,R,color,rot,lw){ctx.save();ctx.translate(x,y);ctx.rotate(-.38);ctx.strokeStyle=color;ctx.lineWidth=lw;ctx.beginPath();ctx.arc(0,0,R,0,6.2832);ctx.stroke();ctx.beginPath();for(let k=0;k<6;k++){const rx=Math.abs(Math.sin(rot+k*Math.PI/6))*R;ctx.moveTo(rx,0);ctx.ellipse(0,0,Math.max(.6,rx),R,0,0,6.2832)}ctx.stroke();ctx.beginPath();for(let k=-2;k<=2;k++){const lat=k*Math.PI/6.4,rx=Math.cos(lat)*R,cy=Math.sin(lat)*R;ctx.moveTo(rx,cy);ctx.ellipse(0,cy,rx,Math.max(.6,rx*.27),0,0,6.2832)}ctx.stroke();ctx.restore()}
function draw(time){
 const w=uiSize.w,h=uiSize.h;if(w<20||h<20)return;
 const dpr=Math.min(devicePixelRatio||1,2),t=time/1000;
 if(canvas.width!==Math.round(w*dpr)||canvas.height!==Math.round(h*dpr)){canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr)}
 if(uiGW!==w||uiGH!==h||uiGD!==dpr)uiBuildGrid(w,h,dpr);
 ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);ctx.drawImage(uiGrid,0,0,w,h);
 const U=Math.min(w,h),orb=Math.max(21,Math.min(36,U*.085)),spin=reduced?0:t*.32;if(stage._orb!==orb){stage._orb=orb;stage.style.setProperty('--orb',orb+'px')}
 const hl=drawing?'#ff7a52':'#ece3a4';
 // influence fields
 nodes.forEach((n,i)=>{const x=n.x*w,y=n.y*h,r=projectionRadius(n)*U;
  if(enabled){const g=ctx.createRadialGradient(x,y,0,x,y,r),a=Math.round(12+weights[i]*46).toString(16).padStart(2,'0');g.addColorStop(0,palettes[i]+a);g.addColorStop(1,palettes[i]+'00');ctx.fillStyle=g;ctx.fillRect(x-r,y-r,r*2,r*2)}
  ctx.lineWidth=.8;ctx.setLineDash([1.5,5]);for(let k=0;k<3;k++){ctx.strokeStyle=palettes[i]+(k===2?'90':'38');ctx.beginPath();ctx.arc(x,y,r*(.62+k*.19),0,6.2832);ctx.stroke()}ctx.setLineDash([]);
  if(uiRing&&uiRing.i===i){const pu=reduced?.5:.5+.5*Math.sin(t*6),rk=r*uiRingF[uiRing.k];ctx.save();ctx.shadowColor=palettes[i];ctx.shadowBlur=8+12*pu;ctx.strokeStyle=palettes[i]+'f0';ctx.lineWidth=1.6+1.6*pu;ctx.beginPath();ctx.arc(x,y,rk,0,6.2832);ctx.stroke();ctx.restore();ctx.strokeStyle=palettes[i]+'66';ctx.lineWidth=1;for(const f of uiRingF){if(f===uiRingF[uiRing.k])continue;ctx.beginPath();ctx.arc(x,y,r*f,0,6.2832);ctx.stroke()}ctx.fillStyle=palettes[i];ctx.font='8px '+uiMono;ctx.textAlign='center';ctx.textBaseline='alphabetic';ctx.fillText('RADIUS '+Math.round(projectionRadius(n)*100)+'%',x,y-rk-7>24?y-rk-7:Math.min(h-6,y+rk+13))}});
 // listener crosshair + weight tethers
 if(enabled){const head=(path.length>1&&(playing||progress>0)&&!drawing)?samplePath(progress):point,hx=head.x*w,hy=head.y*h;
  ctx.strokeStyle='rgba(190,240,240,.09)';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(0,hy);ctx.lineTo(w,hy);ctx.moveTo(hx,0);ctx.lineTo(hx,h);ctx.stroke();
  nodes.forEach((n,i)=>{if(weights[i]<.025)return;ctx.strokeStyle=palettes[i]+Math.round(26+weights[i]*90).toString(16).padStart(2,'0');ctx.lineWidth=.8+weights[i]*.8;ctx.setLineDash([2,6]);ctx.beginPath();ctx.moveTo(hx,hy);ctx.lineTo(n.x*w,n.y*h);ctx.stroke();ctx.setLineDash([])})}
 // route
 if(path.length>1){
  ctx.lineJoin='round';ctx.lineCap='round';
  ctx.strokeStyle='rgba(143,227,234,.16)';ctx.lineWidth=7;ctx.beginPath();path.forEach((p,i)=>i?ctx.lineTo(p.x*w,p.y*h):ctx.moveTo(p.x*w,p.y*h));ctx.stroke();
  ctx.setLineDash([5,5]);ctx.strokeStyle='rgba(168,236,240,.78)';ctx.lineWidth=1.2;ctx.beginPath();path.forEach((p,i)=>i?ctx.lineTo(p.x*w,p.y*h):ctx.moveTo(p.x*w,p.y*h));ctx.stroke();ctx.setLineDash([]);
  const a=path[0],z=path[path.length-1];ctx.strokeStyle=hl;ctx.fillStyle=hl;ctx.lineWidth=1.2;ctx.save();ctx.translate(a.x*w,a.y*h);ctx.rotate(Math.PI/4);ctx.strokeRect(-4,-4,8,8);ctx.restore();ctx.beginPath();ctx.arc(z.x*w,z.y*h,3,0,6.2832);ctx.fill();const ep=reduced?.5:.5+.5*Math.sin(t*3.2);ctx.beginPath();ctx.arc(z.x*w,z.y*h,8+ep*2.5,0,6.2832);ctx.stroke()}
 // sources
 nodes.forEach((n,i)=>{const x=n.x*w,y=n.y*h,c=palettes[i],wt=srcOn[i]?weights[i]:0;ctx.globalAlpha=srcOn[i]?1:.38;
  const meter=audio?.routes?.[i],level=meter?.level||0;
  const g0=ctx.createRadialGradient(x,y,0,x,y,orb*1.4);g0.addColorStop(0,c+'26');g0.addColorStop(1,c+'00');ctx.fillStyle=g0;ctx.beginPath();ctx.arc(x,y,orb*1.4,0,6.2832);ctx.fill();
  uiGlobe(x,y,orb,c+'a8',(srcOn[i]?spin:0)*(i%2?-1:1)+i,.8);
  // dial dots
  const dots=44,lit=Math.round(wt*dots),rr=orb+14;ctx.fillStyle=c;ctx.beginPath();for(let d=0;d<lit;d++){const a=-Math.PI/2+d/dots*6.2832;ctx.moveTo(x+Math.cos(a)*rr+1.7,y+Math.sin(a)*rr);ctx.arc(x+Math.cos(a)*rr,y+Math.sin(a)*rr,1.7,0,6.2832)}ctx.fill();
  ctx.fillStyle=c+'44';ctx.beginPath();for(let d=lit;d<dots;d++){const a=-Math.PI/2+d/dots*6.2832;ctx.moveTo(x+Math.cos(a)*rr+1,y+Math.sin(a)*rr);ctx.arc(x+Math.cos(a)*rr,y+Math.sin(a)*rr,1,0,6.2832)}ctx.fill();
  // ticks + sweep arcs
  ctx.strokeStyle=c+'66';ctx.lineWidth=.8;ctx.beginPath();for(let k=0;k<24;k++){const a=k*Math.PI/12,i0=orb+23,i1=i0+(k%6===0?6:3);ctx.moveTo(x+Math.cos(a)*i0,y+Math.sin(a)*i0);ctx.lineTo(x+Math.cos(a)*i1,y+Math.sin(a)*i1)}ctx.stroke();
  const sw=reduced?0:t*(i%2?-.9:.9);ctx.strokeStyle=c+'bb';ctx.lineWidth=1.3;ctx.beginPath();ctx.arc(x,y,orb+8,sw,sw+.9);ctx.stroke();ctx.beginPath();ctx.arc(x,y,orb+8,sw+Math.PI,sw+Math.PI+.5);ctx.stroke();
  // live waveform + core
  if(meter?.meter){ctx.strokeStyle=c;ctx.lineWidth=1;ctx.beginPath();for(let k=0;k<64;k++){const px=x-orb+k*orb*2/63,py=y+(meter.meter[k*2]-128)/128*orb*.6;k?ctx.lineTo(px,py):ctx.moveTo(px,py)}ctx.stroke()}
  ctx.fillStyle=c;ctx.beginPath();ctx.arc(x,y,2+level*3,0,6.2832);ctx.fill();
  // leader + coordinate callout toward map centre (roomy stages only)
  if(w>=520){const side=n.x>.5?-1:1,ay=y-orb*.5,ax=x+side*(orb+30);ctx.strokeStyle=c+'88';ctx.lineWidth=.7;ctx.beginPath();ctx.moveTo(ax,y);ctx.lineTo(ax+side*14,ay);ctx.lineTo(ax+side*14+side*22,ay);ctx.stroke();
  ctx.fillStyle=c+'cc';ctx.font='8px '+uiMono;ctx.textBaseline='alphabetic';ctx.textAlign=side>0?'left':'right';ctx.fillText('X '+n.x.toFixed(3),ax+side*18,ay-3);ctx.fillStyle=c+'88';ctx.fillText('Y '+n.y.toFixed(3),ax+side*18,ay+9)}});
 ctx.globalAlpha=1;
 // collisions: overlapping spheres link up
 for(let i=0;i<4;i++)for(let j=i+1;j<4;j++){const xi=nodes[i].x*w,yi=nodes[i].y*h,xj=nodes[j].x*w,yj=nodes[j].y*h,d=Math.hypot(xi-xj,yi-yj)/U,o=1-d/.2;if(o<=0||!srcOn[i]||!srcOn[j])continue;const mx=(xi+xj)/2,my=(yi+yj)/2,pu=reduced?.5:.5+.5*Math.sin(t*6);ctx.strokeStyle='rgba(236,227,164,'+(.3+o*.55).toFixed(2)+')';ctx.lineWidth=1.2;ctx.beginPath();ctx.moveTo(xi,yi);ctx.lineTo(xj,yj);ctx.stroke();for(let k=0;k<2;k++){ctx.beginPath();ctx.arc(mx,my,orb*(.5+o*.9)+k*5+pu*4,0,6.2832);ctx.stroke()}}
 // sphere being moved
 if(uiMove>=0&&nodes[uiMove]){const n=nodes[uiMove],x=n.x*w,y=n.y*h,pu=reduced?.5:.5+.5*Math.sin(t*7);ctx.strokeStyle='rgba(255,106,69,.9)';ctx.setLineDash([3,4]);ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(x,y,orb+30+pu*6,0,6.2832);ctx.stroke();ctx.setLineDash([])}
 // loop closure: the end flows back to the start
 if(loopOn&&path.length>1){const e=path[path.length-1],st=path[0],ex=e.x*w,ey=e.y*h,sx=st.x*w,sy=st.y*h,len=Math.hypot(sx-ex,sy-ey);
  if(len>6){ctx.lineCap='round';ctx.strokeStyle='rgba(236,227,164,.14)';ctx.lineWidth=7;ctx.beginPath();ctx.moveTo(ex,ey);ctx.lineTo(sx,sy);ctx.stroke();
   ctx.setLineDash([2,6]);ctx.lineDashOffset=reduced?0:-t*14;ctx.strokeStyle='#ece3a4';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(ex,ey);ctx.lineTo(sx,sy);ctx.stroke();ctx.setLineDash([]);ctx.lineDashOffset=0;
   const ang=Math.atan2(sy-ey,sx-ex),mx=(ex+sx)/2,my=(ey+sy)/2;ctx.fillStyle='#ece3a4';ctx.save();ctx.translate(mx,my);ctx.rotate(ang);ctx.beginPath();ctx.moveTo(6,0);ctx.lineTo(-4,-5);ctx.lineTo(-4,5);ctx.closePath();ctx.fill();ctx.restore()}
  const rp=reduced?.5:.5+.5*Math.sin(t*3);ctx.strokeStyle='rgba(236,227,164,'+(.85-rp*.5)+')';ctx.lineWidth=1.2;ctx.beginPath();ctx.arc(sx,sy,11+rp*5,0,6.2832);ctx.stroke();ctx.fillStyle='#ece3a4';ctx.font='8px '+uiMono;ctx.textAlign='center';ctx.textBaseline='alphabetic';ctx.fillText('LOOP ↻ START',sx,sy-18)}
 // held section + pulsing release marker
 if(holdRegion&&path.length>1){const ta=holdRegion.a*totalLength,tb=holdRegion.b*totalLength,pa=samplePath(holdRegion.a),pb=samplePath(holdRegion.b),pc=samplePath(holdRegion.c);
  ctx.lineJoin='round';ctx.lineCap='round';ctx.strokeStyle='rgba(255,106,69,.22)';ctx.lineWidth=11;ctx.beginPath();ctx.moveTo(pa.x*w,pa.y*h);for(let i=0;i<path.length;i++)if(lengths[i]>ta&&lengths[i]<tb)ctx.lineTo(path[i].x*w,path[i].y*h);ctx.lineTo(pb.x*w,pb.y*h);ctx.stroke();ctx.strokeStyle='#ff9a6b';ctx.lineWidth=2.6;ctx.stroke();
  ctx.fillStyle='#ff9a6b';for(const q of[pa,pb]){ctx.beginPath();ctx.arc(q.x*w,q.y*h,3,0,6.2832);ctx.fill()}
  const pu=reduced?.5:.5+.5*Math.sin(t*5.5);ctx.strokeStyle='rgba(255,106,69,'+(.75-pu*.55)+')';ctx.lineWidth=1.4;ctx.beginPath();ctx.arc(pc.x*w,pc.y*h,10+pu*14,0,6.2832);ctx.stroke();ctx.fillStyle='#02070a';ctx.beginPath();ctx.arc(pc.x*w,pc.y*h,8,0,6.2832);ctx.fill();ctx.fillStyle='#ff6a45';ctx.beginPath();ctx.arc(pc.x*w,pc.y*h,4.5+pu*1.5,0,6.2832);ctx.fill();
  ctx.fillStyle='#ffb394';ctx.font='8px '+uiMono;ctx.textAlign='center';ctx.textBaseline='alphabetic';ctx.fillText('LOOP · TAP TO RELEASE',pc.x*w,pc.y*h-24)}
 if(uiGrab>=0&&path[uiGrab]){const g=path[uiGrab];ctx.strokeStyle='#ece3a4';ctx.lineWidth=1.4;ctx.beginPath();ctx.arc(g.x*w,g.y*h,15,0,6.2832);ctx.stroke();ctx.fillStyle='#ece3a4';ctx.beginPath();ctx.arc(g.x*w,g.y*h,3,0,6.2832);ctx.fill()}
 // listener
 if(enabled){const onPath=path.length>1&&(playing||progress>0)&&!drawing,head=onPath?samplePath(progress):point,x=head.x*w,y=head.y*h;
  const beat=audio?audio.beatPosition():0,phase=beat-Math.floor(beat),pulse=playing&&!reduced?Math.exp(-phase*5):0;
  if(onPath){ctx.strokeStyle='#d7fbf6';ctx.lineWidth=2.6;ctx.lineJoin='round';ctx.beginPath();for(let i=0;i<path.length&&lengths[i]<=progress*totalLength;i++){const p=path[i];i?ctx.lineTo(p.x*w,p.y*h):ctx.moveTo(p.x*w,p.y*h)}ctx.lineTo(x,y);ctx.stroke()}
  ctx.strokeStyle=hl+Math.round(90+pulse*150).toString(16).padStart(2,'0');ctx.lineWidth=1.2;ctx.beginPath();ctx.arc(x,y,13+pulse*10,0,6.2832);ctx.stroke();
  const rot=reduced?0:t*1.6;ctx.strokeStyle=hl;ctx.lineWidth=1.6;for(let k=0;k<4;k++){const a=rot+k*Math.PI/2;ctx.beginPath();ctx.arc(x,y,9,a,a+.7);ctx.stroke()}
  ctx.fillStyle='#02070a';ctx.beginPath();ctx.arc(x,y,4.5,0,6.2832);ctx.fill();ctx.fillStyle=hl;ctx.beginPath();ctx.arc(x,y,2.6+pulse*1.2,0,6.2832);ctx.fill();
  ctx.strokeStyle=hl+'aa';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x-19,y);ctx.lineTo(x-14,y);ctx.moveTo(x+14,y);ctx.lineTo(x+19,y);ctx.moveTo(x,y-19);ctx.lineTo(x,y-14);ctx.moveTo(x,y+14);ctx.lineTo(x,y+19);ctx.stroke()}
}
const uiBars=new Float32Array(96);
function drawSpectrum(time){const c=$('spectrum');if(!c||!c.offsetParent)return;const w=c.clientWidth,h=c.clientHeight;if(w<10||h<4)return;const dpr=Math.min(devicePixelRatio||1,2);if(c.width!==Math.round(w*dpr)||c.height!==Math.round(h*dpr)){c.width=Math.round(w*dpr);c.height=Math.round(h*dpr)}
 const g=c.getContext('2d');g.setTransform(dpr,0,0,dpr,0,0);g.clearRect(0,0,w,h);const N=Math.min(uiBars.length,Math.floor(w/5)),live=uiAnalyser&&audio&&audio.a.state==='running';if(live)uiAnalyser.getByteFrequencyData(uiFFT);const t=time/1000;
 for(let i=0;i<N;i++){let v;if(live){const f=Math.pow(i/N,1.25),b=Math.min(uiFFT.length-1,1+Math.floor(f*64));v=Math.min(1,Math.pow(uiFFT[b]/255,1.15)*1.45)}else{const s=Math.sin(i*12.9898+Math.floor(t*1.6)*78.233)*43758.5453;v=.06+(s-Math.floor(s))*.16*(.6+.4*Math.sin(t*.7+i*.3))}
  uiBars[i]+=(v-uiBars[i])*(v>uiBars[i]?.55:.16);const bh=Math.max(2,uiBars[i]*h),x=Math.round(i*(w/N))+.5;g.fillStyle=uiBars[i]>.72?'#ece3a4':uiBars[i]>.4?'#8fdde0':'#2f6f7d';g.fillRect(x,h-bh,1.6,bh)}}
let uiTime=0,drawTime=0,effectUpdateTime=0;function animate(time){try{step(time)}catch(e){console.error(e)}requestAnimationFrame(animate)}
function step(time){const dt=Math.min(.1,(time-lastFrame)/1000||.016);lastFrame=time;if(playing){let pr=journeyStartProgress+Math.max(0,audio.beatPosition()-journeyStartBeat)/journeyBeats;
 if(holdRegion&&pr>=holdRegion.b){journeyStartBeat+=(holdRegion.b-journeyStartProgress)*journeyBeats;journeyStartProgress=holdRegion.a;pr=journeyStartProgress+Math.max(0,audio.beatPosition()-journeyStartBeat)/journeyBeats}
 else if(loopOn&&!holdRegion&&pr>=1){journeyStartBeat+=(1-journeyStartProgress)*journeyBeats;journeyStartProgress=0;pr=Math.max(0,audio.beatPosition()-journeyStartBeat)/journeyBeats}
 progress=Math.min(1,pr);point=samplePath(progress);curvature=geometry(progress);}const target=typeof musicalMix==='function'?musicalMix(point):blend(point);weights=weights.map((w,i)=>w+(target[i]-w)*(1-Math.exp(-dt*2.5)));if(audio&&enabled&&audio.a.state==='running'&&time-effectUpdateTime>=40){audio.update(Math.min(.1,(time-effectUpdateTime)/1000||.04));effectUpdateTime=time;}
if(time-uiTime>180){uiTime=time;const idx=weights.indexOf(Math.max(...weights));
 $('nodeLayer').querySelectorAll('button').forEach((b,i)=>b.setAttribute('aria-pressed',i===idx&&enabled?'true':'false'));
 $('identStrip').querySelectorAll('button').forEach((b,i)=>{b.setAttribute('aria-pressed',i===idx&&enabled?'true':'false');b.style.setProperty('--w',(weights[i]*100).toFixed(1)+'%');});
 const field=audio?.field||worlds[0];
 $('harmony').textContent=uiNotes[field.key]+' '+field.mode;uiNum('tempo',uiPad(Math.min(999,Math.round(audio?.bpm||72)),3));
 uiNum('srcCode',uiPad(idx+1));$('srcName').textContent=worlds[idx].name;
 const has=path.length>1;uiNum('progress',uiPad(playing||(has&&progress>0)?Math.min(99,Math.round(progress*100)):0));
 $('progressLabel').textContent=holdRegion?'HOLD · '+Math.round((holdRegion.b-holdRegion.a)*journeyBeats)+' BEATS':playing?'LOOP · BEAT '+(Math.floor(audio.beatPosition()-journeyStartBeat)+1):drawing?'DRAWING':progress>=1&&has?'ARRIVED':has?'ROUTE SET':'FREE';
 if(typeof updateEffectsClock==='function')updateEffectsClock();if(typeof updateSceneMeters==='function')updateSceneMeters();
 if(typeof transitionLabel==='function'){const tl=enabled?transitionLabel():'STANDBY';$('transitionState').textContent=tl;const t2=$('transitionState2');if(t2)t2.textContent=tl}
 mixSpans.forEach((s,i)=>s.style.width=weights[i]*100+'%');
 $('stageStatus').textContent=enabled?(holdRegion?'LOOPING SECTION':playing?'LOOPING':drawing?'DRAWING ROUTE':worlds[idx].desc.toUpperCase()):'Waiting for sound';
 stage.dataset.mode=!enabled?'idle':holdRegion?'hold':playing?'playing':drawing?'drawing':'ready';const tipOn=playing&&!holdRegion&&time-uiPlayStart<7000;stage.classList.toggle('tip',tipOn);{const ht=stage.querySelector('.hint'),tx=tipOn?'Hold route to loop · drag to bend':'Draw a route';if(ht.textContent!==tx)ht.textContent=tx}

 $('nodeLayer').querySelectorAll('button.node').forEach((b,i)=>{b.classList.toggle('off',!srcOn[i]);const sm=b.querySelector('small'),want=srcOn[i]?nodeSub(i):'STOPPED';if(sm&&sm.textContent!==want)sm.textContent=want});
 $('identStrip').querySelectorAll('button').forEach((b,i)=>b.classList.toggle('off',!srcOn[i]));
 const live=$('liveState');if(live){const st=!enabled?'OFF':silenced||audio.a.state!=='running'?'SILENT':'LIVE';if(live.textContent!==st){live.textContent=st;live.dataset.s=st}}
 document.querySelectorAll('input[type=range]').forEach(r=>{const f=((+r.value-+(r.min||0))/((+r.max||100)-+(r.min||0))*100).toFixed(1)+'%';if(r.style.getPropertyValue('--fill')!==f)r.style.setProperty('--fill',f)})}
if(!document.hidden&&time-drawTime>((silenced||!enabled)&&!press?70:32)){drawTime=time;draw(time);drawSpectrum(time);if(typeof drawFxViz==='function')drawFxViz(time)}}
// Background play: browsers throttle timers and pause animation frames in hidden tabs, so a Worker clock keeps the
// scheduler and the route running, and the Media Session lets the OS show transport controls.
let uiBg=null;
function uiBgClock(on){if(!on){if(uiBg){uiBg.terminate();uiBg=null}return}if(uiBg)return;try{const url=URL.createObjectURL(new Blob(['setInterval(()=>postMessage(0),30)'],{type:'text/javascript'}));uiBg=new Worker(url);URL.revokeObjectURL(url);uiBg.onmessage=()=>{if(!document.hidden||!audio||!enabled||silenced)return;try{audio.schedule();step(performance.now())}catch{}}}catch{uiBg=null}}
function uiMediaSession(){if(!('mediaSession' in navigator))return;try{navigator.mediaSession.metadata=new MediaMetadata({title:'Spatial composition',artist:'CONTINUUM',album:'Echo Opera'});navigator.mediaSession.setActionHandler('play',()=>{if(silenced)wake();else if(!playing&&path.length>1)$('play').click()});navigator.mediaSession.setActionHandler('pause',()=>{if(playing)$('play').click();else silence()});navigator.mediaSession.setActionHandler('stop',()=>$('stop').click())}catch{}}
document.addEventListener('visibilitychange',async()=>{if(!audio||!enabled)return;if(document.hidden){uiBgClock(true);if(typeof saveWorkingSession==='function')saveWorkingSession()}else{uiBgClock(false);if(!silenced&&audio.a.state!=='running'){try{await audio.a.resume()}catch{}}}});
nodes=positions(seed);renderNodes();renderSnapshots();controls();requestAnimationFrame(animate);
['new','clear','save','play','stop'].forEach(k=>$(k).addEventListener('pointerdown',()=>uiBuzz(5)));

// ── Sphere colours ──
const uiSwatchColors=['#a2e1dd','#88c8e8','#b4bce8','#ddd4a0','#f0a6b8','#9fe3a8','#ffb27a','#e6e6ee'];
function setSourceColor(i,hex){palettes[i]=hex;try{localStorage.setItem('continuum-colors-v1',JSON.stringify(palettes))}catch{}mixSpans.forEach((m,k)=>m.style.setProperty('--color',palettes[k]));renderNodes();renderSnapshots();if(typeof renderAudioSlots==='function')renderAudioSlots();uiBuzz(6)}
function uiSwatches(i){const row=document.createElement('div');row.className='swatches';row.setAttribute('role','group');row.setAttribute('aria-label','Sphere colour');
 uiSwatchColors.forEach(h=>{const b=document.createElement('button');b.type='button';b.className='sw';b.style.setProperty('--c',h);b.setAttribute('aria-label','Colour '+h);b.setAttribute('aria-pressed',String(palettes[i].toLowerCase()===h));b.onclick=()=>setSourceColor(i,h);row.append(b)});
 const c=document.createElement('input');c.type='color';c.className='sw-custom';c.value=palettes[i];c.setAttribute('aria-label','Custom colour');c.onchange=()=>setSourceColor(i,c.value);row.append(c);return row}
